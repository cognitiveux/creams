package com.cognitiveux.data.impls

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.cognitiveux.domain.repositories.StarterRepository
import javax.inject.Inject
import androidx.core.net.toUri

class StarterRepositoryImpl @Inject constructor(
    private val context: Context
) : StarterRepository {

    override fun startRealtyScan() {

        val launchIntent = context.packageManager.getLaunchIntentForPackage(APP_PACKAGE)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            //Toast.makeText(context, "App not found", Toast.LENGTH_SHORT).show()
            try {
                val marketIntent = Intent(
                    Intent.ACTION_VIEW,
                    "market://details?id=$APP_PACKAGE".toUri()
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(marketIntent)
            } catch (e: ActivityNotFoundException) {
                // Если Play Маркет не найден, открываем страницу через браузер
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    "https://play.google.com/store/apps/details?id=$APP_PACKAGE".toUri()
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }

        }

    }

    companion object {
        private const val APP_PACKAGE = "com.epicgames.realityscan"
    }

}