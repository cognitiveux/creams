package com.cognitiveux.presentation.starter

import com.arkivanov.mvikotlin.core.store.Reducer
import com.arkivanov.mvikotlin.core.store.Store
import com.arkivanov.mvikotlin.core.store.StoreFactory
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineBootstrapper
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineExecutor
import com.cognitiveux.domain.use_cases.StartRealtyScanUseCase
import com.cognitiveux.presentation.starter.StarterStore.Intent
import com.cognitiveux.presentation.starter.StarterStore.Label
import com.cognitiveux.presentation.starter.StarterStore.State
import javax.inject.Inject

interface StarterStore : Store<Intent, State, Label> {

    sealed interface Intent {
        data object StartApp : Intent
    }

    data class State(
        val state: LoaderState = LoaderState.Initial
    ) {

        sealed interface LoaderState {
            data object Initial : LoaderState
        }
    }

    sealed interface Label {
    }
}

class StarterStoreFactory @Inject constructor(
    private val storeFactory: StoreFactory,
    private val startRealtyScanUseCase: StartRealtyScanUseCase
) {

    fun create(): StarterStore =
        object : StarterStore, Store<Intent, State, Label> by storeFactory.create(
            name = "StarterStore",
            initialState = State(),
            bootstrapper = BootstrapperImpl(),
            executorFactory = ::ExecutorImpl,
            reducer = ReducerImpl
        ) {}

    private sealed interface Action {
    }

    private sealed interface Msg {
    }

    private class BootstrapperImpl : CoroutineBootstrapper<Action>() {
        override fun invoke() {
        }
    }

    private inner class ExecutorImpl : CoroutineExecutor<Intent, Action, State, Msg, Label>() {
        override fun executeIntent(intent: Intent, getState: () -> State) {
            when (intent) {
                Intent.StartApp -> {
                    startRealtyScanUseCase()
                }
            }
        }

        override fun executeAction(action: Action, getState: () -> State) {
        }
    }

    private object ReducerImpl : Reducer<State, Msg> {
        override fun State.reduce(msg: Msg): State = this
    }
}
