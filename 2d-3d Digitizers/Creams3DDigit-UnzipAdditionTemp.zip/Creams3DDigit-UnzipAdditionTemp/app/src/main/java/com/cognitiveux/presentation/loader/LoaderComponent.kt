package com.cognitiveux.presentation.loader

import android.net.Uri
import kotlinx.coroutines.flow.StateFlow

interface LoaderComponent {

    val model: StateFlow<LoaderStore.State>

    fun onClickLoadAll(uri: List<Uri>, name: String)
    fun changeNameAll(uri: List<Uri>, name: String)
    fun onLogoSelected(uri: Uri)

}