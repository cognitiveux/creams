package com.cognitiveux.domain.use_cases

import com.cognitiveux.data.states.LoginResult
import com.cognitiveux.domain.repositories.UsersRepository
import javax.inject.Inject

class LoginUseCase @Inject constructor(
    private val repository: UsersRepository
) {

    suspend operator fun invoke(email: String, password: String): LoginResult =
        repository.login(email, password)

}