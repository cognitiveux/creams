package com.cognitiveux.presentation.loader

import android.net.Uri
import com.arkivanov.decompose.ComponentContext
import com.arkivanov.mvikotlin.core.instancekeeper.getStore
import com.arkivanov.mvikotlin.extensions.coroutines.stateFlow
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.StateFlow

class DefaultLoaderComponent @AssistedInject constructor(
    @Assisted("componentContext") componentContext: ComponentContext,
    private val loaderStoreFactory: LoaderStoreFactory,
    @Assisted("uris") private val uris: List<Uri> = emptyList()
) : LoaderComponent, ComponentContext by componentContext {

    private val store = instanceKeeper.getStore {
        loaderStoreFactory.create(uris = uris)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override val model: StateFlow<LoaderStore.State> = store.stateFlow

    override fun onClickLoadAll(uri: List<Uri>, name: String) {
        store.accept(LoaderStore.Intent.Upload(uri, name))
    }

    override fun changeNameAll(uri: List<Uri>, name: String) {
        store.accept(LoaderStore.Intent.ChangeNameAll(uri, name))
    }

    override fun onLogoSelected(uri: Uri) {
        store.accept(LoaderStore.Intent.SelectLogo(uri))
    }

    @AssistedFactory
    interface Factory {
        fun create(
            @Assisted("componentContext") componentContext: ComponentContext,
            @Assisted("uris") uris: List<Uri> = emptyList()
        ): DefaultLoaderComponent
    }
}