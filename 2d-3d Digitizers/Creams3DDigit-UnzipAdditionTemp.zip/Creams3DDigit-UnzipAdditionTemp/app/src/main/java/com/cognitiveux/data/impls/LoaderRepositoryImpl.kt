package com.cognitiveux.data.impls

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.cognitiveux.R
import com.cognitiveux.data.network.ApiService
import com.cognitiveux.data.states.LoginResult
import com.cognitiveux.data.states.UploadResult
import com.cognitiveux.domain.repositories.LoaderRepository
import com.cognitiveux.domain.use_cases.TokenUseCase
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.IOException
import javax.inject.Inject

class LoaderRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    private val context: Context,
    private val tokenUseCase: TokenUseCase
) : LoaderRepository {

    override suspend fun uploadProjectMultipleUri(
        uris: List<Uri>,
        name: String,
        logoUri: Uri?,
    ): UploadResult {
        val tokensData = tokenUseCase()
        if (tokensData !is LoginResult.Token) return UploadResult.ErrorAuth

        if (name.length < 3) return UploadResult.Error("Name must be at least 3 characters")

        val token = "Bearer ${tokensData.token.first}"
        val cookie = "access_tkn=${tokensData.token.first}; refresh_tkn=${tokensData.token.second}"

        try {
            val createArt = apiService.createArt(
                token = token,
                cookie = cookie,
                src = if (logoUri != null) {
                    createFilePart(fileUri = logoUri, partName = "src", fileName = "logo name")
                } else {
                    createImagePartFromDrawable(R.drawable.logo)
                },
                name = name.toRequestBody(MIME_TEXT.toMediaTypeOrNull()),
                artType = "3d".toRequestBody(MIME_TEXT.toMediaTypeOrNull()),
                genre = "glb".toRequestBody(MIME_TEXT.toMediaTypeOrNull())
            )
            Log.d("CreateArt", "$createArt")
            uris.forEach { uri ->
                Log.d("uploadProjectAll", uri.toString())
                val uploadFile = apiService.uploadFile(
                    token = token,
                    cookie = cookie,
                    file = createFilePart(fileUri = uri, fileName = uri.lastPathSegment ?: "file"),
                    artworkId = createArt.resourceId.toString()
                        .toRequestBody(MIME_TEXT.toMediaTypeOrNull()),
                    saveArtType = "3d".toRequestBody(MIME_TEXT.toMediaTypeOrNull())
                )
                Log.d("uploadProjectAll", "$uploadFile")
            }

            return UploadResult.Success
        } catch (e: Exception) {
            Log.d("uploadProject", "${e.message}")
            return UploadResult.Error(e.message ?: "Unknown error")
        }
    }

    private fun createFilePart(
        fileUri: Uri,
        partName: String = "file",
        fileName: String = "uploaded_file"
    ): MultipartBody.Part {
        val contentResolver = context.contentResolver
        val mimeType = contentResolver.getType(fileUri) ?: "application/octet-stream"
        Log.d("createFilePart", mimeType)
        Log.d("createFileName", fileName)

        val bytes = try {
            context.contentResolver.openInputStream(fileUri)?.readBytes()
                ?: throw IOException("Не удалось открыть поток для URI: $fileUri")
        } catch (e: Exception) {
            throw IOException("Ошибка чтения файла: ${e.message}", e)
        }

        val requestBody = bytes.toRequestBody(mimeType.toMediaTypeOrNull())
        return MultipartBody.Part.createFormData(partName, fileName, requestBody)
    }

    private fun createImagePartFromDrawable(
        drawableResId: Int,
        partName: String = "src",
        fileName: String = "image.png"
    ): MultipartBody.Part {
        val bitmap: Bitmap = BitmapFactory.decodeResource(context.resources, drawableResId)
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        val imageBytes = outputStream.toByteArray()
        val requestBody = imageBytes.toRequestBody("image/png".toMediaTypeOrNull())

        return MultipartBody.Part.createFormData(partName, fileName, requestBody)
    }

    companion object {
        private const val MIME_TEXT = "text/plain"
    }

}