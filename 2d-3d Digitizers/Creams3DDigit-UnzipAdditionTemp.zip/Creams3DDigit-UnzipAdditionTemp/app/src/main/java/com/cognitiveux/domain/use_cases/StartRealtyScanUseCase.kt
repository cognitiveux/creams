package com.cognitiveux.domain.use_cases

import com.cognitiveux.domain.repositories.StarterRepository
import javax.inject.Inject

class StartRealtyScanUseCase @Inject constructor(
    private val repository: StarterRepository
) {

    operator fun invoke() = repository.startRealtyScan()

}