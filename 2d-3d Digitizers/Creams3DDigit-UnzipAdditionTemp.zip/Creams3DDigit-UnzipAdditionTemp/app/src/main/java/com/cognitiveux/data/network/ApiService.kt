package com.cognitiveux.data.network

import com.cognitiveux.data.db.payload.requests.LoginRequestDto
import com.cognitiveux.data.db.payload.responses.CreateArtResponse
import com.cognitiveux.data.db.payload.responses.LoginResponseDto
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {

    @POST(LOGIN_URL)
    suspend fun login(
        @Body login: LoginRequestDto
    ): LoginResponseDto

    @Multipart
    @POST(CREATE_ARTWORK)
    suspend fun createArt(
        @Header("Authorization") token: String,
        @Header("Cookie") cookie: String,
        @Part src: MultipartBody.Part,
        @Part("name") name: RequestBody,
        @Part("art_type") artType: RequestBody,
        @Part("genre") genre: RequestBody
    ): CreateArtResponse

    @Multipart
    @POST(UPLOAD_FILE)
    suspend fun uploadFile(
        @Header("Authorization") token: String,
        @Header("Cookie") cookie: String,
        @Part file: MultipartBody.Part,
        @Part("artwork_id") artworkId: RequestBody,
        @Part("save_art_type") saveArtType: RequestBody,
    ): Response<ResponseBody>


    companion object {
        const val LOGIN_URL = "account-mgmt/login/"
        const val CREATE_ARTWORK = "artworks/create/"
        const val UPLOAD_FILE = "student/artwork/save_associated_media/"
    }

}