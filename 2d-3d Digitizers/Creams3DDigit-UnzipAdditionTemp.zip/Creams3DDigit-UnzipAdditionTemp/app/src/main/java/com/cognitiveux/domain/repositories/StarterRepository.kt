package com.cognitiveux.domain.repositories

interface StarterRepository {

    fun startRealtyScan()

}