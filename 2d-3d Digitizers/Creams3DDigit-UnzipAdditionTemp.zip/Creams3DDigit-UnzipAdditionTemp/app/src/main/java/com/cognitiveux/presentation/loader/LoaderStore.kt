package com.cognitiveux.presentation.loader

import android.net.Uri
import com.arkivanov.mvikotlin.core.store.Reducer
import com.arkivanov.mvikotlin.core.store.Store
import com.arkivanov.mvikotlin.core.store.StoreFactory
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineBootstrapper
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineExecutor
import com.cognitiveux.data.states.UploadResult
import com.cognitiveux.domain.use_cases.UploadProjectUseCase
import com.cognitiveux.presentation.loader.LoaderStore.Intent
import com.cognitiveux.presentation.loader.LoaderStore.Label
import com.cognitiveux.presentation.loader.LoaderStore.State
import com.cognitiveux.presentation.loader.LoaderStoreFactory.Msg.ErrorLoadAll
import com.cognitiveux.presentation.loader.LoaderStoreFactory.Msg.LoadingAll
import com.cognitiveux.presentation.loader.LoaderStoreFactory.Msg.SuccessLoad
import com.cognitiveux.presentation.loader.LoaderStoreFactory.Msg.UploadAll
import kotlinx.coroutines.launch
import javax.inject.Inject

interface LoaderStore : Store<Intent, State, Label> {

    sealed interface Intent {
        data class Upload(val uris: List<Uri>, val name: String) : Intent
        data class ChangeNameAll(val uris: List<Uri>, val name: String) : Intent
        data class SelectLogo(val uri: Uri) : Intent
    }

    data class State(
        val state: LoaderState = LoaderState.Initial
    ) {

        sealed interface LoaderState {
            data object Initial : LoaderState
            data object SuccessLoad : LoaderState
            data class LoadingAll(
                val uris: List<Uri>,
                val name: String,
                val logoUri: Uri? = null
            ) : LoaderState

            data class UploadAll(
                val uris: List<Uri>,
                val name: String,
                val logoUri: Uri? = null
            ) : LoaderState

            data class ErrorLoadAll(
                val uris: List<Uri>,
                val name: String,
                val message: String,
                val logoUri: Uri? = null
            ) : LoaderState
        }
    }

    sealed interface Label {}
}

class LoaderStoreFactory @Inject constructor(
    private val storeFactory: StoreFactory,
    private val uploadProjectUseCase: UploadProjectUseCase
) {

    fun create(uris: List<Uri>): LoaderStore =
        object : LoaderStore, Store<Intent, State, Label> by storeFactory.create(
            name = "LoaderStore",
            initialState = State(),
            bootstrapper = BootstrapperImpl(uris),
            executorFactory = ::ExecutorImpl,
            reducer = ReducerImpl
        ) {}

    private sealed interface Action {
        data class UploadAll(val uris: List<Uri>, val name: String, val logoUri: Uri? = null) :
            Action
    }

    private sealed interface Msg {
        data object SuccessLoad : Msg
        data class LoadingAll(
            val uris: List<Uri>,
            val name: String,
            val logoUri: Uri? = null
        ) : Msg

        data class UploadAll(
            val uris: List<Uri>,
            val name: String,
            val logoUri: Uri? = null
        ) : Msg

        data class ErrorLoadAll(
            val uris: List<Uri>,
            val name: String,
            val message: String,
            val logoUri: Uri? = null
        ) : Msg
    }

    private inner class BootstrapperImpl(
        private val uris: List<Uri>
    ) : CoroutineBootstrapper<Action>() {
        override fun invoke() {
            dispatch(Action.UploadAll(uris = uris, name = "", logoUri = null))
        }
    }

    private inner class ExecutorImpl : CoroutineExecutor<Intent, Action, State, Msg, Label>() {
        override fun executeIntent(intent: Intent, getState: () -> State) {
            when (intent) {
                is Intent.Upload -> {
                    val currentState = getState()
                    val logoUri = when (val state = currentState.state) {
                        is State.LoaderState.UploadAll -> state.logoUri
                        is State.LoaderState.LoadingAll -> state.logoUri
                        is State.LoaderState.ErrorLoadAll -> state.logoUri
                        else -> null
                    }
                    dispatch(LoadingAll(intent.uris, intent.name, logoUri))
                    scope.launch {
                        when (val result = uploadProjectUseCase(
                            uris = intent.uris,
                            name = intent.name,
                            logoUri = logoUri
                        )) {
                            is UploadResult.Error -> dispatch(
                                ErrorLoadAll(
                                    intent.uris,
                                    intent.name,
                                    result.message,
                                    logoUri
                                )
                            )

                            UploadResult.ErrorAuth -> dispatch(
                                ErrorLoadAll(
                                    intent.uris,
                                    intent.name,
                                    "Auth Error",
                                    logoUri
                                )
                            )

                            UploadResult.Success -> dispatch(SuccessLoad)
                        }
                    }
                }

                is Intent.ChangeNameAll -> {
                    val currentState = getState()
                    val logoUri = when (val state = currentState.state) {
                        is State.LoaderState.UploadAll -> state.logoUri
                        is State.LoaderState.LoadingAll -> state.logoUri
                        is State.LoaderState.ErrorLoadAll -> state.logoUri
                        else -> null
                    }
                    dispatch(UploadAll(intent.uris, intent.name, logoUri))
                }

                is Intent.SelectLogo -> {
                    println("Debug: SelectLogo intent received with URI: ${intent.uri}")
                    val currentState = getState()
                    when (val state = currentState.state) {
                        is State.LoaderState.UploadAll -> {
                            println("Debug: Updating UploadAll state with logo URI")
                            dispatch(UploadAll(state.uris, state.name, intent.uri))
                        }

                        is State.LoaderState.LoadingAll -> {
                            println("Debug: Updating LoadingAll state with logo URI")
                            dispatch(LoadingAll(state.uris, state.name, intent.uri))
                        }

                        is State.LoaderState.ErrorLoadAll -> {
                            println("Debug: Updating ErrorLoadAll state with logo URI")
                            dispatch(
                                ErrorLoadAll(
                                    state.uris,
                                    state.name,
                                    state.message,
                                    intent.uri
                                )
                            )
                        }

                        else -> {
                            println("Debug: Logo selection in unexpected state: ${currentState.state}")
                        } // Handle other states if needed
                    }
                }
            }
        }

        override fun executeAction(action: Action, getState: () -> State) {
            when (action) {
                is Action.UploadAll -> dispatch(UploadAll(action.uris, action.name, action.logoUri))
            }
        }
    }

    private object ReducerImpl : Reducer<State, Msg> {
        override fun State.reduce(msg: Msg): State =
            when (msg) {
                is ErrorLoadAll -> copy(
                    state = State.LoaderState.ErrorLoadAll(
                        uris = msg.uris,
                        name = msg.name,
                        message = msg.message,
                        logoUri = msg.logoUri
                    )
                )

                is LoadingAll -> copy(
                    state = State.LoaderState.LoadingAll(
                        uris = msg.uris,
                        name = msg.name,
                        logoUri = msg.logoUri
                    )
                )

                is UploadAll -> copy(
                    state = State.LoaderState.UploadAll(
                        uris = msg.uris,
                        name = msg.name,
                        logoUri = msg.logoUri
                    )
                )

                SuccessLoad -> copy(state = State.LoaderState.SuccessLoad)
            }
    }
}
