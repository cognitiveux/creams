package com.cognitiveux.presentation.root

import android.net.Uri
import com.arkivanov.decompose.router.stack.ChildStack
import com.arkivanov.decompose.value.Value
import com.cognitiveux.presentation.loader.LoaderComponent
import com.cognitiveux.presentation.login.LoginComponent
import com.cognitiveux.presentation.starter.StarterComponent

interface RootComponent {

    val stack: Value<ChildStack<*, Child>>

    fun fileProcessed(uri: Uri, name: String, size: Long)
    fun logout()

    sealed interface Child {

        data class Login(val component: LoginComponent) : Child
        data class Loader(val component: LoaderComponent) : Child
        data class Starter(val component: StarterComponent) : Child

    }

}