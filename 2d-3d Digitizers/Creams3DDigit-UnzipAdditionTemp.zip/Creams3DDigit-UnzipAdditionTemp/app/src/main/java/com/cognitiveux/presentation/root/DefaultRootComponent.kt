package com.cognitiveux.presentation.root

import android.net.Uri
import android.os.Parcelable
import androidx.core.net.toUri
import com.arkivanov.decompose.ComponentContext
import com.arkivanov.decompose.router.stack.ChildStack
import com.arkivanov.decompose.router.stack.StackNavigation
import com.arkivanov.decompose.router.stack.childStack
import com.arkivanov.decompose.router.stack.replaceAll
import com.arkivanov.decompose.value.Value
import com.cognitiveux.data.extensions.componentScope
import com.cognitiveux.domain.use_cases.LogoutUseCase
import com.cognitiveux.domain.use_cases.UnzipProjectUseCase
import com.cognitiveux.domain.use_cases.UnzipResult
import com.cognitiveux.presentation.loader.DefaultLoaderComponent
import com.cognitiveux.presentation.login.DefaultLoginComponent
import com.cognitiveux.presentation.starter.DefaultStarterComponent
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.launch
import kotlinx.parcelize.Parcelize

class DefaultRootComponent @AssistedInject constructor(
    @Assisted("componentContext") componentContext: ComponentContext,
    private val loginFactory: DefaultLoginComponent.Factory,
    private val logoutUseCase: LogoutUseCase,
    private val loaderFactory: DefaultLoaderComponent.Factory,
    private val starterFactory: DefaultStarterComponent.Factory,
    private val unzipProjectUseCase: UnzipProjectUseCase
) : RootComponent, ComponentContext by componentContext {

    private val navigation = StackNavigation<Config>()

    override val stack: Value<ChildStack<*, RootComponent.Child>> = childStack(
        source = navigation,
        initialConfiguration = Config.Login,
        handleBackButton = true,
        childFactory = ::child
    )

    override fun fileProcessed(uri: Uri, name: String, size: Long) {
        val scope = componentScope()

        scope.launch {
            if (uri.toString().endsWith(".zip")) {
                when (val result = unzipProjectUseCase(uri)) {
                    is UnzipResult.Success -> {
                        result.files.forEach {
                            navigation.replaceAll(
                                Config.Loader(
                                    uri = it.toUri(),
                                    name = "",
                                    size = it.length(),
                                    uris = result.files.map { file -> file.toUri() }
                                )
                            )
                        }
                    }

                    is UnzipResult.Error -> {
                        navigation.replaceAll(
                            Config.Loader(
                                uri = uri,
                                name = "Error: ${result.message}",
                                size = size
                            )
                        )
                    }
                }
            } else {
                navigation.replaceAll(Config.Loader(uri, "", size))
            }
        }
    }

    override fun logout() {
        logoutUseCase()
        navigation.replaceAll(Config.Login)
    }

    private fun child(
        config: Config,
        componentContext: ComponentContext
    ): RootComponent.Child {
        return when (config) {
            Config.Login -> {
                val component = loginFactory.create(
                    componentContext = componentContext,
                    onLoginSuccess = {
                        navigation.replaceAll(Config.Starter)
                    }
                )
                RootComponent.Child.Login(component)
            }

            is Config.Loader -> {
                val component = loaderFactory.create(
                    componentContext,
                    uris = config.uris,
                )
                RootComponent.Child.Loader(component)
            }

            Config.Starter -> {
                val component = starterFactory.create(componentContext)
                RootComponent.Child.Starter(component)
            }
        }
    }

    sealed interface Config : Parcelable {
        @Parcelize
        data object Login : Config

        @Parcelize
        data class Loader(
            val uri: Uri,
            val name: String,
            val size: Long,
            val uris: List<Uri> = emptyList(),
        ) : Config

        @Parcelize
        data object Starter : Config
    }

    @AssistedFactory
    interface Factory {
        fun create(
            @Assisted("componentContext") componentContext: ComponentContext
        ): DefaultRootComponent
    }
}