package com.cognitiveux.data.db.payload.responses

import com.google.gson.annotations.SerializedName

data class CreateArtResponse(
    @SerializedName("resource_id")
    val resourceId: Int
)
