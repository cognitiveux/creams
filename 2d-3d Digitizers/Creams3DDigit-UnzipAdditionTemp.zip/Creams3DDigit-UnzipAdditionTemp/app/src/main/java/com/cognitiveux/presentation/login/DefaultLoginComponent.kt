package com.cognitiveux.presentation.login

import android.util.Log
import com.arkivanov.decompose.ComponentContext
import com.arkivanov.mvikotlin.core.instancekeeper.getStore
import com.arkivanov.mvikotlin.extensions.coroutines.labels
import com.arkivanov.mvikotlin.extensions.coroutines.stateFlow
import com.cognitiveux.data.extensions.componentScope
import dagger.assisted.Assisted
import dagger.assisted.AssistedFactory
import dagger.assisted.AssistedInject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DefaultLoginComponent @AssistedInject constructor(
    private val loginStoreFactory: LoginStoreFactory,
    @Assisted("componentContext") componentContext: ComponentContext,
    @Assisted("onLoginSuccess") val onLoginSuccess: () -> Unit
) : LoginComponent, ComponentContext by componentContext {

    private val store = instanceKeeper.getStore { loginStoreFactory.create() }
    private val scope = componentScope()

    @OptIn(ExperimentalCoroutinesApi::class)
    override val model: StateFlow<LoginStore.State> = store.stateFlow

    init {
        scope.launch {
            store.labels.collect {
                when (it) {
                    LoginStore.Label.SuccessLogin -> {
                        Log.d("LoginComponentLabel", "SuccessLogin")
                        onLoginSuccess()
                    }
                }
            }
        }
    }

    override fun onClickLogin(email: String, password: String) {
        store.accept(LoginStore.Intent.ClickLogin(email, password))
    }

    @AssistedFactory
    interface Factory {
        fun create(
            @Assisted("componentContext") componentContext: ComponentContext,
            @Assisted("onLoginSuccess") onLoginSuccess: () -> Unit
        ): DefaultLoginComponent
    }

}