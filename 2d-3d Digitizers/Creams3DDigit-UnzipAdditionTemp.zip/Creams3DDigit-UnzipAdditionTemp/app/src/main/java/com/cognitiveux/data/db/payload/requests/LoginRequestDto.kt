package com.cognitiveux.data.db.payload.requests

data class LoginRequestDto(
    val email: String,
    val password: String
)
