package com.cognitiveux.di

import android.content.Context
import com.cognitiveux.data.db.DataBase
import com.cognitiveux.data.db.DataBaseDao
import com.cognitiveux.data.impls.LoaderRepositoryImpl
import com.cognitiveux.data.impls.StarterRepositoryImpl
import com.cognitiveux.data.impls.UsersRepositoryImpl
import com.cognitiveux.data.network.ApiFactory
import com.cognitiveux.data.network.ApiService
import com.cognitiveux.domain.repositories.LoaderRepository
import com.cognitiveux.domain.repositories.StarterRepository
import com.cognitiveux.domain.repositories.UsersRepository
import com.cognitiveux.domain.use_cases.UnzipProjectUseCase
import dagger.Binds
import dagger.Module
import dagger.Provides

@Module
interface DataModule {

    @[ApplicationScope Binds]
    fun bindUsersRepository(impl: UsersRepositoryImpl): UsersRepository

    @[ApplicationScope Binds]
    fun bindStarterRepository(impl: StarterRepositoryImpl): StarterRepository

    @[ApplicationScope Binds]
    fun bindLoaderRepository(impl: LoaderRepositoryImpl): LoaderRepository

    companion object {

        @[ApplicationScope Provides]
        fun provideResultsDao(database: DataBase): DataBaseDao {
            return database.dbDao()
        }

        @[ApplicationScope Provides]
        fun provideApiService(): ApiService = ApiFactory.apiService


        @[ApplicationScope Provides]
        fun provideUnzipProjectUseCase(context: Context): UnzipProjectUseCase {
            return UnzipProjectUseCase(context)
        }

    }

}