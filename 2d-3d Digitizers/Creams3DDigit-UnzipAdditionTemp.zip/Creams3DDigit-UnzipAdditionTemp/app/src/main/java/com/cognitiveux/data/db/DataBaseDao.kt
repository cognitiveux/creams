package com.cognitiveux.data.db

import androidx.room.Dao

@Dao
interface DataBaseDao {
}