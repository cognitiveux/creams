package com.cognitiveux.domain.repositories

import android.net.Uri
import com.cognitiveux.data.states.UploadResult

interface LoaderRepository {

    suspend fun uploadProjectMultipleUri(uris: List<Uri>, name: String, logoUri: Uri?): UploadResult

}