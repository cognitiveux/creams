package com.cognitiveux.presentation.loader

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cognitiveux.R
import com.cognitiveux.presentation.loader.models.LoadScreenAll

@Composable
fun LoaderContent(component: LoaderComponent) {
    val state by component.model.collectAsState()

    // Image picker launcher
    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { component.onLogoSelected(it) }
    }

    when (val item = state.state) {

        LoaderStore.State.LoaderState.Initial -> {}

        LoaderStore.State.LoaderState.SuccessLoad -> {
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                Image(
                    painter = painterResource(id = R.drawable.mnemosyne_background2),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
                Image(
                    painter = painterResource(id = R.drawable.lab_logo_1),
                    contentDescription = "Corner Logo",
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(100.dp)
                        .padding(16.dp),
                    contentScale = ContentScale.Fit
                )
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val textSuccess = remember { "Files successfully uploaded!" }

                    Text(
                        text = textSuccess,
                        color = Color.Magenta,
                        fontSize = 24.sp,
                        modifier = Modifier
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }

        is LoaderStore.State.LoaderState.ErrorLoadAll -> {
            LoadScreenAll(
                name = item.name,
                uris = item.uris,
                logoUri = item.logoUri,
                nameChange = component::changeNameAll,
                onLogoSelected = {
                    logoPickerLauncher.launch("image/*")
                },
                onClickLoad = component::onClickLoadAll,
                isClickable = true,
                isLoad = false,
                error = item.message
            )
        }

        is LoaderStore.State.LoaderState.LoadingAll -> {
            LoadScreenAll(
                name = item.name,
                uris = item.uris,
                logoUri = item.logoUri,
                nameChange = component::changeNameAll,
                onLogoSelected = {
                    logoPickerLauncher.launch("image/*")
                },
                onClickLoad = component::onClickLoadAll,
                isClickable = false,
                isLoad = true,
                error = null
            )
        }

        is LoaderStore.State.LoaderState.UploadAll -> {
            LoadScreenAll(
                name = item.name,
                uris = item.uris,
                logoUri = item.logoUri,
                nameChange = component::changeNameAll,
                onLogoSelected = {
                    logoPickerLauncher.launch("image/*")
                },
                onClickLoad = component::onClickLoadAll,
                isClickable = true,
                isLoad = false,
                error = null
            )
        }
    }
}

