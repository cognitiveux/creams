package com.cognitiveux.domain.repositories

import com.cognitiveux.data.states.LoginResult

interface UsersRepository {

    suspend fun login(email: String, password: String): LoginResult
    fun logout()
    fun checkAuth(): LoginResult
    fun saveToken(accessToken: String, refreshToken: String)
    fun getToken(): LoginResult

}