package com.cognitiveux.data.db.payload.responses

import com.google.gson.annotations.SerializedName

data class LoginResponseDto(
    @SerializedName("message")
    val message: String?,
    @SerializedName("resource_obj")
    val token: TokenObjectDto?
)