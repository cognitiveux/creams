package com.cognitiveux

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.arkivanov.decompose.defaultComponentContext
import com.cognitiveux.di.Creams3DDigit
import com.cognitiveux.presentation.root.DefaultRootComponent
import com.cognitiveux.presentation.root.RootComponent
import javax.inject.Inject

class MainActivity : ComponentActivity() {

    @Inject
    lateinit var rootComponentFactory: DefaultRootComponent.Factory
    private lateinit var component: DefaultRootComponent

    override fun onCreate(savedInstanceState: Bundle?) {
        (applicationContext as Creams3DDigit).applicationComponent.inject(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        component = rootComponentFactory.create(defaultComponentContext())
        handleIncomingIntent(intent, component)
        setContent {
            RootComponent(component = component)
        }
    }

    private fun handleIncomingIntent(intent: Intent?, component: RootComponent) {
        if (intent == null) return

        when (intent.action) {
            Intent.ACTION_SEND -> {
                val fileUri: Uri? =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(Intent.EXTRA_STREAM)
                    }

                fileUri?.let { uri ->
                    val resolver = contentResolver
                    resolver.query(uri, null, null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) { // Перемещаем курсор на первую строку
                            val nameIndex =
                                cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                            val sizeIndex =
                                cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)

                            val name =
                                if (nameIndex != -1) cursor.getString(nameIndex) else "unknown.zip"
                            val size =
                                if (sizeIndex != -1) cursor.getLong(sizeIndex) else 0L

                            component.fileProcessed(uri, name, size)
                        }
                    }
                }
            }
        }
    }
}