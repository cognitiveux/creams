package com.cognitiveux.presentation.login

import com.arkivanov.mvikotlin.core.store.Reducer
import com.arkivanov.mvikotlin.core.store.Store
import com.arkivanov.mvikotlin.core.store.StoreFactory
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineBootstrapper
import com.arkivanov.mvikotlin.extensions.coroutines.CoroutineExecutor
import com.cognitiveux.data.states.LoginResult
import com.cognitiveux.domain.use_cases.CheckAuthUseCase
import com.cognitiveux.domain.use_cases.LoginUseCase
import com.cognitiveux.presentation.login.LoginStore.Intent
import com.cognitiveux.presentation.login.LoginStore.Label
import com.cognitiveux.presentation.login.LoginStore.State
import kotlinx.coroutines.launch
import javax.inject.Inject

interface LoginStore : Store<Intent, State, Label> {

    sealed interface Intent {
        data class ClickLogin(val email: String, val password: String) : Intent
    }

    data class State(
        val state: LoginState = LoginState.Initial
    ) {
        sealed interface LoginState {

            data object Initial : LoginState
            data object LoginForm : LoginState
            data object Loading : LoginState
            data class Error(val message: String) : LoginState

        }
    }

    sealed interface Label {
        data object SuccessLogin : Label
    }
}

class LoginStoreFactory @Inject constructor(
    private val storeFactory: StoreFactory,
    private val loginUseCase: LoginUseCase,
    private val checkAuthUseCase: CheckAuthUseCase
) {

    fun create(): LoginStore =
        object : LoginStore, Store<Intent, State, Label> by storeFactory.create(
            name = "LoginStore",
            initialState = State(),
            bootstrapper = BootstrapperImpl(),
            executorFactory = ::ExecutorImpl,
            reducer = ReducerImpl
        ) {}

    private sealed interface Action {

        data object Loading : Action
        data object LoginForm : Action
        data object SuccessLogin : Action
        data class ErrorLogin(val message: String) : Action

    }

    private sealed interface Msg {

        data object Loading : Msg
        data object LoginForm : Msg
        data class ErrorLogin(val message: String) : Msg

    }

    private inner class BootstrapperImpl : CoroutineBootstrapper<Action>() {
        override fun invoke() {
            val auth = checkAuthUseCase()
            if (auth is LoginResult.Success) {
                dispatch(Action.SuccessLogin)
            } else {
                dispatch(Action.LoginForm)
            }
        }
    }

    private inner class ExecutorImpl : CoroutineExecutor<Intent, Action, State, Msg, Label>() {
        override fun executeIntent(intent: Intent, getState: () -> State) {
            when (intent) {
                is Intent.ClickLogin -> {
                    dispatch(Msg.Loading)
                    scope.launch {
                        when (val result = loginUseCase(intent.email, intent.password)) {
                            is LoginResult.Error -> {
                                dispatch(Msg.ErrorLogin(result.message))
                            }

                            LoginResult.Success -> {
                                publish(Label.SuccessLogin)
                            }

                            else -> {
                                dispatch(Msg.ErrorLogin("Unknown error"))
                            }
                        }
                    }
                }
            }
        }

        override fun executeAction(action: Action, getState: () -> State) {
            when (action) {
                Action.Loading -> {
                    dispatch(Msg.Loading)
                }

                is Action.ErrorLogin -> {
                    dispatch(Msg.ErrorLogin(action.message))
                }

                Action.LoginForm -> {
                    dispatch(Msg.LoginForm)
                }

                Action.SuccessLogin -> {
                    scope.launch {
                        publish(Label.SuccessLogin)
                    }
                }
            }

        }
    }

    private object ReducerImpl : Reducer<State, Msg> {
        override fun State.reduce(msg: Msg): State =
            when (msg) {
                is Msg.ErrorLogin -> {
                    copy(state = State.LoginState.Error(msg.message))
                }

                Msg.Loading -> {
                    copy(state = State.LoginState.Loading)
                }

                Msg.LoginForm -> {
                    copy(state = State.LoginState.LoginForm)
                }
            }
    }
}
