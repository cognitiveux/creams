package com.cognitiveux.data.impls

import android.content.Context
import com.cognitiveux.data.db.payload.requests.LoginRequestDto
import com.cognitiveux.data.network.ApiService
import com.cognitiveux.data.states.LoginResult
import com.cognitiveux.domain.repositories.UsersRepository
import javax.inject.Inject

class UsersRepositoryImpl @Inject constructor(
    private val apiService: ApiService,
    context: Context
) : UsersRepository {

    private val sharedPrefs = context.getSharedPreferences(SHARED_PRESENCES, Context.MODE_PRIVATE)

    override suspend fun login(email: String, password: String): LoginResult {
        return when {
            email.isEmpty() -> LoginResult.Error("Email is empty")
            password.isEmpty() -> LoginResult.Error("Password is empty")
            else -> try {
                val response = apiService.login(LoginRequestDto(email, password))
                if (response.token == null) {
                    LoginResult.Error(response.message ?: "Unknown error")
                } else {
                    saveToken(response.token.access, response.token.refresh)
                    LoginResult.Success
                }
            } catch (e: Exception) {
                LoginResult.Error("Network error: ${e.message}")
            }
        }
    }

    override fun logout() {
        sharedPrefs.edit().apply {
            remove(ACCESS_TOKEN)
            remove(REFRESH_TOKEN)
        }.apply()
    }

    override fun checkAuth(): LoginResult {
        val token = sharedPrefs.getString(ACCESS_TOKEN, null)

        return if (token == null) LoginResult.Error("Token not found")
        else LoginResult.Success
    }

    override fun saveToken(accessToken: String, refreshToken: String) {
        sharedPrefs.edit().apply {
            putString(ACCESS_TOKEN, accessToken)
            putString(REFRESH_TOKEN, refreshToken)
        }.apply()
    }

    override fun getToken(): LoginResult {
        val token = sharedPrefs.getString(ACCESS_TOKEN, null)
        val refToken = sharedPrefs.getString(REFRESH_TOKEN, null)

        return if (token == null || refToken == null) LoginResult.Error("Token not found")
        else LoginResult.Token(Pair(token, refToken))
    }

    companion object {

        private const val SHARED_PRESENCES = "app_sp"
        private const val ACCESS_TOKEN = "access_token"
        private const val REFRESH_TOKEN = "refresh_token"

    }
}