package com.cognitiveux.domain.use_cases

import android.net.Uri
import com.cognitiveux.data.states.UploadResult
import com.cognitiveux.domain.repositories.LoaderRepository
import javax.inject.Inject

class UploadProjectUseCase @Inject constructor(
    private val repository: LoaderRepository
) {

    suspend operator fun invoke(uris: List<Uri>, name: String, logoUri: Uri? = null): UploadResult =
        repository.uploadProjectMultipleUri(
            uris, name,
            logoUri = logoUri
        )

}