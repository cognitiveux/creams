package com.cognitiveux.data.states

sealed class UploadResult {

    data object Success : UploadResult()
    data class Error(val message: String) : UploadResult()
    data object ErrorAuth : UploadResult()

}