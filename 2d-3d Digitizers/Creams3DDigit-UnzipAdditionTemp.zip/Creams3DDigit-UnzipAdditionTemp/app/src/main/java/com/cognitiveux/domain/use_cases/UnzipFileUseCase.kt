package com.cognitiveux.domain.use_cases

import android.content.Context
import android.net.Uri
import com.cognitiveux.di.ApplicationScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream
import javax.inject.Inject

sealed interface UnzipResult {
    data class Success(val files: List<File>) : UnzipResult
    data class Error(val message: String) : UnzipResult
}

@ApplicationScope
class UnzipProjectUseCase @Inject constructor(
    private val context: Context
) {
    suspend operator fun invoke(uri: Uri): UnzipResult = withContext(Dispatchers.IO) {
        try {
            val files = unzip(uri)
            UnzipResult.Success(files)
        } catch (e: Exception) {
            UnzipResult.Error("Error unzipping file: ${e.message}")
        }
    }

    private fun unzip(uri: Uri): List<File> {
        val contentResolver = context.contentResolver
        val cacheDir = context.cacheDir

        contentResolver.openInputStream(uri)?.use { inputStream ->
            ZipInputStream(BufferedInputStream(inputStream)).use { zipInputStream ->
                val files = mutableListOf<File>()

                generateSequence { zipInputStream.nextEntry }
                    .forEach { zipEntry ->
                        val file = File(cacheDir, zipEntry.name)

                        when {
                            zipEntry.isDirectory -> file.mkdirs()
                            else -> {
                                file.parentFile?.mkdirs()

                                BufferedOutputStream(FileOutputStream(file)).use { outputStream ->
                                    zipInputStream.copyTo(outputStream)
                                }

                                files.add(file)
                            }
                        }
                    }

                return files
            }
        } ?: throw IllegalStateException("Could not open input stream for URI: $uri")
    }
}