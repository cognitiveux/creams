package com.cognitiveux.domain.use_cases

import com.cognitiveux.data.states.LoginResult
import com.cognitiveux.domain.repositories.UsersRepository
import javax.inject.Inject

class TokenUseCase @Inject constructor(
    private val repository: UsersRepository
) {

    operator fun invoke(): LoginResult = repository.getToken()

}