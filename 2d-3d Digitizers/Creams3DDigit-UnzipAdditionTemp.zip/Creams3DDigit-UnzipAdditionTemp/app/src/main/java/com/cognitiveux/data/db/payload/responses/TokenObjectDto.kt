package com.cognitiveux.data.db.payload.responses

import com.google.gson.annotations.SerializedName

data class TokenObjectDto(
    @SerializedName("access")
    val access: String,
    @SerializedName("refresh")
    val refresh: String
)
