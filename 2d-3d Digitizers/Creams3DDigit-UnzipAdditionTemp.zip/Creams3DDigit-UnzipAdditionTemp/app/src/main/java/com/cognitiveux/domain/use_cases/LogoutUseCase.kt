package com.cognitiveux.domain.use_cases

import com.cognitiveux.domain.repositories.UsersRepository
import javax.inject.Inject

class LogoutUseCase @Inject constructor(
    private val repository: UsersRepository
) {
    operator fun invoke() {
        repository.logout()
    }
}