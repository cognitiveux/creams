package com.cognitiveux.presentation.starter

import kotlinx.coroutines.flow.StateFlow

interface StarterComponent {

    val model: StateFlow<StarterStore.State>

    fun onClickStartApp()

}