package com.cognitiveux.presentation.root

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.arkivanov.decompose.extensions.compose.jetpack.stack.Children
import com.cognitiveux.presentation.loader.LoaderContent
import com.cognitiveux.presentation.login.LoginContent
import com.cognitiveux.presentation.root.models.CreamsTopAppBar
import com.cognitiveux.presentation.starter.StarterContent

@Composable
fun RootComponent(component: RootComponent) {
    Children(
        stack = component.stack
    ) {
        val instance = it.instance
        Scaffold(
            topBar = {
                CreamsTopAppBar(
                    instance,
                    logout = component::logout
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center,
            ) {
                when (instance) {
                    is RootComponent.Child.Login -> {
                        LoginContent(instance.component)
                    }

                    is RootComponent.Child.Loader -> {
                        LoaderContent(instance.component)
                    }

                    is RootComponent.Child.Starter -> {
                        StarterContent(instance.component)
                    }
                }
            }
        }
    }
}
