package com.cognitiveux.presentation.loader.models

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import androidx.core.net.toUri
import coil.compose.AsyncImage
import com.cognitiveux.R

@Composable
fun LoadScreenAll(
    name: String,
    uris: List<Uri>,
    logoUri: Uri?,
    nameChange: (List<Uri>, String) -> Unit,
    onLogoSelected: (Uri) -> Unit,
    onClickLoad: (List<Uri>, String) -> Unit,
    isClickable: Boolean,
    isLoad: Boolean,
    error: String?
) {
    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.mnemosyne_background2),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.FillBounds
        )
        Image(
            painter = painterResource(id = R.drawable.lab_logo_1),
            contentDescription = "Corner Logo",
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(100.dp)
                .padding(16.dp),
            contentScale = ContentScale.Fit
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // File names display
            Text(
                text = "Selected Files:",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            uris.forEach { uri ->
                Text(
                    text = uri.lastPathSegment ?: "Unknown file",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Logo selection
            Button(
                onClick = {
                    onLogoSelected(logoUri ?: Uri.EMPTY)
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = if (logoUri == null) "Select Logo" else "Change Logo")
            }

            if (logoUri != null) {
                AsyncImage(
                    model = logoUri,
                    contentDescription = "Selected Logo",
                    modifier = Modifier
                        .size(100.dp)
                        .padding(8.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Art name input
            OutlinedTextField(
                value = name,
                onValueChange = { nameChange(uris, it) },
                label = { Text("Art Name") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            Button(
                onClick = { onClickLoad(uris, name) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                enabled = isClickable && name.isNotBlank()
            ) {
                if (isLoad) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Upload")
                }
            }

            if (error != null) {
                Text(
                    text = error,
                    color = Color.Red,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }
    }
}

data class LoadScreenPreviewState(
    val name: String,
    val uri: Uri,
    val isClickable: Boolean,
    val isLoad: Boolean,
    val error: String?
)

class LoadScreenPreviewProvider : PreviewParameterProvider<LoadScreenPreviewState> {
    override val values = sequenceOf(
        LoadScreenPreviewState(
            name = "My Artwork",
            uri = "content://media/external/images/1".toUri(),
            isClickable = true,
            isLoad = false,
            error = null
        ),
        LoadScreenPreviewState(
            name = "",
            uri = "content://media/external/images/1".toUri(),
            isClickable = false,
            isLoad = true,
            error = "Error uploading artwork"
        )
    )

}

@Preview(showBackground = true)
@Composable
fun LoadScreenPreview(
    @PreviewParameter(LoadScreenPreviewProvider::class) state: LoadScreenPreviewState
) {
    LoadScreenAll(
        name = "",
        uris = listOf(state.uri),
        nameChange = { _, _ -> },
        onClickLoad = { _, _ -> },
        onLogoSelected = {},
        isClickable = state.isClickable,
        isLoad = state.isLoad,
        error = state.error,
        logoUri = "content://media/external/images/2".toUri()
    )
}