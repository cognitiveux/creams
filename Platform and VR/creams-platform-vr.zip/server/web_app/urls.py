from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.decorators import login_required
from django.urls import include, path, re_path
from drf_yasg import openapi
from drf_yasg.views import get_schema_view
from rest_framework import permissions

from . import views
from . import views_artworks
from . import views_account
from . import views_teacher
from . import views_teacher_pages
from . import views_student_pages
from . import views_artist_pages
from . import views_functional_pages
from . import views_visitor
from . import views_audio
from . import views_video
from . import views_exhibitions
from . import views_assessment
from . import views_chat
from . import views_admin_pages

# Create the schema view for the API documentation
schema_view = get_schema_view(
	openapi.Info(
		title="CREAMS API",
		default_version='v2',
		description="The endpoints for interacting with the CREAMS server",
		terms_of_service="http://www.creams-project.eu/",
		contact=openapi.Contact(email="admin@cognitiveux.com"),
		license=openapi.License(name="BSD License"),
	),
	public=True,
	permission_classes=(permissions.AllowAny,),
)

urlpatterns = [
	re_path(r'^demo(?P<format>\.json|\.yaml)/?$', schema_view.without_ui(cache_timeout=0), name='schema-json'),
	re_path(r'^demo/?$', schema_view.with_ui('swagger', cache_timeout=0), name='schema-swagger-ui'),
	re_path(r'^doc/?$', schema_view.with_ui('redoc', cache_timeout=0), name='schema-redoc'),

    # Endpoints 
	# Account Management
	re_path(r'^account-mgmt/activate-account/?$', views_account.AccountMgmtActivateAccount.as_view(), name='account-mgmt/activate-account'),
	re_path(r'^account-mgmt/create-user/?$', views_account.AccountMgmtCreateUser.as_view(), name='account-mgmt/create-user'),
	re_path(r'^account-mgmt/login/?$', views_account.AccountMgmtLogin.as_view(), name='account-mgmt/login'),
	re_path(r'^account-mgmt/logout/?$', views_functional_pages.logout, name='account-mgmt/logout'),
	re_path(r'^account-mgmt/poll-reset-email-status/?$', views_account.AccountMgmtPollResetEmailStatus.as_view(), name='account-mgmt/poll-reset-email-status'),
	re_path(r'^account-mgmt/poll-verification-email-status/?$', views_account.AccountMgmtPollVerificationEmailStatus.as_view(), name='account-mgmt/poll-verification-email-status'),
	re_path(r'^account-mgmt/refresh-token/?$', views_account.AccountMgmtRefreshToken.as_view(), name='account-mgmt/refresh-token'),
	re_path(r'^account-mgmt/request-account-verification-code/?$', views_account.AccountMgmtRequestAccountVerificationCode.as_view(), name='account-mgmt/request-account-verification-code'),
	re_path(r'^account-mgmt/request-password-reset-code/?$', views_account.AccountMgmtRequestPasswordResetCode.as_view(), name='account-mgmt/request-password-reset-code'),
	re_path(r'^account-mgmt/reset-password/?$', views_account.AccountMgmtResetPassword.as_view(), name='account-mgmt/reset-password'),
	re_path(r'^account-mgmt/update-password/?$', views_account.AccountMgmtUpdatePassword.as_view(), name='account-mgmt/update-password'),
    
	# Artworks
	re_path(r'^artworks/details/?$', views_artworks.getArtwork.as_view(), name='getArtwork'),
	re_path(r'^artworks/delete/?$', views_artworks.deleteArtwork.as_view(), name='deleteArtwork'),
	re_path(r'^artworks/update/?$', views_artworks.updateArtwork.as_view(), name='updateArtwork'),
	re_path(r'^artworks/student_list/?$', views_artworks.getStudentsArtworks.as_view(), name='getStudentsArtworks'),
	re_path(r'^artworks/outdoor_list/?$', views_artworks.getAllOutdoorArtworks.as_view(), name='getAllOutdoorArtworks'),
	re_path(r'^artworks/outdoor_list/sorted/?$', views_artworks.getAllOutdoorArtworksSorted.as_view(), name='getAllOutdoorExhibitions'),
	re_path(r'^artworks/create/?$', views_artworks.ArtworkCreate.as_view(), name='artworks/create'),
	re_path(r'^artworks/all/?$', views_artworks.getAllArtworks.as_view(), name='getAllArtworks'),
	re_path(r'^artworks/mr/?$', views_artworks.getMRArtworks.as_view(), name='getMRArtworks'),
	re_path(r'^artworks/associated_media/?$', views_artworks.ArtworkAssociatedMedia.as_view(), name='ArtworkAssociatedMedia'),
	re_path(r'^artworks/study/all/?$', views_artworks.getAllStudyArtworks.as_view(), name='getAllStudyArtworks'),
	re_path(r'^artworks/check_similarity$', views_artworks.ArtworkSimilarity.as_view(), name='artworksCheckSimilarity'),
    
	# Exhibitions
	re_path(r'^exhibitions/outdoor/details/?$', views_exhibitions.getOutdoorExhibition.as_view(), name='getOutdoorExhibition'),
	re_path(r'^exhibitions/outdoor/all/?$', views_exhibitions.getAllOutdoorExhibitions.as_view(), name='getAllOutdoorExhibitions'),
	re_path(r'^exhibitions/indoor/all/?$', views_exhibitions.getAllIndoorExhibitions.as_view(), name='getAllIndoorExhibitions'),
	re_path(r'^exhibitions/outdoor/all/sorted/?$', views_exhibitions.getAllOutdoorExhibitionsSorted.as_view(), name='getAllOutdoorExhibitionsSorted'),
	re_path(r'^exhibitions/outdoor/submit_artwork/?$', views_exhibitions.submitOutdoorArtwork.as_view(), name='submitOutdoorArtwork'),
 	re_path(r'^exhibitions/templates/fetch/?$', views_exhibitions.getVRTemplate.as_view(), name='getVRTemplate'),
 	re_path(r'^exhibitions/templates/fetch/all/?$', views_exhibitions.getAllVRTemplates.as_view(), name='getAllVRTemplates'),
	re_path(r'^exhibitions/indoor/create/vr/?$', views.createVR.as_view(), name="creteVR"),

	re_path(r'^exhibitions/save_exhibition/?$', views_exhibitions.studentSaveExhibition.as_view(),   name='studentSaveExhibition'),
	re_path(r'^exhibitions/delete_vr_exhibition/?$', views_exhibitions.deleteVRExhibition.as_view(),   name='deleteVRExhibition'),

	re_path(r'^exhibitions/mr/all/?$', views_exhibitions.getAllMRExhibitions.as_view(), name='getAllMRExhibitions'),

	# Assignment
 	re_path(r'^assignment/create/?$', views.ExhibitionCreate.as_view(), name='assignment/create'),
 	re_path(r'^assignment/delete/?$', views.deleteAssignment.as_view(), name='assignment/delete'),
 	re_path(r'^assignment/update/?$', views.updateAssignment.as_view(), name='assignment/update'),
 	re_path(r'^assignment/assign_student/?$', views.AssignExhibition.as_view(), name='assignment/assign_student'),
 	re_path(r'^assignment/remove_assigned_student/?$', views.removeStudentAssignmentExhibition.as_view(), name='assignment/remove_assign_student'),
 	re_path(r'^assignment/remove_assigned_instructor/?$', views.removeInstructorAssignmentExhibition.as_view(), name='assignment/remove_assign_instructor'),
 	re_path(r'^assignment/assign_instructors/?$', views.AssignAdvisory.as_view(), name='assignment/assign_instructors'),
 	re_path(r'^assignment/get_list/?$', views_exhibitions.getIndoorExhibitions.as_view(), name='assignment/get_list'),
 	re_path(r'^assignment/get_list/student/?$', views_exhibitions.getIndoorExhibitionsOfStudent.as_view(), name='assignment/get_list/student'),
 	re_path(r'^assignment/assessment/getStudents/?$', views_teacher.getStudentsOfAnAssignment.as_view(), name='assignment/assessment/getStudents'),
	re_path(r'^assignment/assessment/assess/?$', views_assessment.GeneralAssessmentCreate.as_view(),name="GeneralAssessment"),
	re_path(r'^assignment/filter/?$', views.getFilteredExhibitions.as_view(), name="getFilteredExhibitions"),
    
	# Teacher
	re_path(r'^teacher/other_users/?$', views.getAllUsers.as_view(), name="getAllUsers"),
    re_path(r'^teacher/other_users_same_org/?$', views.getAllUsersSameOrg.as_view(), name="getAllUsersSameOrg"),
	re_path(r'^teacher/curatorial/get_group_artworks/?$', 		views_teacher_pages.instructorCuratorialGetGroupArtworks.as_view(),   name='instructorCuratorialGetGroupArtworks'),
	re_path(r'^student/available_instructors/?$', views.getAvailableInstructors.as_view(), name="getAvailableInstructors"),

    # Pages
	re_path(r'^profile/?$', views_functional_pages.profile, name='profile'),
	re_path(r'^user-model/?$', views_functional_pages.user_model, name='user_model'),
	re_path(r'^user_model/update/?$', views_functional_pages.saveUserModel.as_view(), name='saveUserModel'),
    
    # Artist
 	re_path(r'^artist/dashboard/?$', 					views_artist_pages.artistDashboardPage,  					name='artistDashboardPage'),
	re_path(r'^artist/artworks/?$', 						views_artist_pages.artistArtworksPage, 						name='artistArtworksPage'),
	re_path(r'^artist/artwork/new/?$',					views_artist_pages.artistSubmitArtworkPage, 				name='artistSubmitArtworkPage'),
    re_path(r'^artist/artwork/view/?$',					views_artist_pages.artistViewArtworkPage,					name="artistViewArtworkPage"),
    re_path(r'^artist/artwork/edit/?$',					views_artist_pages.artistEditArtworkPage, 					name="artistEditArtworkPage"),
    re_path(r'^artist/audiofiles/?$', 					views_artist_pages.artistAudioFilesPage,      				name='artistAudioFilesPage'),
	re_path(r'^artist/audiofile/new/?$', 				views_artist_pages.artistSubmitAudioFilePage, 				name='artistSubmitAudioFilePage'),
    re_path(r'^artist/videos/?$', 						views_artist_pages.artistVideoFilesPage,      				name='artistVideoFilesPage'),
	re_path(r'^artist/videos/new/?$',	 				views_artist_pages.artistSubmitVideoFilePage, 				name='artistSubmitVideoFilePage'),
	re_path(r'^artist/exhibitions/?$', 					views_artist_pages.artistExhibitionsPage,  					name='artistExhibitionsPage'),
  	re_path(r'^artist/exhibitions/new/?$', 				views_artist_pages.artistInitExhibitionPage, 				name='artistInitExhibitionPage'),
	re_path(r'^artist/exhibition/view/?$', 				views_artist_pages.artistViewExhibitionPage, 				name='artistViewExhibitionPage'),
    re_path(r'^artist/exhibition/edit/?$', 				views_artist_pages.artistEditExhibitionPage, 				name="artistEditExhibitionPage"),
	re_path(r'^artist/exhibition/viewer/$' ,   			views_artist_pages.artistExhibitionViewerPage,				name='artistExhibitionViewerPage'),
    re_path(r'^artist/template_selection/?$', 			views.templateSelectionPagev2, 								name='artistSelectTemplatePage'),
    re_path(r'^artist/editor/?$',  views.editorv2, name='artist/editor'),
    
    # Teacher
 	re_path(r'^teacher/dashboard/?$', 					views_teacher_pages.teacherDashboardPage,  					name='teacherDashboardPage'),
  	re_path(r'^teacher/assessment/?$', 					views_teacher_pages.teacherAssessmentMainPage, 				name='teacherAssessmentMainPage'),
  	re_path(r'^teacher/exhibitions/?$',	 				views_teacher_pages.teacherExhibitionsPage, 				name='teacherExhibitionsPage'),
	re_path(r'^teacher/exhibition/new/?$', 				views_teacher_pages.teacherInitExhibitionPage, 				name='teacherInitExhibitionPage'),
  	#re_path(r'^teacher/exhibition/new/student_list/?$', 	views_teacher_pages.teacherSelectStudentsAndCoadvisorsPage, name='teacherSelectStudentsAndCoadvisorsPage'),
  	#re_path(r'^teacher/assessment/student_list/?$', 		views_teacher_pages.teacherAssessStudentsPage, 				name='teacherAssessStudentsPage'),
  	re_path(r'^teacher/assessment/assess/?$',	 		views_teacher_pages.teacherAssessmentPage, 					name='teacherAssessmentPage'),
    re_path(r'^teacher/exhibition/view/?$', 				views_teacher_pages.teacherViewExhibitionPage, 				name="teacherViewExhibitionPage"),
    re_path(r'^teacher/exhibition/edit/?$', 				views_teacher_pages.teacherEditExhibitionPage, 				name="teacherEditExhibitionPage"),
    re_path(r'^teacher/exhibition/edit/student_list/?$', views_teacher_pages.teacherEditStudentsAndCoadvisorsPage, 	name="teacherEditStudentsAndCoadvisorsPage"),
	re_path(r'^teacher/assess_students/?$', views_teacher_pages.teacherAssessStudentsPage, 	name="teacherAssessStudentsPage"),
    re_path(r'^teacher/communication/?$', 				views_teacher_pages.teacherCommunicationPage,  				name='teacherCommunicationPage'),
	re_path(r'^teacher/curatorial/describe_groups/?$', 		views_teacher_pages.teacherCuratorialDescribeGroupsPage,   name='teacherCuratorialDescribeGroups'),
	re_path(r'^teacher/curatorial/save_group_description/?$', 		views_teacher_pages.instructorCuratorialSaveGroupDescription.as_view(),   name='instructorCuratorialSaveGroupDescription'),
	re_path(r'^teacher/curatorial/final_assessment/?$', 		views_teacher_pages.teacherCuratorialFinalAssessmentPage,   name='instructorCuratorialFinalAssessmentPage'),
	re_path(r'^teacher/curatorial/save_assessment/?$', 		views_teacher_pages.instructorSaveAssessment.as_view(),   name='instructorSaveAssessment'),

	# Admin
	re_path(r'^admin/dashboard/?$', views_admin_pages.adminDashboardPage, name='adminDashboardPage'),
	re_path(r'^admin/add-terms/?$', views_admin_pages.adminAddTermsPage, name='adminAddTermsPage'),
	re_path(r'^admin/manage-guides/?$', views_admin_pages.adminManageGuidesPage, name='adminManageGuidesPage'),
	re_path(r'^admin/manage-kr/?$', views_admin_pages.adminManageKRPage, name='adminManageKRPage'),
	re_path(r'^admin/manage-organizations/?$', views_admin_pages.adminManageOrganizationsPage, name='adminManageOrganizationsPage'),

	# PoC3
	re_path(r'^teacher/poc3/dashboard/?$', views_teacher_pages.teacherDashboardPagePOC3, name='teacherDashboardPagePOC3'),

    # Util Pages
    re_path(r'^login/?$', 			views_functional_pages.loginPage, 			name='loginPage'),
    re_path(r'^sign-up/?$', 			views_functional_pages.signUpPage, 			name='signUpPage'),
    re_path(r'^verify-account/?$',	views_functional_pages.verifyAccountPage, 	name='verifyAccountPage'),
    re_path(r'^forgot-password/?$', 	views_functional_pages.forgotPasswordPage, 	name='forgotPasswordPage'),
	re_path(r'^reset-password/?$', 	views_functional_pages.resetPasswordPage, 	name='resetPasswordPage'),
    re_path(r'^403/?$', 				views_functional_pages.display403Page, 		name="display403Page"),

    # Student
    re_path(r'^student/dashboard/?$', 			views_student_pages.studentDashboardPage, 		name='studentDashboardPage'),
    re_path(r'^student/artworks/?$', 			views_student_pages.studentArtworksPage, 		name='studentArtworksPage'),
    re_path(r'^student/exhibitions/?$', 			views_student_pages.studenExhibitionsPage, 		name='studenExhibitionsPage'),
	re_path(r'^student/load-exhibition/?$',			views_student_pages.studentLoadExhibitionPage, 	name='studentLoadExhibitionPage'),
    re_path(r'^student/template_selection/?$', 	views.templateSelectionPagev2, 					name='studentSelectTemplatePage'),
    re_path(r'^student/communication/?$', 		views_student_pages.studentCommunicationPage,   name='studentCommunicationPage'),
	re_path(r'^student/curatorial/?$', 		views_student_pages.studentCuratorialPage,   name='studentCuratorial'),
	re_path(r'^student/curatorial/select_artworks/?$', 		views_student_pages.studentCuratorialSelectArtworksPage,   name='studentCuratorialSelectArtworks'),
	re_path(r'^student/curatorial/artworks_groups/?$', 		views_student_pages.studentCuratorialArtworksGroupsPage,   name='studentCuratorialArtworksGroups'),
	re_path(r'^student/curatorial/describe_groups/?$', 		views_student_pages.studentCuratorialDescribeGroupsPage,   name='studentCuratorialDescribeGroups'),
	re_path(r'^student/curatorial/edit_groups_description/?$', 		views_student_pages.studentCuratorialEditGroupsDescriptionPage,   name='studentCuratorialEditGroupsDescription'),
	re_path(r'^student/curatorial/expand_narratives/?$', 		views_student_pages.studentCuratorialExpandNarrativesPage,   name='studentCuratorialExpandNarratives'),
	re_path(r'^student/curatorial/final_assessment/?$', 		views_student_pages.studentCuratorialFinalAssessmentPage,   name='studentCuratorialFinalAssessmentPage'),
	re_path(r'^student/mr/select_artworks/?$', 		views_student_pages.studentMRSelectArtworksPage,   name='studentMRSelectArtworksPage'),
	re_path(r'^student/ar/select_artworks/?$', 		views_student_pages.studentARSelectArtworksPage,   name='studentARSelectArtworksPage'),
    re_path(r'^student/editor/?$', views.editorv2, name='student/editor'),
	re_path(r'^student/vr-threed-viewer/?$', views.vr_threed_viewer, name='student/vr_threed_viewer'),
	re_path(r'^student/vr-viewer/?$', views.vr_viewer_exhibition_viewer, name='student/vr_viewer_exhibition_viewer'),
    re_path(r'^student/artwork/new/?$',			views_student_pages.studentSubmitArtworkPage, 	name='studentSubmitArtworkPage'),
    re_path(r'^student/artwork/view/?$',			views_student_pages.studentViewArtworkPage,		name="studentViewArtworkPage"),
	re_path(r'^student/artwork/edit/?$',			views_student_pages.studentEditArtworkPage, 	name="studentEditArtworkPage"),
	re_path(r'^student/artwork/associated_media/?$',			views_student_pages.studentArtworkAssociatedMediaPage,		name="studentArtworkAssociatedMediaPage"),
	re_path(r'^student/artwork/threed_files/?$',			views_student_pages.studentArtworkThreedFilesPage,		name="studentArtworkThreedFilesPage"),
	re_path(r'^student/artwork/get_artwork_associated_media/?$', 		views_student_pages.studentGetArtworkAssociatedMedia.as_view(),   name='studentGetArtworkAssociatedMedia'),
	re_path(r'^student/artwork/save_associated_media/?$', 		views_student_pages.studentSaveAssociatedMedia.as_view(),   name='studentSaveAssociatedMedia'),
	re_path(r'^student/exhibition/view/?$', 		views_student_pages.studentViewExhibitionPage,  name='studentViewExhibitionPage'),
	re_path(r'^student/exhibition/viewer/$' ,   views_student_pages.studentExhibitionViewerPage,name='studentExhibitionViewerPage'),
    re_path(r'^student/audiofiles/?$', 			views_student_pages.studentAudioFilesPage,      name='studentAudioFilesPage'),
	re_path(r'^student/audiofile/new/?$', 		views_student_pages.studentSubmitAudioFilePage, name='studentSubmitAudioFilePage'),
    re_path(r'^student/media/?$', 				views_student_pages.studentVideoFilesPage,      name='studentVideoFilesPage'),
	re_path(r'^student/videos/new/?$',	 		views_student_pages.studentSubmitVideoFilePage, name='studentSubmitVideoFilePage'),
	re_path(r'^student/curatorial/save_selected_artworks/?$', 		views_student_pages.studentCuratorialSaveSelectedArtworks.as_view(),   name='studentCuratorialSaveSelectedArtworks'),
	re_path(r'^student/curatorial/save_group_artworks/?$', 		views_student_pages.studentCuratorialSaveGroupArtworks.as_view(),   name='studentCuratorialSaveGroupArtworks'),
	re_path(r'^student/curatorial/update_group_artworks/?$', 		views_student_pages.studentCuratorialUpdateGroupArtworks.as_view(),   name='studentCuratorialUpdateGroupArtworks'),
	re_path(r'^student/curatorial/save_group_description/?$', 		views_student_pages.studentCuratorialSaveGroupDescription.as_view(),   name='studentCuratorialSaveGroupDescription'),
	re_path(r'^student/curatorial/get_group_artworks/?$', 		views_student_pages.studentCuratorialGetGroupArtworks.as_view(),   name='studentCuratorialGetGroupArtworks'),
	re_path(r'^student/curatorial/save_expanded_narratives/?$', 		views_student_pages.studentCuratorialSaveExpandedNarratives.as_view(),   name='studentCuratorialSaveExpandedNarratives'),
	re_path(r'^student/recommended_artworks/?$', 		views_student_pages.studentRecommendedArtworks.as_view(),   name='studentRecommendedArtworks'),
	re_path(r'^student/mr/save_selected_artworks/?$', 		views_student_pages.studentMRSaveSelectedArtworks.as_view(),   name='studentMRSaveSelectedArtworks'),
	re_path(r'^student/ar/save_selected_artworks/?$', 		views_student_pages.studentARSaveSelectedArtworks.as_view(),   name='studentARSaveSelectedArtworks'),

	re_path(r'^admin/get_kr_files/?$', 		views_student_pages.KRGetFiles.as_view(),   name='KRGetFiles'),
	re_path(r'^admin/save_kr_files/?$', 		views_student_pages.KRSaveFiles.as_view(),   name='KRSaveFiles'),

    re_path(r'^test/?$', views.test, name='ROOM-TEST'),
    # Augemented Reality
    re_path(r'^create_ar/?$', views.createAr, name='createAr'),
    
    # Visitor
    re_path(r'^visitor/dashboard/?$', views_visitor.visitor_dashboard,name="visitorDashboardPage"),
    re_path(r'^visitor/ar_display/?$', views_visitor.ar_display,name="visitor/ar_display"),
    re_path(r'^visitor/vr_display/?$', views_visitor.vr_display,name="visitor/vr_display"),
    
	# Audio Files
    re_path(r'^audiofile/create/?$', views_audio.AudioFileCreate.as_view(), name='AudioFileCreate'),
    re_path(r'^audiofile/delete/?$', views_audio.AudioFileDelete.as_view(), name='AudioFileDelete'),
    re_path(r'^audiofile/list/?$', views_audio.AudioFileList.as_view(), name='AudioFileList'),
    
	# Video Files
    re_path(r'^videofile/create/?$', views_video.VideoFileCreate.as_view(), name='VideoFileCreate'),
    re_path(r'^videofile/delete/?$', views_video.VideoFileDelete.as_view(), name='VideoFileDelete'),
    re_path(r'^videofile/list/?$', 	views_video.VideoFileList.as_view(),   name='VideoFileList'),
    
	# Indoor Artwork
	re_path(r'^artworks/indoor/assign/?$', views.assignIndoorArtwork.as_view(), name='assignIndoorArtwork'),
    
	re_path(r'^shenkar/?$', views_teacher_pages.shenkar, name="shenkar"),
	# Chat
	path("chat/<str:chat_box_name>/", views.chat_box, name="chat"),
	re_path(r'^chat-mgmt/create/?$', views_chat.ChatMgmtCreate.as_view(), name="chat-mgmt/create"),
	re_path(r'^chat-mgmt/send_message/?$', views_chat.ChatMgmtSendMsg.as_view(), name="chat-mgmt/send_message"),
	re_path(r'^chat-mgmt/history/?$', views_chat.ChatMgmtHistory.as_view(), name="chat-mgmt/history"),

	# Blockchain
	re_path('blockchain', views.blockchain, name='blockchain'),

	re_path(r'^query_gpt/?$', views.queryGPT, name='query_gpt'),
]
