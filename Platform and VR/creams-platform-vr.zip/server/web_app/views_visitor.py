from .views import *
from django.http import HttpResponseForbidden

def visitor_dashboard(request):
    vr_exhibitions = {}
    vr_exhibitions["exhibitions"] = []

    demo = VR_Exhibition.objects.values()
    for indoor in demo:
        temp = {}
        temp["id"] = indoor['id']
        temp["owner"] = indoor['student_fk_id']
        owner = Users.objects.filter(id=indoor['student_fk_id']).values()[0]
        temp["owner_name"] = owner['name'] + ' ' + owner['surname']
        main = Exhibition.objects.filter(id=indoor['exhibition_fk_id']).values()[0]
        temp["image"] = main['image']
        temp["start_date"] = main['start_date']
        temp["end_date"] = main['end_date']
        temp["exhibition_title"] = main['exhibition_title']
        vr_exhibitions["exhibitions"].append(temp)

    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    template = loader.get_template('web_app/visitor/dashboard.html')
    context = {
		'title': "Visitor Dashboard",
		'header_content': 'Index header content',
        'vr_exhibitions': vr_exhibitions,
        #'ar_exhibitions': ar_exhibitions,
        #'mr_exhibitions': mr_exhibitions,
	}   
        
    return HttpResponse(template.render(context, request))

def ar_display(request):
    assigned_id = request.GET.get('assign')

    outdoor = OutdoorExhibition.objects.filter(id = assigned_id).values()[0]
    exh = Exhibition.objects.filter(id=outdoor['exhibition_fk_id']).values()
    titleExh = exh[0]['exhibition_title']
    
    inst = Users.objects.filter(id=outdoor['user_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    template = loader.get_template('web_app/visitor/ar_display.html')
    context = {
		'title': "View AR Exhibition",
		'header_content': 'Index header content',
        'exh_title': titleExh,
        'teacher': full_name,
        'exh_id': outdoor['id']
	}   

    return HttpResponse(template.render(context, request))

def vr_display(request):
    assigned_id = request.GET.get('assign')

    virtual = VR_Exhibition.objects.filter(id = assigned_id).values()[0]
    exh = Exhibition.objects.filter(id=virtual['exhibition_fk_id']).values()
    titleExh = exh[0]['exhibition_title']
    
    temp = virtual['vr_exhibition']
    filename = "media/" + temp[0:len(temp)]
    payload = open(filename, "r").read()
    try:
        name = "media/" + virtual['vr_script']
        ac = open(name, "r").read()
    except Exception:
        ac = ' '
    
    student_fk_id = virtual["student_fk_id"]
    exhibition_fk_id = virtual["exhibition_fk_id"]

    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_fk_id,
        student_fk_id=student_fk_id
    ).values('artwork_fk')

    selected_artworks_list = []

    for item in student_selected_artworks:
        selected_artworks_list.append(item.get('artwork_fk'))

    artworks_2d_rows = Artwork.objects.filter(id__in=selected_artworks_list, art_type="2d")

    for item in artworks_2d_rows:
        path_artwork = os.path.join("/code/media/", str(item.src))
        img = Image.open(path_artwork)
        item.width = img.width
        item.height = img.height

    artworks_3d_rows = Artwork.objects.filter(id__in=selected_artworks_list, art_type="3d")

    associated_3d_files_rows = ArtworksAssociatedMedia.objects.filter(
        Q(student_fk_id=student_fk_id) &
        Q(is_threed_file=True) &
        (Q(original_media_name="glb") | Q(original_media_name="gltf") | Q(original_media_name="obj") | Q(original_media_name="mtl"))
    )

    videos_rows = VideoFiles.objects.filter(user_fk_id=student_fk_id)

    template = loader.get_template('web_app/visitor/vr_exhibition_viewer.html')
    context = {
        'title': titleExh,
        'exh_id': virtual['id'],
        'custom_exhibition': payload,
        'x_script':ac,
        'social': True,
        'artworks_2d_rows': artworks_2d_rows,
        'artworks_3d_rows': artworks_3d_rows,
        'associated_3d_files_rows': associated_3d_files_rows,
        'videos_rows': videos_rows,
	}   

    return HttpResponse(template.render(context, request))
