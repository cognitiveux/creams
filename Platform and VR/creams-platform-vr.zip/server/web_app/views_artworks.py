from .views import *
from .apps import WebappConfig

import cv2
import pathlib
from PIL import Image


class getAllOutdoorArtworks(RetrieveAPIView):
    """
    get: Get data of all outdoor artworks assigned to an outdoor exhibition.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getAllOutdoorArtworks', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request):
        '''
        Get data of all outdoor artworks assigned to an outdoor exhibition.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                art_list = OutdoorArtwork.objects.values()
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []
                for a in art_list:
                    i = Artwork.objects.filter(id=a['artwork_fk_id']).values()[0]
                    data = {}
                    data["id"]          = a['id']
                    data["lat"]         = a['lat']
                    data["lon"]         = a['lon']
                    data["src"]         = i['src']
                    data["year"]        = i['year']
                    data["name"]        = i['name']
                    data["height"]      = i['height']
                    data["width"]       = i['width']
                    data["unit"]        = i['unit']
                    data["depth"]       = i['depth']
                    data["technique"]   = i['technique']
                    data["genre"]       = i['genre']
                    data["art_type"]    = i['art_type']
                    header_data["artworks"].append(data)
                    
                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
   

class getStudentsArtworks(RetrieveAPIView):
    """
    get: Get data all artworks of a student based on their jwt token.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = UserSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getStudentsArtworks', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,
    )

    def get(self, request):
        '''
        Get data all artworks of a student based on their jwt token.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = UserSerializer(data=req_data)

            flag,stu,decoded = at.authenticateStudent(request,settings)
            flag,artist,decoded = at.authenticateArtist(request,settings)

            if(flag == False  or (stu == False and artist == False)):
                log.error("{} Internal error: {}".format(request_details(request), decoded))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
                
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                st_id = req_data.get('student-id')
                art_list = Artwork.objects.filter(user_fk_id=decoded['user_id']).values()

                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []
                for i in art_list:
                    data = {}
                    data["id"]          = i['id']
                    data["src"]         = i['src']
                    data["year"]        = i['year']
                    data["name"]        = i['name']
                    data["height"]      = i['height']
                    data["width"]       = i['width']
                    data["unit"]        = i['unit']
                    data["depth"]       = i['depth']
                    data["technique"]   = i['technique']
                    data["genre"]       = i['genre']
                    data["art_type"]    = i['art_type']
                    header_data["artworks"].append(data)
                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getArtwork(RetrieveAPIView):
    """
    get: Get data of an artwork based on its id.
    """
    serializer_class = ArtworkSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'], 
    ]
    
    response_dict = build_fields('getArtwork', response_types)
    
    parameters = openapi.Parameter(
        'artwork-id',
        in_=openapi.IN_QUERY,
        description='The id of the artwork you want to fetch',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[parameters]
    )

    def get(self, request):
        '''
        Get data of an artwork based on its id.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ArtworkSerializer(data=req_data)
            
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                art_id = req_data.get('artwork-id')
                demo = Artwork.objects.filter(id=art_id).values()
                
                if not demo:
                    raise ApplicationError(['resource_not_found', 'artwork'])
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                
                artwork = demo[0]
                data = {}
                data["id"] = artwork['id']
                data["owner"] = artwork['user_fk_id']
                data["name"] = artwork['name']
                data["src"] = artwork['src']
                data["year"] = artwork['year']
                data["height"] = artwork['height']
                data["width"] = artwork['width']
                data["unit"] = artwork['unit']
                data["depth"] = artwork['depth']
                data["technique"] = artwork['technique']
                data["genre"] = artwork['genre']
                data["art_type"] = artwork['art_type']
                
                content[RESOURCE_OBJ] = data
                
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
                
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
  

class ArtworkCreate(CreateAPIView):
    """
    post:
    Creates a new artwork instance
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ArtworkCreateSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ArtworkCreate', response_types)

    @swagger_auto_schema(
        responses=response_dict,
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Creates a new artwork instance  '''
        
        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, decoded = at.authenticate(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( decoded['role'] != ARTIST and decoded['role'] != STUDENT):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ArtworkCreateSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        post = request.POST.copy()
                        post['user_fk'] = decoded['user_id']

                        art_terms = req_data.get('art_terms', "")
                        spatial_context_terms = req_data.get('spatial_context_terms', "")
                        post['personalization_model'] = art_terms + "," + spatial_context_terms

                        form = ArtWorkForm(post, request.FILES)
                        t = form.save()
                        art = Artwork.objects.filter(id=t.id).values()[0]
                        file_src = "/code/media/" + art['src']
                        
                        # os.chmod(path_of_image , stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)

                        # target_size = (800, 600)
                        # image = Image.open(path_of_image)

                        # if image.width < target_size[0] or image.height < target_size[1]:
                        #     image.save("/code/media/resized_" + art['src'])
                        # else:
                        #     aspect_ratio = image.width / image.height
                        #     new_width = target_size[0]
                        #     new_height = int(new_width / aspect_ratio)
                        #     resized_image = image.resize((new_width, new_height), Image.LANCZOS)
                        #     resized_image.save("/code/media/resized_" + art['src'])



                        # Update the model of images similarity
                        #image = Image.open(file_src)
                        #image = image.convert("RGB")
                        #image.save(file_src)
                        #WebappConfig.IMG_SIMIL.embed_dataset("/code/media/images/")
                        #WebappConfig.IMG_SIMIL.save_dataset("/code/media/img_model/")
                        sig = Users.objects.filter(id=decoded['user_id']).values()[0]
                        sig_value = sig['name'] + ' ' + sig['surname']

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        content[RESOURCE_ID] = t.id
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getAllOutdoorArtworksSorted(RetrieveAPIView):
    """
    get: Get data of all outdoor artworks sorted based on a latitude and longitude.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getAllOutdoorArtworksSorted', response_types)
    
    parameters = [openapi.Parameter(
        'lat',
        in_=openapi.IN_QUERY,
        description='The latitude of your position',
        type=openapi.TYPE_NUMBER,
        required=True,
    ),openapi.Parameter(
        'lon',
        in_=openapi.IN_QUERY,
        description='The longitude of your position',
        type=openapi.TYPE_NUMBER,
        required=True,
    )]
                  

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=parameters
    )
    
    def get(self, request):
        '''
        Get data of all outdoor artworks sorted based on a latitude and longitude. 
        '''

        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            lat = req_data.get('lat')
            lon = req_data.get('lon')

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                art_list = OutdoorArtwork.objects.values()
                
                
                status_code, message = get_code_and_response(['success'])
                
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []
                art_list = sortGeo(art_list,lat,lon)
                for a in art_list:
                    i = Artwork.objects.filter(id=a['artwork_fk_id']).values()[0]
                    data = {}
                    data["id"]          = a['id']
                    data["lat"]         = a['lat']
                    data["lon"]         = a['lon']
                    data["src"]         = i['src']
                    data["year"]        = i['year']
                    data["name"]        = i['name']
                    data["height"]      = i['height']
                    data["width"]       = i['width']
                    data["unit"]        = i['unit']
                    data["depth"]       = i['depth']
                    data["technique"]   = i['technique']
                    data["genre"]       = i['genre']
                    data["art_type"]    = i['art_type']
                    header_data["artworks"].append(data)
                    
                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
  

class deleteArtwork(DestroyAPIView):
    """
    delete: Delete data of an `artwork` based on its `id`.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'], 
    ]
    
    response_dict = build_fields('deleteArtwork', response_types)
    
    parameters = openapi.Parameter(
        'artwork-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the artwork you want to delete',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[parameters]
    )

    def delete(self, request):
        '''
        Delete data of an `artwork` based on its `id`.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != ARTIST and decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                
                art_to_delete_id = req_data.get('artwork-id')
                try:
                    instance=get_object_or_404(Artwork,id=art_to_delete_id,user_fk_id = decoded['user_id'] )
                    instance.delete()
                except Exception as e:
                    log.error("{} Internal error: {}".format(request_details(request), str(e)))
                    status_code, _ = get_code_and_response(['resource_not_found'])
                    content = {
                        MESSAGE: "This artwork does not exist."
                    }
                    return Response(content, status=status_code)
                
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                content[RESOURCE_OBJ] = "Deleted Artwork"
                
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
                
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to delete artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class updateArtwork(GenericAPIView):
    """
    patch:
    Update a agent
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ArtworkUpdateSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'], 
    ]
    response_dict = build_fields('updateArtwork', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[]
    )
    def patch(self, request, *args, **kwargs):
        ''' Patch:  Updates an agent   '''
        
        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ArtworkUpdateSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != ARTIST and decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                    
                with transaction.atomic():
                    try:
                        try:
                            artwork = get_object_or_404(Artwork,id=req_data.get('artwork_id'))
                        except:
                            raise ApplicationError(['resource_not_found', 'artwork'])
                        post = request.POST.copy()
                        if req_data.get('name') == None:
                            post['name'] = artwork.name
                        if req_data.get('year') == None:
                            post['year'] = artwork.year
                        if req_data.get('height') == None:
                            post['height'] = artwork.height
                        if req_data.get('width') == None:
                            post['width'] = artwork.width
                        if req_data.get('depth') == None:
                            post['depth'] = artwork.depth
                        if req_data.get('unit') == None:
                            post['unit'] = artwork.unit
                        if req_data.get('technique') == None:
                            post['technique'] = artwork.technique
                        if req_data.get('genre') == None:
                            post['genre'] = artwork.genre
                        if req_data.get('art_type') == None:
                            post['art_type'] = artwork.art_type
                        
                        art_terms = req_data.get('art_terms')
                        spatial_context_terms = req_data.get('spatial_context_terms')
                        post['personalization_model'] = art_terms + "," + spatial_context_terms

                        form = UpdateArtWorkForm(post,request.FILES,instance=artwork)
                        form.save()

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])



class getAllArtworks(RetrieveAPIView):
    """
    get: Get data of all artworks that exist in the system.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getAllArtworks', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request):
        '''
        Get data of all outdoor artworks that exist in the system.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                art_list = Artwork.objects.values()
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []

                for art in art_list:
                    outdoor_art = OutdoorArtwork.objects.filter(artwork_fk_id=art.get('id')).first()
                    outdoor_lat = ''
                    outdoor_lon = ''
                    outdoor_description = ''

                    if outdoor_art:
                        outdoor_lat = outdoor_art.lat
                        outdoor_lon = outdoor_art.lon
                        outdoor_description = outdoor_art.description

                    data = {}
                    data["id"] = art.get('id')
                    data["src"] = str(art.get('src'))
                    data["year"] = art.get('year')
                    data["name"] = art.get('name')
                    data["height"] = art.get('height')
                    data["width"] = art.get('width')
                    data["unit"] = art.get('unit')
                    data["depth"] = art.get('depth')
                    data["technique"] = art.get('technique')
                    data["genre"] = art.get('genre')
                    data["art_type"] = art.get('art_type')
                    data["lat"] = outdoor_lat
                    data["lon"] = outdoor_lon
                    data["description"] = outdoor_description

                    header_data["artworks"].append(data)
                    
                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch all artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getMRArtworks(RetrieveAPIView):
    """
    get: Get data of all artworks that exist in the system.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getMRArtworks', response_types)
    
    parameters = openapi.Parameter(
        'mr_exhibition_fk_id',
        in_=openapi.IN_QUERY,
        description='The ID of the mr exhibition',
        type=openapi.TYPE_INTEGER,
        required=False,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[parameters]
    )

    def get(self, request):
        '''
        Get data of all outdoor artworks that exist in the system.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                #art_list = Artwork.objects.values()

                mr_exhibition_fk_id = req_data.get('mr_exhibition_fk_id')

                if mr_exhibition_fk_id:
                    mr_artworks_with_artwork = MRArtworks.objects.filter(mr_exhibition_fk_id=mr_exhibition_fk_id).select_related('artwork_fk').all()
                else:
                    mr_artworks_with_artwork = MRArtworks.objects.select_related('artwork_fk').all()
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []

                for mr_artwork in mr_artworks_with_artwork:
                    data = {}
                    data["id"] = mr_artwork.artwork_fk.id
                    data["src"] = str(mr_artwork.artwork_fk.src)
                    data["year"] = mr_artwork.artwork_fk.year
                    data["name"] = mr_artwork.artwork_fk.name
                    data["height"] = mr_artwork.artwork_fk.height
                    data["width"] = mr_artwork.artwork_fk.width
                    data["unit"] = mr_artwork.artwork_fk.unit
                    data["depth"] = mr_artwork.artwork_fk.depth
                    data["technique"] = mr_artwork.artwork_fk.technique
                    data["genre"] = mr_artwork.artwork_fk.genre
                    data["art_type"] = mr_artwork.artwork_fk.art_type

                    header_data["artworks"].append(data)
                    
                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch all artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class ArtworkAssociatedMedia(RetrieveAPIView):
    """
    get: Get data of associated media based on the provided artwork ID.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ArtworkAssociatedMediaSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ArtworkAssociatedMedia', response_types)

    parameters = openapi.Parameter(
        'artwork_id',
        in_=openapi.IN_QUERY,
        description='The ID of the artwork',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[parameters]
    )
    def get(self, request):
        '''
        Get data of associated media based on the provided artwork ID.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ArtworkAssociatedMediaSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))

                    artwork_fk_id = req_data.get('artwork_id')
                    associated_media_list_2D = []
                    associated_media_list_3D = []
                    associated_media_list_3D_standalone = []
                    associated_media_list_videos = []
                    associated_media_list_videos_dimension = []
                    associated_media_list_audio = []

                    associated_media_rows = ArtworksAssociatedMedia.objects.filter(
                        artwork_fk_id=artwork_fk_id,
                    )

                    for item in associated_media_rows:
                        file_extension = pathlib.PurePosixPath(str(item.media_src)).suffix
                        file_extension_lower = ''

                        try:
                            file_extension_split = file_extension.split('.')[1]
                            file_extension_lower = file_extension_split.lower()
                        except Exception as e:
                            log.info("{} Can't parse file extension: {}".format(request_details(request), str(e)))

                        if item.is_threed_file:
                            associated_media_list_3D_standalone.append(item.media_src)
                        
                        if file_extension_lower in settings.ASSOC_MEDIA_FMT_2D:
                            if not item.is_threed_file:
                                associated_media_list_2D.append(item.media_src)
                        elif file_extension_lower in settings.ASSOC_MEDIA_FMT_3D:
                            if not item.is_threed_file:
                                associated_media_list_3D.append(item.media_src)
                        elif file_extension_lower in settings.ASSOC_MEDIA_FMT_VIDEO:
                            associated_media_list_videos.append(item.media_src)

                            try:
                                print("item.media_src: ", item.media_src)
                                video_descr_obj = {}
                                vid_height = 0
                                vid_width = 0

                                vid = cv2.VideoCapture("/code/" + item.media_src)
                                vid_height = vid.get(cv2.CAP_PROP_FRAME_HEIGHT)
                                vid_width = vid.get(cv2.CAP_PROP_FRAME_WIDTH)
                            except Exception as e:
                                log.info("{} Can't extract video dimensions. Reason: {}".format(request_details(request), str(e)))
                                vid_height = 0
                                vid_width = 0

                            video_descr_obj['height'] = vid_height
                            video_descr_obj['width'] = vid_width
                            associated_media_list_videos_dimension.append(video_descr_obj)
                        elif file_extension_lower in settings.ASSOC_MEDIA_FMT_AUDIO:
                            associated_media_list_audio.append(item.media_src)
                        else:
                            log.debug("{} Couldn't detect matching file extension. Item: ".format(request_details(request), item.media_src))

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_OBJ] = {
                        '2D': associated_media_list_2D,
                        '3D': associated_media_list_3D,
                        '3D_standalone': associated_media_list_3D_standalone,
                        'videos': associated_media_list_videos,
                        'videos_dimensions': associated_media_list_videos_dimension,
                        'audio': associated_media_list_audio,
                    }

                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of associated media for artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getAllStudyArtworks(RetrieveAPIView):
    """
    get: Get data of all artworks that exist in the system.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getAllStudyArtworks', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request):
        '''
        Get data of all outdoor artworks that exist in the system.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["artworks"] = []

                f = open('/code/web_app/study_data.json')
                art_list = json.load(f)

                for art in art_list:
                    data = {}
                    data["id"] = art.get('id')
                    data["name"] = art.get('name')
                    data["src"] = str(art.get('src'))
                    data["description"] = art.get('description')

                    header_data["artworks"].append(data)

                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch all artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class ArtworkSimilarity(CreateAPIView):
     """
     post:
     Checks the similarity of the artwork
     """
     authentication_classes = [JWTAuthentication]
     serializer_class = ArtworkSimilaritySerializer
     parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
     response_types = [
         ['success'],
         ['unauthorized'],
         ['bad_request'],
         ['method_not_allowed'],
         ['unsupported_media_type'],
         ['internal_server_error']
     ]
     response_dict = build_fields('ArtworkSimilarity', response_types)

     @swagger_auto_schema(
         responses=response_dict,
     )

     def post(self, request, *args, **kwargs):
         ''' Post:  Checks the similarity of the artwork  '''

         log.debug("{} Received request".format(request_details(request)))
         try:
             access_tkn = request.COOKIES.get('access_tkn')
             refresh_tkn = request.COOKIES.get('refresh_tkn')
             if not access_tkn:
                 raise Exception("No access token provided!")

             tkn_okay, decoded = at.authenticate(request,settings)
             if( tkn_okay == False):
                 raise Exception("Access token invalid!")

             if( decoded['role'] != ARTIST and decoded['role'] != STUDENT):
                 raise Exception("User account unauthorized!")

         except Exception as e:
                 log.error("{} Internal error: {}".format(request_details(request), str(e)))
                 status_code, _ = get_code_and_response(['unauthorized'])
                 content = {
                     MESSAGE: "Access token is invalid."
                 }
                 return Response(content, status=status_code)
         try:
             response = {}
             data = {}
             req_data = request.data
             serialized_request = serialize_request(request)
             log.debug("{} START".format(request_details(request)))
             serialized_item = ArtworkSimilaritySerializer(data=req_data)

             if not serialized_item.is_valid():
                 log.debug("{} VALIDATION ERROR: {}".format(
                         request_details(request),
                         serialized_item.formatted_error_response()
                     )
                 )
                 response = {}
                 response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                 response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                 data = response
             else:
                 with transaction.atomic():
                     try:
                         log.debug("{} VALID DATA".format(request_details(request)))

                         file_obj = request.data['src']
                         filename_uuid = generate_random_uuid()
                         tmp_file_src = "/code/media/tmp_similar/" + filename_uuid + ".png"

                         with open(tmp_file_src, "wb+") as outf:
                             for chunk in file_obj.chunks():
                                 outf.write(chunk)

                         image = Image.open(tmp_file_src)
                         image = image.convert("RGB")
                         image.save(tmp_file_src)

                         WebappConfig.IMG_SIMIL.load_dataset("/code/media/img_model/tensors.pt")
                         similarity_scores = WebappConfig.IMG_SIMIL.similar_images(tmp_file_src, n=3)

                         if os.path.exists(tmp_file_src):
                             os.remove(tmp_file_src)

                         response_data = {}

                         for k, v in similarity_scores.items():
                             new_key = k.replace("/code", "", 1)
                             response_data[new_key] = v

                         status_code, message = get_code_and_response(['success'])
                         content = {}
                         content[MESSAGE] = message
                         content[RESOURCE_NAME] = 'artwork'
                         content[RESOURCE_OBJ] = response_data
                         response = {}
                         response[CONTENT] = content
                         response[STATUS_CODE] = status_code
                         log.debug("{} SUCCESS".format(request_details(request)))
                         data = response
                     except ApplicationError as e:
                         log.info("{} ERROR: {}".format(request_details(request), str(e)))
                         response = {}
                         response[CONTENT] = e.get_response_body()
                         response[STATUS_CODE] = e.status_code
                         data = response

         except Exception as e:
             log.error("{} Internal error: {}".format(request_details(request), str(e)))
             status_code, _ = get_code_and_response(['internal_server_error'])
             content = {
                 MESSAGE: "Failed to check similarity for artwork."
             }
             return Response(content, status=status_code)

         return Response(data[CONTENT], status=data[STATUS_CODE])
