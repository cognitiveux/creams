from cmath import nan
from decimal import Decimal
from email import header
from .forms import *
from re import T
from celery.result import AsyncResult
from datetime import timedelta
from django.db import transaction
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.http import (
	HttpResponse,
    HttpResponseRedirect,
    JsonResponse,
)
from django.shortcuts import render, get_object_or_404
from django.template import loader
from django.urls import reverse
from django.utils.timezone import now

from drf_yasg.utils import swagger_auto_schema
import os
from rest_framework import (
    parsers,
    permissions,
    status,
)
from rest_framework.exceptions import ParseError
from rest_framework.generics import (
    CreateAPIView,
    GenericAPIView,
    RetrieveAPIView,
    DestroyAPIView,
    UpdateAPIView,
)
from rest_framework.response import Response
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from rest_framework.decorators import (
    permission_classes,
    api_view,
)

from rest_framework.permissions import(
    IsAuthenticated,
)
import stat
from creams_project.celery import (
    app,
)
from .application_error import ApplicationError
from .authentication_tools import auth_tools as at

from .logging import logger as log
from .models import *
from .serializers import *
from .status_codes import *
from .views_utils import (
    generate_random_uuid,
    request_details,
    send_verification_email,
    serialize_request,
    sortGeo,
    geoDistance,
    changeExhibitionState,
    chechRole,
    watermark,
    assignDefaultAssignment,
    exhibitionStatusClassDecoder,
    decodeHeaderColouring,
    getInstructorExhibitions,
    getStudentExhibitions,
    getStudentArtworks,
    getStudentVrExhibitions,
)
from .blockchain import Blockchain
from django.db.models import Q
from PIL import Image
from django.db.models import Prefetch


import jwt
import json

BAD_REQUEST = "bad_request"
CONTENT = "content"
INTERNAL_SERVER_ERROR = "internal_server_error"
STRING_TYPE = "_str"
DICT_TYPE = "_dict"
ARRAY_TYPE = "_array"
BOOLEAN_TYPE = "_bool"
MESSAGE = "message"
EXTRA_DETAILS = "extra_details"
BAD_FORMATTED_FIELDS = "bad_formatted_fields"
MISSING_REQUIRED_FIELDS = "missing_required_fields"
METHOD_NOT_ALLOWED = "method_not_allowed"
STATUS_CODE = "status_code"
RESOURCE = "resource"
RESOURCE_IS_ACTIVATED = "resource_is_activated"
RESOURCE_NAME = "resource_name"
RESOURCE_OBJ = "resource_obj"
RESOURCE_ID = "resource_id"
RESOURCE_BOOL = "resource_bool"
RESOURCE_ARRAY = "resource_array"
ARTWORK = "artwork"
INSTRUCTOR = "INSTRUCTOR"
STUDENT = "STUDENT"
ARTIST = "ARTIST"
WALLS =  5.0 

TASK_STATUS = "task_status"

ALREADY_EXISTS_FIELDS = "already_exists_fields"
BAD_FORMATTED_FIELDS = "bad_formatted_fields"
ERROR_DETAILS = "error_details"
MISSING_REQUIRED_FIELDS = "missing_required_fields"

import chromadb
from openai import OpenAI

os.environ["OPENAI_API_KEY"] = "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"


def queryChromaDB(nameOfArtwork):
    #from creams_project.settings import client as clienttest
    from web_app.chromadb_client import get_client
    
    clienttest = get_client()
    answer = ""
    print("[queryChromaDB] nameOfArtwork: ", nameOfArtwork)

    client_obj = clienttest.get_or_create_collection(name=nameOfArtwork)
    print("client_obj in query: ", client_obj)
    answer = (client_obj.query(query_texts=[nameOfArtwork],n_results=2))
    print("queryChromaDB answer: ", answer)

    return answer


def chat_gpt(question, name):
    #from creams_project.settings import client as clienttest
    from web_app.chromadb_client import get_client
    
    clienttest = get_client()
    print("[chat_gpt] question: ", question, " and name: ", name)
    print(clienttest)
    print("client type: ", type(clienttest))
    c = clienttest.get_or_create_collection(name=name)

    print("c.get() in gpt: ", c.get())
    answ = queryChromaDB(name)
    print("answ: ", answ)

    messagess = []

    for i in range(len(answ['documents'][0])):
        print("doc append: " , answ['documents'][0][i])
        messagess.append({"role": "assistant", "content": answ['documents'][0][i]})

    messagess.append({"role": "system", "content": "You are a helpful assistant."})
    messagess.append({"role": "user", "content": question})
    client_openai = OpenAI()
    response = client_openai.chat.completions.create(model="gpt-3.5-turbo",messages=messagess)
    answ = response.choices[0].message.content

    return answ


def toText(id):
    client_openai = OpenAI()
    audio_file = open("uploaded_file.wav", "rb")
    transcript = client_openai.audio.translations.create(
      model="whisper-1", 
      file=audio_file, 
      response_format="text"
    )
    print("transcript: ", transcript)
    return transcript, chat_gpt(transcript, id)


from rest_framework.decorators import api_view
@api_view(['PUT'])
def queryGPT(request):
    print("query GPT called")
    print(request.headers)
    file_path = os.path.join('', 'uploaded_file.wav')
    file = open(file_path, 'wb')
    file.write(request.body)
    name = request.headers.get('Name-Of-Artwork')
    name_split = name.split(".")
    name = name_split[0]
    print("name: ", name)
    question, answer = toText(name)
    print("queryGPT answer: ", answer)
    result = {
        'question': question,
        'answer': answer
    }
    return JsonResponse(result)


class SampleAuthenticated(GenericAPIView):
    """
    post:
    Sample view that checks the JWT Authentication
    """
    authentication_classes = [JWTAuthentication]
    permission_classes = (permissions.IsAuthenticated,)
    serializer_class = SampleAuthenticatedSerializer

    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['resource_not_allowed'],
        ['resource_not_found', 'user'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('SampleAuthenticated', response_types)

    @app.task(bind=True, time_limit=settings.CELERY_TASK_TIME_LIMIT)
    def sample_authenticated_task(self, data, request):
        response = {}
        log.debug("{} START".format(request_details(request)))
        serialized_item = SampleAuthenticatedSerializer(data=data)

        if not serialized_item.is_valid():
            log.debug("{} VALIDATION ERROR: {}".format(
                    request_details(request),
                    serialized_item.formatted_error_response()
                )
            )
            response = {}
            response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=False)
            response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
            return response
        else:
            try:
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
                content[RESOURCE_NAME] = 'jwt'
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                return response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                return response

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ]
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request". format(request_details(request)))

        try:
            result = self.sample_authenticated_task.delay(request.data, serialize_request(request))
            data = result.wait(timeout=None, interval=settings.CELERY_TASK_INTERVAL)
        except ParseError as e:
            status_code, message = get_code_and_response(['bad_formatted_json'])
            content = {}
            content['message'] = message
            content['bad_formatted_fields'] = []
            content['missing_required_fields'] = []
            content['error_details'] = {
                'json': str(e)
            }
            return Response(content, status=status_code)
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, message = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: message
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])

def submit_artwork(request):
	template = loader.get_template('web_app/student/submit_artwork.html')
	context = {
		'title': "Submit an artwork",
		'header_content': 'Index header content'
	}
	return HttpResponse(template.render(context, request))



def editor_prototype(request):
    template = loader.get_template('web_app/editor/editor.html')
    demo = VR_Templates.objects.filter(id=7).values()
    temp = demo[0]['basis']
    context = {
		'title1': "Teacher Dashboard",
		'header_content': 'Index header content',
        'basis': temp
	}   

    
    return HttpResponse(template.render(context, request)) 

def room(request):
    template = loader.get_template('web_app/editor_v2/editor.html')
    layout = json.loads(request.GET.get('layout'))
    context = {
            'modular': False,
            'height' : 9,
            'dimension': 15,
            'dimension_y': 13,
            'walls': False,
    }

    
    return HttpResponse(template.render(context, request)) 

def test(request):
    template = loader.get_template('web_app/vr-exhibitions/picasso/picasso.html')
    context = {
		'title1': "Teacher Dashboard",
		'header_content': 'Index header content',
	}   

    
    return HttpResponse(template.render(context, request)) 

def profile(request):
    template = loader.get_template('web_app/account-management/user_profile.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, decoded = at.authenticate(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    
    user__ = Users.objects.filter(id=decoded['user_id']).values()[0]
    context = {
		'title': "User Profile",
		'header_content': 'Index header content',
        'name': user__['name'],
        'surname': user__['surname'],
        'email': user__['email'],
        'organization': user__['organization'],
        'role': user__['role'],
        'class_level': user__['class_level'],
	}   

    
    return HttpResponse(template.render(context, request)) 

def exhibition(request):
    template = loader.get_template('web_app/student/exhibition.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    assigned_id = request.GET.get('assign')
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    exh = Exhibition.objects.filter(id=assigned_id).values()[0]
    inst = Users.objects.filter(id=exh['instructor_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    titleExh = exh['exhibition_title']
    sp_type = exh['space_assign']
    status = exh['status']
    if status == "Temporary Stored":
        class__ = "redText"
    if status == "Published":
        class__ =  "greenText"
    if status == "Accepting Artworks":
        class__ =  "orangeText"
    if status == "Ready to be Assessed":
        class__ =  "yellowText"
    if status == "Assessed":
        class__ =  "blueText"
    if status == "Assessment Started":
        class__ =  "cyanText"

    context = {
		'title': "Exhibition",
		'header_content': 'Index header content',
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition_title': titleExh,
        'thumbnail': exh['image'],
        'start': exh['start_date'],
        'end': exh['end_date'],
        'description': exh['message'],
        'space_type': exh['space_assign'],
        'status_value': status,
        'status_class': class__ ,
        'space':  sp_type
	}   

    
    return HttpResponse(template.render(context, request)) 


def createAr(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False and artist == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    assigned_id = request.GET.get('assign')
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        if stu:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
    
    template = loader.get_template('web_app/ar-exhibitions/createAR.html')
    exh = Exhibition.objects.filter(id=assigned_id).values()[0]
    if not exh:
        if stu:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        
    inst = Users.objects.filter(id=exh['instructor_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    titleExh = exh['exhibition_title']
    outdoor = OutdoorExhibition.objects.filter(exhibition_fk_id = exh['id'], user_fk_id =decoded['user_id']).values()
    if not outdoor:
        inModel = OutdoorExhibition(
        user_fk_id = decoded['user_id'],
        exhibition_fk_id = assigned_id)

        inModel.save()
        outdoor = OutdoorExhibition.objects.filter(exhibition_fk_id = exh['id'], user_fk_id =decoded['user_id']).values()
        
    outdoor = outdoor[0]
    context = {
		'title': "Create AR Exhibition",
		'header_content': 'Index header content',
        'assignment_id': assigned_id,
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'exh_title': titleExh,
        'teacher': full_name,
        'exh_id': outdoor['id'],
        'help_title': "Outdoor Exhibition",
        'help_text': "You can select a an artwork by clicking on the `select` button, optionally add a description and then click on the map to add a pin.",
	}   

    return HttpResponse(template.render(context, request))


class ExhibitionCreate(CreateAPIView):
    """
    post:
    Assigns a student to an exhibition.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ExhibitionSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ExhibitionCreate', response_types)
    

    @swagger_auto_schema(
        responses=response_dict,
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))

        try:
                    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( instr == False and artist == False):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ExhibitionSerializer(data=req_data)
            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        post = request.POST.copy()
                        post['instructor_fk'] = decoded['user_id']
                        post['status'] = ExhibitionStatus.TemporaryStored

                        art_terms = req_data.get('art_terms')
                        spatial_context_terms = req_data.get('spatial_context_terms')
                        post['personalization_model'] = art_terms + "," + spatial_context_terms

                        form = ExhibitionForm(post, request.FILES)
                        CREATED_EXHIBITION = form.save()
                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'exhibition assignment'
                        content[RESOURCE_ID] = Exhibition.objects.last().id
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response

                        if artist:
                            '''if the user is an artist we should assign them as a "student" to the exhibition '''
                            assign = AssignedExhibitionStudents(
                            student_fk_id= decoded['user_id'],
                            assignment_fk_id=int(CREATED_EXHIBITION.id),)
                            assign.save()
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response
                   

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create exhibition assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class deleteAssignment(DestroyAPIView):
    """
    delete: Delete data of an `assignment` based on its `id`.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'assignment'], 
    ]
    
    response_dict = build_fields('deleteAssignment', response_types)
    
    parameters = openapi.Parameter(
        'assignment-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the assignment you want to delete',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[parameters]
    )

    def delete(self, request):
        '''
        Delete data of an `assignment` based on its `id`.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( instr == False and artist == False):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                
                assignment_to_delete_id = req_data.get('assignment-id')
                try:
                    instance=get_object_or_404(Exhibition,id=assignment_to_delete_id,instructor_fk_id = decoded['user_id'] )
                    instance.delete()
                except Exception as e:
                    log.error("{} Internal error: {}".format(request_details(request), str(e)))
                    status_code, _ = get_code_and_response(['resource_not_found'])
                    content = {
                        MESSAGE: "This assignment does not exist."
                    }
                    return Response(content, status=status_code)
                
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                content[RESOURCE_OBJ] = "Deleted Assignment"
                
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
                
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to delete assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class updateAssignment(GenericAPIView):
    """
    patch:
    Update an assignment
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = AssignmentUpdateSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'assignment'], 
    ]
    response_dict = build_fields('updateAssignment', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[]
    )
    def patch(self, request, *args, **kwargs):
        ''' Patch:  Updates an assignment   '''
        
        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = AssignmentUpdateSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( instr == False and artist == False):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                    
                with transaction.atomic():
                    try:
                        try:
                            #assignment = get_object_or_404(Exhibition,id=req_data.get('assignment_id'))
                            requested_id = req_data.get('assignment_id')
                            assignment = Exhibition.objects.none()
                            exhibition_row = Exhibition.objects.filter(id=requested_id).first()
                            if exhibition_row:
                                if exhibition_row.instructor_fk_id == decoded['user_id']:
                                    assignment = exhibition_row
                                else:
                                    coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
                                    if coadvisor_row:
                                        assignment = exhibition_row
                        except:
                            raise ApplicationError(['resource_not_found', 'assignment'])
                        post = request.POST.copy()
                        if req_data.get('exhibition_title') == None:
                            post['exhibition_title'] = assignment.exhibition_title
                        if req_data.get('start_date') == None:
                            post['start_date'] = assignment.start_date
                        if req_data.get('end_date') == None:
                            post['end_date'] = assignment.end_date
                        if req_data.get('space_assign') == None:
                            post['space_assign'] = assignment.space_assign
                        if req_data.get('message') == None:
                            post['message'] = assignment.message
                        if req_data.get('status') == None:
                            post['status'] = assignment.status
                        
                        post['ts_last_update'] = now()

                        art_terms = req_data.get('art_terms')
                        spatial_context_terms = req_data.get('spatial_context_terms')
                        post['personalization_model'] = art_terms + "," + spatial_context_terms

                        form = UpdateAssignmentForm(post,request.FILES,instance=assignment)
                        form.save()
                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'assignment'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class AssignExhibition(CreateAPIView):
    """
    post:
    Creates an exhibition assignment
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = AssignStudentSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('AssignExhibition', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,

    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))

        try:
                    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( instr == False):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = AssignStudentSerializer(data=req_data)
            
            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        student = req_data.get('student_fk')
                        if(chechRole(student,STUDENT) == False):
                            raise Exception
                        exhibition = req_data.get('assignment_fk')
                        
                        # exhibition_item = Exhibition.objects.filter(
                        #     id=exhibition
                        # ).first()

                        exhibition_item = Exhibition.objects.none()
                        exhibition_row = Exhibition.objects.filter(id=exhibition).first()
                        if exhibition_row:
                            if exhibition_row.instructor_fk_id == decoded['user_id']:
                                exhibition_item = exhibition_row
                            else:
                                coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
                                if coadvisor_row:
                                    exhibition_item = exhibition_row

                        if exhibition_item.exhibition_type == "vr":
                            assign = AssignedExhibitionStudents(
                                student_fk_id=student,
                                assignment_fk_id=exhibition,
                            )
                            assign.save()
                        elif exhibition_item.exhibition_type == "ar":
                            assign = AR_Exhibition(
                                student_fk_id=student,
                                exhibition_fk_id=exhibition,
                            )
                            assign.save()
                        elif exhibition_item.exhibition_type == "mr":
                            assign = MR_Exhibition(
                                student_fk_id=student,
                                exhibition_fk_id=exhibition,
                            )
                            assign.save()

                        changeExhibitionState(exhibition,ExhibitionStatus.AcceptingArtworks)

                        cur_status_row = CuratorialStatus.objects.filter(
                            instructor_fk_id=decoded['user_id'],
                            student_fk_id=student,
                            assignment_fk_id=exhibition,
                        )

                        if not cur_status_row:
                            cur_status = CuratorialStatus(
                                instructor_fk_id=decoded['user_id'],
                                student_fk_id=student,
                                assignment_fk_id=exhibition,
                            )
                            cur_status.save()

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'exhibition assignment'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response
                   

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create exhibition assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class removeStudentAssignmentExhibition(DestroyAPIView):
    """
    delete: Delete a student assignment
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'assigned_student'], 
    ]
    
    response_dict = build_fields('removeStudentAssignmentExhibition', response_types)
    
    assignment_id = openapi.Parameter(
        'assignment-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the assignment you want to edit',
        type=openapi.TYPE_INTEGER,
        required=True,
    )
    
    student_id = openapi.Parameter(
        'student-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the student you want to remove from the assignment',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[assignment_id, student_id]
    )

    def delete(self, request):
        '''
        Delete data of a `student assignment`.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( instr == False):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                
                assignment_to_delete_id = req_data.get('assignment-id')
                student_to_delete_id = int(req_data.get('student-id'))

                if(chechRole(student_to_delete_id,STUDENT) == False):
                    raise ApplicationError
                
                try:
                    #assignment = get_object_or_404(Exhibition, id=assignment_to_delete_id, instructor_fk_id=decoded['user_id'])
                    
                    # exhibition_item = Exhibition.objects.filter(
                    #     id=assignment.id
                    # ).first()
                    assignment = Exhibition.objects.none()
                    exhibition_row = Exhibition.objects.filter(id=assignment_to_delete_id).first()
                    if exhibition_row:
                        if exhibition_row.instructor_fk_id == decoded['user_id']:
                            assignment = exhibition_row
                        else:
                            coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
                            if coadvisor_row:
                                assignment = exhibition_row

                    if assignment.exhibition_type == "vr":
                        instance = get_object_or_404(AssignedExhibitionStudents,student_fk_id=student_to_delete_id,assignment_fk_id=assignment.id)
                        instance.delete()
                    elif assignment.exhibition_type == "ar":
                        instance = get_object_or_404(AR_Exhibition,student_fk_id=student_to_delete_id,exhibition_fk_id=assignment.id)
                        instance.delete()
                    elif assignment.exhibition_type == "mr":
                        instance = get_object_or_404(MR_Exhibition,student_fk_id=student_to_delete_id,exhibition_fk_id=assignment.id)
                        instance.delete()
                    # try:
                    #     student_list = AssignedExhibitionStudents.objects.filter(assignment_fk_id=assignment.id).values()[0]
                    # except:
                    #     changeExhibitionState(int(assignment.id),ExhibitionStatus.TemporaryStored )
                except Exception as e:
                    log.error("{} Internal error: {}".format(request_details(request), str(e)))
                    status_code, _ = get_code_and_response(['resource_not_found'])
                    content = {
                        MESSAGE: "This student assignment does not exist."
                    }
                    return Response(content, status=status_code)
            
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                content[RESOURCE_OBJ] = "Deleted Student Assignment"
                
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
                
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to delete student assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class removeInstructorAssignmentExhibition(DestroyAPIView):
    """
    delete: Delete an instructor assignment
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'assigned_instructor'], 
    ]
    
    response_dict = build_fields('removeInstructorAssignmentExhibition', response_types)
    
    assignment_id = openapi.Parameter(
        'assignment-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the assignment you want to edit',
        type=openapi.TYPE_INTEGER,
        required=True,
    )
    
    instructor_id = openapi.Parameter(
        'instructor-id',
        in_=openapi.IN_QUERY,
        description='The `id` of the instructor you want to remove from the assignment',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=[assignment_id, instructor_id]
    )

    def delete(self, request):
        '''
        Delete data of an `instructor assignment`.
        '''
        
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( instr == False):
                        raise Exception("User account unauthorized!")
                    
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)
                
                assignment_to_delete_id = req_data.get('assignment-id')
                instructor_to_delete_id = int(req_data.get('instructor-id'))

                if(chechRole(instructor_to_delete_id,INSTRUCTOR) == False):
                    raise ApplicationError
                
                try:
                    assignment = get_object_or_404(Exhibition, id=assignment_to_delete_id, instructor_fk_id=decoded['user_id'])
                    instance = get_object_or_404(AssignedExhibitionInstructor,instructor_fk_id=instructor_to_delete_id,assignment_fk_id=assignment.id)
                    instance.delete()

                except Exception as e:
                    log.error("{} Internal error: {}".format(request_details(request), str(e)))
                    status_code, _ = get_code_and_response(['resource_not_found'])
                    content = {
                        MESSAGE: "This student assignment does not exist."
                    }
                    return Response(content, status=status_code)
            
                
                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                content[RESOURCE_OBJ] = "Deleted Instructor Assignment"
                
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
                
            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to delete student assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class AssignAdvisory(CreateAPIView):
    """
    post:
    Creates an exhibition advisory to an instructor
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = AssignAdvisorSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('AssignAdvisory', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,

    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))

        try:
                    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( instr == False):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = AssignAdvisorSerializer(data=req_data)
            
            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        instructor = req_data.get('instructor_fk')
                        if(chechRole(instructor,INSTRUCTOR) == False):
                            raise Exception
                        exhibition = req_data.get('assignment_fk')
                        assign = AssignedExhibitionInstructor(
                            instructor_fk_id=instructor,
                            assignment_fk_id=exhibition,
                        )
                        assign.save()
                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'exhibition advisory assignment'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response
                   

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create exhibition advisory assignment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getAllUsers(RetrieveAPIView):
    """
    get: Get all users in the database.
    """
    serializer_class = UserSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getAllUsers', response_types)
    
    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request, *args, **kwargs):
        '''
        Get all users in the database.
        '''
        error_message = "ERROR!"
        try:
                    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                error_message = "No access token provided!"
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                error_message = "Access token invalid!"
                raise Exception("Access token invalid!")

            if( instr == False):
                error_message = "User account unauthorized!"
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: error_message
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = UserSerializer(data=req_data)
        
            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                demo = ActiveUsers.objects.values()
                t_who = ActiveUsers.objects.filter(id=decoded['user_id']).values()[0]
                who = Users.objects.filter(id=t_who['user_fk_id']).values()[0]

                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message
            
                header_data = {}
                header_data["users"] = []
                for user in demo:
                    if(user['user_fk_id'] != decoded['user_id']):
                        real_user = Users.objects.filter(id=user['user_fk_id']).values()[0]
                        if(real_user['organization'] == who['organization']) or True:
                            temp = {}
                            temp["id"] = real_user['id']
                            temp["email"] = real_user['email']
                            temp["name"] = real_user['name']
                            temp["surname"] = real_user['surname']
                            temp["role"] = real_user['role']
                            temp["organization"] = real_user['organization']
                            temp["class_level"] = real_user['class_level']

                            curr_chat_uuid = ""

                            curr_sender_fk_id = decoded['user_id']
                            curr_rcver_fk_id = real_user['id']

                            # Check if chat already exists between sender and receiver
                            comm_srv_row_obj = CommunicationService.objects.filter(
                                sender_fk_id=curr_sender_fk_id,
                                rcver_fk_id=curr_rcver_fk_id
                            ) | CommunicationService.objects.filter(
                                sender_fk_id=curr_rcver_fk_id,
                                rcver_fk_id=curr_sender_fk_id
                            )

                            comm_srv_row_obj = comm_srv_row_obj.first()

                            if comm_srv_row_obj:
                                log.debug("{} Chat exists. UUID: {}".format(request_details(request), comm_srv_row_obj.uuid))
                                curr_chat_uuid = comm_srv_row_obj.uuid
                            else:
                                with transaction.atomic():
                                    try:
                                        log.debug("{} Chat not exists. Will be created.".format(request_details(request)))
                                        comm_srv_uuid = generate_random_uuid()
                                        ts_now = now()

                                        new_comm_srv = CommunicationService(
                                            uuid=comm_srv_uuid,
                                            sender_fk_id=curr_sender_fk_id,
                                            rcver_fk_id=curr_rcver_fk_id,
                                            ts_added=ts_now,
                                        )
                                        new_comm_srv.save()
                                        log.debug("{} Chat created. uuid: {} sender: {} receiver: {}.".format(
                                                request_details(request),
                                                comm_srv_uuid,
                                                curr_sender_fk_id,
                                                curr_rcver_fk_id
                                            )
                                        )
                                        curr_chat_uuid = comm_srv_uuid
                                    except Exception as e:
                                        raise

                            temp["chat_uuid"] = curr_chat_uuid

                            header_data["users"].append(temp)
                        
                content[RESOURCE_OBJ] = header_data
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response
            
        
        except Exception as e:
           log.error("{} Internal error: {}".format(request_details(request), str(e)))
           status_code, _ = get_code_and_response(['internal_server_error'])
           content = {
               MESSAGE: "Failed to fetch user."
           }
           return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getAllUsersSameOrg(RetrieveAPIView):
    """
    get: Get all users in the database for the same organization.
    """
    serializer_class = UserSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]

    response_dict = build_fields('getAllUsersSameOrg', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request, *args, **kwargs):
        '''
        Get all users in the database.
        '''
        error_message = "ERROR!"
        try:

            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                error_message = "No access token provided!"
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                error_message = "Access token invalid!"
                raise Exception("Access token invalid!")

            if( instr == False):
                error_message = "User account unauthorized!"
                raise Exception("User account unauthorized!")

        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: error_message
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = UserSerializer(data=req_data)

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                demo = ActiveUsers.objects.values()
                t_who = ActiveUsers.objects.filter(id=decoded['user_id']).values()[0]
                who = Users.objects.filter(id=t_who['user_fk_id']).values()[0]

                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                header_data = {}
                header_data["users"] = []
                for user in demo:
                    if(user['user_fk_id'] != decoded['user_id']):
                        real_user = Users.objects.filter(id=user['user_fk_id']).values()[0]
                        if(real_user['organization'] == who['organization']):
                            temp = {}
                            temp["id"] = real_user['id']
                            temp["email"] = real_user['email']
                            temp["name"] = real_user['name']
                            temp["surname"] = real_user['surname']
                            temp["role"] = real_user['role']
                            temp["organization"] = real_user['organization']
                            temp["class_level"] = real_user['class_level']

                            is_curatorial_avail = False

                            curatorial_row = CuratorialStatus.objects.filter(
                                instructor_fk_id=decoded['user_id'],
                                student_fk_id=real_user['id'],
                                assignment_fk_id=req_data.get('id'),
                            )

                            if curatorial_row:
                                is_curatorial_avail = True

                            temp["is_curatorial_avail"] = is_curatorial_avail

                            curatorial_assessment_avail = False

                            curatorial_assessment_row = CuratorialGroupArtworks.objects.filter(
                                student_fk_id=real_user['id'],
                                assignment_fk_id=req_data.get('id'),
                            ).first()

                            if curatorial_assessment_row:
                                if curatorial_assessment_row.student_description:
                                    curatorial_assessment_avail = True

                            temp["is_curatorial_assessment_avail"] = curatorial_assessment_avail

                            curr_chat_uuid = ""

                            curr_sender_fk_id = decoded['user_id']
                            curr_rcver_fk_id = real_user['id']

                            # Check if chat already exists between sender and receiver
                            comm_srv_row_obj = CommunicationService.objects.filter(
                                sender_fk_id=curr_sender_fk_id,
                                rcver_fk_id=curr_rcver_fk_id
                            ) | CommunicationService.objects.filter(
                                sender_fk_id=curr_rcver_fk_id,
                                rcver_fk_id=curr_sender_fk_id
                            )

                            comm_srv_row_obj = comm_srv_row_obj.first()

                            if comm_srv_row_obj:
                                log.debug("{} Chat exists. UUID: {}".format(request_details(request), comm_srv_row_obj.uuid))
                                curr_chat_uuid = comm_srv_row_obj.uuid
                            else:
                                with transaction.atomic():
                                    try:
                                        log.debug("{} Chat not exists. Will be created.".format(request_details(request)))
                                        comm_srv_uuid = generate_random_uuid()
                                        ts_now = now()

                                        new_comm_srv = CommunicationService(
                                            uuid=comm_srv_uuid,
                                            sender_fk_id=curr_sender_fk_id,
                                            rcver_fk_id=curr_rcver_fk_id,
                                            ts_added=ts_now,
                                        )
                                        new_comm_srv.save()
                                        log.debug("{} Chat created. uuid: {} sender: {} receiver: {}.".format(
                                                request_details(request),
                                                comm_srv_uuid,
                                                curr_sender_fk_id,
                                                curr_rcver_fk_id
                                            )
                                        )
                                        curr_chat_uuid = comm_srv_uuid
                                    except Exception as e:
                                        raise

                            temp["chat_uuid"] = curr_chat_uuid

                            header_data["users"].append(temp)

                content[RESOURCE_OBJ] = header_data
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response


        except Exception as e:
           log.error("{} Internal error: {}".format(request_details(request), str(e)))
           status_code, _ = get_code_and_response(['internal_server_error'])
           content = {
               MESSAGE: "Failed to fetch user."
           }
           return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getAvailableInstructors(RetrieveAPIView):
    """
    get: Get all instructors in the same organization as student.
    """
    serializer_class = UserSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]

    response_dict = build_fields('getAvailableInstructors', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def get(self, request, *args, **kwargs):
        '''
        Get all instructors in the same organization as student.
        '''
        error_message = "ERROR!"
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                error_message = "No access token provided!"
                raise Exception("No access token provided!")

            tkn_okay, student, decoded = at.authenticateStudent(request,settings)
            if( tkn_okay == False):
                error_message = "Access token invalid!"
                raise Exception("Access token invalid!")

            if( student == False):
                error_message = "User account unauthorized!"
                raise Exception("User account unauthorized!")

        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: error_message
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = UserSerializer(data=req_data)

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                demo = ActiveUsers.objects.values()
                t_who = ActiveUsers.objects.filter(id=decoded['user_id']).values()[0]
                who = Users.objects.filter(id=t_who['user_fk_id']).values()[0]

                status_code, message = get_code_and_response(['success'])
                content = {}
                content[MESSAGE] = message

                header_data = {}
                header_data["users"] = []
                for user in demo:
                    if(user['user_fk_id'] != decoded['user_id']):
                        real_user = Users.objects.filter(id=user['user_fk_id']).values()[0]
                        if(real_user['organization'] == who['organization'] and real_user['role'] == INSTRUCTOR):
                            temp = {}
                            temp["id"] = real_user['id']
                            temp["email"] = real_user['email']
                            temp["name"] = real_user['name']
                            temp["surname"] = real_user['surname']
                            temp["role"] = real_user['role']
                            temp["organization"] = real_user['organization']

                            curr_chat_uuid = ""

                            curr_sender_fk_id = decoded['user_id']
                            curr_rcver_fk_id = real_user['id']

                            # Check if chat already exists between sender and receiver
                            comm_srv_row_obj = CommunicationService.objects.filter(
                                sender_fk_id=curr_sender_fk_id,
                                rcver_fk_id=curr_rcver_fk_id
                            ) | CommunicationService.objects.filter(
                                sender_fk_id=curr_rcver_fk_id,
                                rcver_fk_id=curr_sender_fk_id
                            )

                            comm_srv_row_obj = comm_srv_row_obj.first()

                            if comm_srv_row_obj:
                                log.debug("{} Chat exists. UUID: {}".format(request_details(request), comm_srv_row_obj.uuid))
                                curr_chat_uuid = comm_srv_row_obj.uuid
                            else:
                                with transaction.atomic():
                                    try:
                                        log.debug("{} Chat not exists. Will be created.".format(request_details(request)))
                                        comm_srv_uuid = generate_random_uuid()
                                        ts_now = now()

                                        new_comm_srv = CommunicationService(
                                            uuid=comm_srv_uuid,
                                            sender_fk_id=curr_sender_fk_id,
                                            rcver_fk_id=curr_rcver_fk_id,
                                            ts_added=ts_now,
                                        )
                                        new_comm_srv.save()
                                        log.debug("{} Chat created. uuid: {} sender: {} receiver: {}.".format(
                                                request_details(request),
                                                comm_srv_uuid,
                                                curr_sender_fk_id,
                                                curr_rcver_fk_id
                                            )
                                        )
                                        curr_chat_uuid = comm_srv_uuid
                                    except Exception as e:
                                        raise

                            temp["chat_uuid"] = curr_chat_uuid

                            header_data["users"].append(temp)

                content[RESOURCE_OBJ] = header_data
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

        except Exception as e:
           log.error("{} Internal error: {}".format(request_details(request), str(e)))
           status_code, _ = get_code_and_response(['internal_server_error'])
           content = {
               MESSAGE: "Failed to fetch user."
           }
           return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class getFilteredExhibitions(RetrieveAPIView):
    """
    get: Get all temporary stored exhibitions of an instructor in the database.
    """
    serializer_class = FilterExhibitionSerializer
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
    ]
    
    response_dict = build_fields('getFilteredExhibitions', response_types)
    
    parameters = openapi.Parameter(
        'status',
        in_=openapi.IN_QUERY,
        description='The status of exhibitions you want to fetch.',
        type=openapi.TYPE_STRING,
        required=True,
    )
    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters = [parameters],
    )
    def get(self, request, *args, **kwargs):
        '''
        Get all temporary stored exhibitions of an instructor in the database.
        '''
        error_message = "ERROR!"
        try:
                    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                error_message = "No access token provided!"
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                error_message = "Access token invalid!"
                raise Exception("Access token invalid!")

            if( instr == False):
                error_message = "User account unauthorized!"
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: error_message
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = FilterExhibitionSerializer(data=req_data)
            status_flag = req_data.get('status')
            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    exh_list = Exhibition.objects.filter(instructor_fk_id=decoded['user_id'],status=status_flag).values()
                    exh_list2 = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=decoded["user_id"]).values()
                    
                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    
                
                    header_data = {}
                    header_data["exhibitions"] = []
                    for ex in exh_list:
                        temp = {}
                        temp["id"] = ex['id']
                        temp["title"] = ex['exhibition_title']
                        temp["start_date"] = ex['start_date']
                        temp["end_date"] = ex['end_date']
                        temp["space"] = ex['space_assign']
                        temp["description"] = ex['message']
                        temp["thumbnail"] = ex['image']
                        temp["status"] = ex['status']
                        listStuds = AssignedExhibitionStudents.objects.filter(assignment_fk_id=ex['id']).values()
                        temp["participants"] = len(listStuds)
                        header_data["exhibitions"].append(temp)
                        
                    for indoor2 in exh_list2:
                        indoor = Exhibition.objects.filter(id=indoor2["assignment_fk_id"],status=status_flag).values()
                        if(len(indoor) == 1):
                            indoor = indoor[0]
                            temp = {}
                            temp["id"] = indoor['id']
                            temp["title"] = indoor['exhibition_title']
                            temp["start_date"] = indoor['start_date']
                            temp["end_date"] = indoor['end_date']
                            temp["description"] = indoor['message']
                            temp["thumbnail"] = indoor['image']
                            temp["status"] = indoor['status']
                            temp["thumbnail"] = indoor['image']
                            listStuds = AssignedExhibitionStudents.objects.filter(assignment_fk_id=indoor['id']).values()
                            temp["participants"] = len(listStuds)
                            header_data["exhibitions"].append(temp)
                        
                    content[RESOURCE_OBJ] = header_data
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
            
        
        except Exception as e:
           log.error("{} Internal error: {}".format(request_details(request), str(e)))
           status_code, _ = get_code_and_response(['internal_server_error'])
           content = {
               MESSAGE: "Failed to fetch exhibitions."
           }
           return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
  

def editor(request):
    template = loader.get_template('web_app/editor/editor.html')
    
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])
    
    assigned_id = request.GET.get('assign')
    try:
        temp_id = request.GET.get('temp')
        if not temp_id:
            raise Exception
        crass = VR_Templates.objects.filter(id =temp_id ).values()
        if not crass:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        
        demo = VR_Templates.objects.filter(id=temp_id).values()
        temp = demo[0]['basis']
        filename = temp[1:len(temp)]
        payload = open(filename, "r").read()
        
        context = {
		    'title': "VR Editor",
		    'header_content': 'Index header content',
            'assignment_id': assigned_id,
            'user': caller,
            'basis': payload,
            'exh_id': request.GET.get('assign'),
            'temp_id': request.GET.get('temp'),
            'script': ' ',
            'reloaded' : 0
	    }   
    except Exception:
        ready = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id =decoded['user_id']).values()
        if not ready:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        
        name = "media/" + ready[0]['vr_exhibition']
        payload = open(name, "r").read()
        
        try:
            name = "media/" + ready[0]['vr_script']
            ac = open(name, "r").read()
        except Exception:
            ac = ' '

        context = {
		    'title': "VR Editor",
		    'header_content': 'Index header content',
            'assignment_id': assigned_id,
            'user': caller,
            'basis': payload ,
            'exh_id': assigned_id,
            'temp_id': 0,
            'x_script' : ac,
            'reloaded' : 1
	    }   
        
        
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    

    
    return HttpResponse(template.render(context, request)) 


def editorv2(request):
    template = loader.get_template('web_app/editor_v2/editor.html')
    
    access_tkn = request.COOKIES.get('access_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False and artist == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    assigned_id = request.GET.get('assign')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    exists = False

    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=assigned_id,
        student_fk_id=decoded['user_id']
    ).values('artwork_fk')

    selected_artworks_list = []

    for item in student_selected_artworks:
        selected_artworks_list.append(item.get('artwork_fk'))

    artworks_2d_rows = Artwork.objects.filter(id__in=selected_artworks_list, art_type="2d")

    for item in artworks_2d_rows:
        path_artwork = os.path.join("/code/media/", str(item.src))
        img = Image.open(path_artwork)
        item.width = img.width
        item.height = img.height

    artworks_3d_rows = Artwork.objects.filter(id__in=selected_artworks_list, art_type="3d")

    associated_3d_files_rows = ArtworksAssociatedMedia.objects.filter(
        Q(student_fk_id=decoded['user_id']) &
        Q(is_threed_file=True) &
        (Q(original_media_name="glb") | Q(original_media_name="gltf") | Q(original_media_name="obj") | Q(original_media_name="mtl"))
    )

    videos_rows = VideoFiles.objects.filter(user_fk_id=decoded['user_id'])

    try:
        ready = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id=decoded['user_id']).values()
        if len(ready) == 0:
            raise Exception
        exists = True
    except:
        exists = False
        log.debug("{} Exhibition does not exist".format(request_details(request)))

    context = {
	    'title': "VR Editor",
	    'header_content': 'Index header content',
        'user' : caller,
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'exh_id': assigned_id,
        'reloaded': exists,
        'artworks_2d_rows': artworks_2d_rows,
        'artworks_3d_rows': artworks_3d_rows,
        'associated_3d_files_rows': associated_3d_files_rows,
        'videos_rows': videos_rows,
	}   

    if exists == False:
        log.debug("{} Create modular space".format(request_details(request)))

        space = "web_app/editor_v2/shenkar_space.html"
        layout = "{}"
        startX = 0
        startY = 0

        if request.method == 'GET' and 'layout' in request.GET:
            layout = json.loads(request.GET.get('layout'))
            space = "web_app/editor_v2/modular_space.html"
        
        if request.method == 'GET' and 'shenkar' in request.GET:
            space = "web_app/editor_v2/shenkar_space.html"

        WALL_HEIGHT = request.GET.get('height') or 5

        if layout != "{}":
            for capital in layout.values():
                    if capital['starting']:
                        startX = int(capital['x']) +  float(WALLS/2)
                        startY = int(capital['y']) +  float(WALLS/2)

        context_1 = {
            'dimension': WALLS,
            'wall_height': WALL_HEIGHT,
            'half_dimension': float(WALLS/2),
            'walls': True,
            'startX': startX,
            'startY': startY,
            'counters': layout,
            'space': space,
        }   
        context.update(context_1)

    else:
        ready = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id =decoded['user_id']).values()
        if not ready:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        
        name = "media/" + ready[0]['vr_exhibition']
        payload = open(name, "r").read()
        
        try:
            name = "media/" + ready[0]['vr_script']
            ac = open(name, "r").read()
        except Exception:
            ac = ' '

        log.debug(f"{format(request_details(request))} Space exists at {ready[0]['vr_exhibition']}")
        context_3 = {
            'basis': payload ,
            'temp_id': 0,
            'x_script' : ac,
	    }   
        
        context.update(context_3)

        
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')

    return HttpResponse(template.render(context, request)) 


def vr_threed_viewer(request):
    template = loader.get_template('web_app/editor_v2/vr_threed_viewer.html')
    
    access_tkn = request.COOKIES.get('access_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False and artist == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    artwork_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])

    #artwork_row = ArtworksAssociatedMedia.objects.filter(artwork_fk_id=artwork_id, original_media_name="glb").first()
    artwork_row = ArtworksAssociatedMedia.objects.filter(
        Q(artwork_fk_id=artwork_id) & (Q(original_media_name="glb") | Q(original_media_name="obj") | Q(original_media_name="mtl") | Q(original_media_name="gltf"))
    )

    context = {
	    'title': "VR Viewer",
	    'header_content': 'Index header content',
        'user' : caller,
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'artwork_id': artwork_id,
        #'artwork_glb_src': artwork_row.media_src,
        'artwork_row': artwork_row,
	}   
    
    return HttpResponse(template.render(context, request)) 


def vr_viewer_exhibition_viewer(request):
    template = loader.get_template('web_app/editor_v2/vr_viewer_exhibition_viewer.html')
    
    access_tkn = request.COOKIES.get('access_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False and artist == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    artwork_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])

    artwork_row = ArtworksAssociatedMedia.objects.filter(artwork_fk_id=artwork_id, original_media_name="glb").first()

    context = {
	    'title': "VR Viewer",
	    'header_content': 'Index header content',
        'user' : caller,
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'artwork_id': artwork_id,
        'artwork_glb_src': artwork_row.media_src
	}   
    
    return HttpResponse(template.render(context, request)) 


def templateSelectionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    assigned_id = request.GET.get('assign')
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    print(cross)
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    crass = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id =decoded['user_id']).values()
    if  len(crass) > 0 :
        return HttpResponseRedirect('/web_app/student/editor/?assign=' + assigned_id)
    
    template = loader.get_template('web_app/student/templateSelection.html')
    exh = Exhibition.objects.filter(id=assigned_id).values()[0]
    inst = Users.objects.filter(id=exh['instructor_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    titleExh = exh['exhibition_title']
    sp_type = exh['space_assign']
    context = {
		'title': "Template Selection",
		'header_content': 'Index header content',
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition_title': titleExh,
        'space':  sp_type
	}   
    
    return HttpResponse(template.render(context, request)) 


def templateSelectionPagev2(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

    user_role = "artist"
    if(stu):
        user_role = "student"

    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( stu == False and artist == False):
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    assigned_id = request.GET.get('assign')
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    crass = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id =decoded['user_id']).values()
    if  len(crass) > 0 :
        return HttpResponseRedirect('/web_app/student/editor/?assign=' + assigned_id)
    
    template = loader.get_template('web_app/editor_v2/createPlace.html')
    exh = Exhibition.objects.filter(id=assigned_id).values()[0]
    inst = Users.objects.filter(id=exh['instructor_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    titleExh = exh['exhibition_title']
    sp_type = exh['space_assign']

    caller = get_object_or_404(Users,id = decoded['user_id'])

    context = {
		'title': "Template Selection",
		'header_content': 'Index header content',
        'userID': decoded['user_id'],
        'email': decoded['sub'],
        'name': decoded['name'],
        'surname': decoded['surname'],
        'organization': decoded['organization'],
        'role': decoded['role'],
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition_title': titleExh,
        'space':  sp_type,
        'user_role': user_role,
        'help_title': "Space Creation",
        'help_text': "Click on the following canvas to create a 3D space for your exhibition. The first room you create is by default the starting point of your exhibition and its marked with a different color. You can click on a block to remove it or make it the starting point (if there is no starting point). You cannot proceed without a starting point.",
        'user' : caller,
	}   
    
    return HttpResponse(template.render(context, request)) 


class createVR(CreateAPIView):
    """
    post:
    Creates a new vr exhibition instance
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = VRCreateSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('createVR', response_types)

    @swagger_auto_schema(
        responses=response_dict,
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, stud, decoded = at.authenticateStudent(request,settings)
            tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( stud == False and artist == False):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = VRCreateSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        post = request.POST.copy()
                        post['student_fk'] = decoded['user_id']
                        try:
                            test = VR_Exhibition.objects.get(student_fk_id = post['student_fk'], exhibition_fk_id=post['exhibition_fk'])
                            pathToDelete = "/code/media/" + str(test.vr_exhibition)
                            os.remove(pathToDelete)
                            try:
                                pathToDelete = "/code/media/" + str(test.vr_script)
                                os.remove(pathToDelete)
                                test.vr_script = request.FILES['vr_script']
                                test.save(update_fields=['vr_script'])
                            except Exception:
                                pass
                                
                            test.vr_exhibition = request.FILES['vr_exhibition']
                            id = test.id
                            test.save(update_fields=['vr_exhibition'])
                        except Exception:
                            form = VRExhibitionForm(post, request.FILES)
                            item = form.save()
                            id = item.id
                            
                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'vr_exhibition'
                        content[RESOURCE_ID] = id
                        
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create VR exhibition."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
    

class assignIndoorArtwork(CreateAPIView):
    """
    post:
    Creates a new artwork instance
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = GeeksSerializer
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error']
    ]
    response_dict = build_fields('assignIndoorArtwork', response_types)

    @swagger_auto_schema(
        responses=response_dict,
    )
    
    
    def post(self, request, *args, **kwargs):
        ''' Post:  Creates an indoor artwork list  '''
        
        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, stud, decoded = at.authenticateStudent(request,settings)
            tkn_okay, artist, decoded = at.authenticateArtist(request,settings)

            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( stud == False and artist == False):
                raise Exception("User account unauthorized!")
            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = GeeksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        get_object_or_404(VR_Exhibition,id=serialized_item.data['assignment'],student_fk_id = decoded['user_id'] )
                        timestamp_now = now()
                        for artwork in serialized_item.data['artworks']:
                            indoor_artwork, created = IndoorArtworks.objects.get_or_create(artwork_fk_id=artwork, vr_exhibition_fk_id=serialized_item.data['assignment'])
                            if created:
                                # means you have created a new indoor_artwork
                                pass
                            else:
                                # indoor_artwork just refers to the existing one
                                indoor_artwork.ts_last_updated = timestamp_now
                                indoor_artwork.save()

                        existing = IndoorArtworks.objects.filter(vr_exhibition_fk_id=serialized_item.data['assignment']).values('id','artwork_fk_id')
                        for ex in existing:
                            if ex['artwork_fk_id'] in serialized_item.data['artworks']:
                                pass
                            else:
                                IndoorArtworks.objects.get(id = ex['id']).delete()

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'indoor artwork list'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create indoor artwork list."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


def chat_box(request, chat_box_name):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    # Check if chat already exists between sender and receiver
    row_obj = CommunicationService.objects.filter(
        uuid=chat_box_name,
        sender_fk_id=decoded['user_id']
    ) | CommunicationService.objects.filter(
        uuid=chat_box_name,
        rcver_fk_id=decoded['user_id']
    )

    if not row_obj:
        log.debug("{} User: {} does not have access to chat: {}".format(
                request_details(request),
                decoded['user_id'],
                chat_box_name
            )
        )
        url = reverse('display403Page')
        return HttpResponseRedirect(url)

    chat_history_rows = Chat.objects.filter(
        comm_srvc_fk_id=chat_box_name
    )

    row_obj = row_obj.first()

    sender_fk_id = row_obj.sender_fk_id
    rcver_fk_id = row_obj.rcver_fk_id
    chat_other_user_fk_id = rcver_fk_id

    if sender_fk_id != decoded['user_id']:
        chat_other_user_fk_id = sender_fk_id
    else:
        chat_other_user_fk_id = rcver_fk_id

    user_row_obj = Users.objects.filter(id=chat_other_user_fk_id).first()

    user_name = user_row_obj.name
    user_surname = user_row_obj.surname

    chat_history = ""

    for c in chat_history_rows:
        sender_row = Users.objects.filter(
            id=c.sender_fk_id
        ).first()

        if c.sender_fk_id == decoded['user_id']:
            chat_history += "<span style='float:right;'><strong>" + c.msg + "</strong> " + sender_row.name + " (" + c.ts_added.strftime("%a, %d %b %Y %H:%M:%S GMT") + ")" + "</span></br>"
        else:
            chat_history += "<span><strong>" + c.msg + "</strong> " + sender_row.name + " (" + c.ts_added.strftime("%a, %d %b %Y %H:%M:%S GMT") + ")" + "</span></br>"

        chat_history += "</br>"

    if decoded['role'] == STUDENT:
        template = loader.get_template('web_app/chatbox_student.html')
    else:
        template = loader.get_template('web_app/chatbox.html')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])
    context = {
        'chat_box_name': chat_box_name,
        'chat_history': chat_history,
        'username': decoded['name'],
        'user_id': decoded['user_id'],
        'user_name': user_name,
        'user_surname': user_surname,
        'user' : caller,
    }
    return HttpResponse(template.render(context, request))


def blockchain(request):
    my_blockchain = Blockchain()

    my_blockchain.add_block("Transaction Data")
    my_blockchain.add_block("Another Transaction Data")

    my_blockchain.print_chain()

    print("is blockchain valid: ", my_blockchain.is_chain_valid())

    # block_to_modify = Block.objects.get(index=2)
    # block_to_modify.data = "Manipulated Data 2"
    # block_to_modify.save()

    my_blockchain.print_chain()

    print("is blockchain valid after manipulation: ", my_blockchain.is_chain_valid())
    return JsonResponse({'completed': True})
