from PIL import Image, ImageDraw, ImageFont
import os

WATERMARK_SRC =  "/code/web_app/static/web_app/media/logos/creams-icon-logo.png"
WATERMARK_EXTENSION = "_w"

def watermark_with_transparency(filename,EXTENSION=WATERMARK_EXTENSION,watermark_image_path=WATERMARK_SRC,TRANSPARENCY=60,new_path='/code/media/images/', old_path='/code/media/images/'):
    angle = 0
    alias = filename
    image_name =  old_path + filename
    base_image = Image.open(old_path + filename)
    filename, ext = os.path.splitext(image_name)
    test, none = os.path.splitext(alias)
    filename = new_path + test
    w_img, h_img = base_image.size
    basewidth = w_img
    watermark = Image.open(watermark_image_path)
    watermark = watermark.rotate(angle, expand=True)
    wpercent = (basewidth / float(watermark.size[0]))
    hpercent = h_img / float(watermark.size[1])
    if wpercent < hpercent:
        hsize = int((float(watermark.size[1]) * float(wpercent)))
        watermark = watermark.resize(( int(basewidth*0.8),  int(hsize*0.8)),  Image.Resampling.LANCZOS)
    else:
        wsize = int((float(watermark.size[0]) * float(hpercent)))
        watermark = watermark.resize(( int(wsize*0.8),int(h_img*0.8)),  Image.Resampling.LANCZOS)
    w_logo, h_logo = watermark.size
    center_y = int(h_img / 2)
    center_x = int(w_img / 2)
    top_y = center_y - int(h_logo / 2)
    left_x = center_x - int(w_logo / 2)
    if watermark.mode != 'RGBA':
        alpha = Image.new('L', (w_img, h_img), 255)
        watermark.putalpha(alpha)
    paste_mask = watermark.split()[3].point(lambda i: i * TRANSPARENCY / 100.)
    base_image.paste(watermark, (left_x, top_y), mask=paste_mask)

    new_filename = f"{filename}{EXTENSION}{ext}"
    base_image.save(new_filename)
    return new_filename

