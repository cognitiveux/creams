from .views import *

from django.http.response import FileResponse
from django.http import HttpResponseForbidden


def loginPage(request):
    access, payload = at.authenticate(request,settings)
    if access:
        if(payload.get('role') == INSTRUCTOR):
            url = reverse('teacherDashboardPage')
            
        elif(payload.get('role') == STUDENT):
            url = reverse('studentDashboardPage')
            
        elif(payload.get('role') == ARTIST):
            url = reverse('artistDashboardPage')
            
        return HttpResponseRedirect(url)
    template = loader.get_template('web_app/account-management/sign-in.html')
    context = {
		'title': "Login",
		'header_content': 'Index header content'
	}
    
    return HttpResponse(template.render(context, request))


def signUpPage(request):
    template = loader.get_template('web_app/account-management/sign-up.html')
    context = {
		'title': "Sign Up",
		'header_content': 'Index header content',
        'organizations' : [oc[0] for oc in OrganizationModel.ORGANIZATION_CHOICES],
        'roles' : [r[0] for r in RoleModel.ROLE_CHOICES],
        'student_choices' : [r[0] for r in ClassAndLevelModel.STUDENT_CHOICES],
        'teacher_choices' : [r[0] for r in ClassAndLevelModel.TEACHER_CHOICES],

	}

    return HttpResponse(template.render(context, request))


def verifyAccountPage(request):
    template = loader.get_template('web_app/account-management/verifyemail.html')
    context = {
		'title': "Verify Account",
		'header_content': 'Index header content',
	}

    return HttpResponse(template.render(context, request))


def media_access(request, path):    
    used_path = 'images/' + path
    image = Exhibition.objects.filter(image=used_path, status="Published").values()    
    if(len(image) == 1 ):
        image = image[0]
        log.debug("{} accessed {} as a thumbnail of a publically available exhibition".format(request_details(request), used_path))
        used_path = 'media/images/' + path
        img = open(used_path, 'rb')
        response = FileResponse(img)
        return response
    
    image = Artwork.objects.filter(src=used_path).values()
    if(len(image) == 1 ):
        image = image[0]
        outart = OutdoorArtwork.objects.filter(artwork_fk_id=image['id']).values()
        if ( len(outart) > 0 ):
            log.debug("{} accessed {} as an open image".format(request_details(request), used_path))
            used_path = 'media/images/' + path
            img = open(used_path, 'rb')
            response = FileResponse(img)
            return response

    access_granted,decoded = at.authenticate(request,settings)
    if access_granted:
        image = Artwork.objects.filter(src=used_path,user_fk_id=decoded['user_id']).values()
        if ( len(image) > 0 ):
            log.debug("{} accessed {} as an artwork owner".format(request_details(request), used_path))
            used_path = 'media/images/' + path
            img = open(used_path, 'rb')
            response = FileResponse(img)
            return response

        image = Exhibition.objects.filter(image=used_path).values()
        if ( len(image) > 0 ):
            image2 = image[0]
            coadv = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=image2["id"],instructor_fk_id=decoded['user_id']).values()
            main = image2['instructor_fk_id']
            stud = AssignedExhibitionStudents.objects.filter(assignment_fk_id=image2["id"],student_fk_id=decoded['user_id']).values()
            if ( len(coadv) > 0 ):
                log.debug("{} accessed exhibition {} thumbnail {} as a coadvisor".format(request_details(request),image2['id'], used_path))
                used_path = 'media/images/' + path
                img = open(used_path, 'rb')
                response = FileResponse(img)
                return response
            elif(main == decoded['user_id']):
                log.debug("{} accessed exhibition {} thumbnail {} as a main advisor".format(request_details(request),image2['id'], used_path))
                used_path = 'media/images/' + path
                img = open(used_path, 'rb')
                response = FileResponse(img)
                return response
            elif(len(stud) > 0):
                log.debug("{} accessed exhibition {} thumbnail {} as a student".format(request_details(request),image2['id'], used_path))
                used_path = 'media/images/' + path
                img = open(used_path, 'rb')
                response = FileResponse(img)
                return response

    used_path = 'media/images/' + path
    img = open(used_path, 'rb')
    response = FileResponse(img)
    return response
    log.debug("{} request access to {}".format(request_details(request),used_path))
    return HttpResponseForbidden('Not authorized to access this media. CHECK')      


def logout(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay,decoded = at.authenticate(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    response = HttpResponseRedirect('/web_app/login/')
    response.delete_cookie('access_tkn')
    response.delete_cookie('refresh_tkn')
    return response


def display403Page(request):
    template = loader.get_template('web_app/errors/403.html')
    context = {
		'title': "Unauthorized Access",
		'header_content': 'Index header content',
	}   

    
    return HttpResponse(template.render(context, request)) 


def forgotPasswordPage(request):
    access, payload = at.authenticate(request,settings)
    if access:
        if(payload.get('role') == INSTRUCTOR):
            url = reverse('teacherDashboardPage')
            
        elif(payload.get('role') == STUDENT):
            url = reverse('studentDashboardPage')
            
        return HttpResponseRedirect(url)
    template = loader.get_template('web_app/account-management/forgot-password.html')
    context = {
		'title': "Forgot Password",
		'header_content': 'Index header content',
	}   

    
    return HttpResponse(template.render(context, request)) 


def resetPasswordPage(request):
    access, payload = at.authenticate(request,settings)
    if access:
        if(payload.get('role') == INSTRUCTOR):
            url = reverse('teacherDashboardPage')
            
        elif(payload.get('role') == STUDENT):
            url = reverse('studentDashboardPage')
            
        return HttpResponseRedirect(url)
    template = loader.get_template('web_app/account-management/reset-password.html')
    context = {
		'title': "Reset Password",
		'header_content': 'Index header content',
	}   

    
    return HttpResponse(template.render(context, request)) 


def profile(request):
    template = loader.get_template('web_app/account-management/user_profile.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, decoded = at.authenticate(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    caller = get_object_or_404(Users,id = decoded['user_id'])
    context = {
		'title': "User Profile",
		'header_content': 'Index header content',
        'user': caller
	}
    
    return HttpResponse(template.render(context, request)) 


def user_model(request):
    template = loader.get_template('web_app/account-management/user_model.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, decoded = at.authenticate(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    user_model_csv = Users.objects.filter(id=decoded['user_id']).first()
    user_model_list = []
    if user_model_csv.user_model:
        user_model_list = [item.strip() for item in user_model_csv.user_model.split(',')]

    art_terms_list = []
    art_terms_rows = ArtTerms.objects.values()

    for item in art_terms_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in user_model_list:
            current_term['selected'] = True
        art_terms_list.append(current_term)

    spatial_context_terms_list = []
    spatial_context_rows = SpatialContextTerms.objects.values()

    for item in spatial_context_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in user_model_list:
            current_term['selected'] = True
        spatial_context_terms_list.append(current_term)

    context = {
		'title': "User Model",
		'header_content': 'Index header content',
        'user': caller,
        'art_terms_list': art_terms_list,
        'spatial_context_terms_list': spatial_context_terms_list,
	}
    
    return HttpResponse(template.render(context, request))


class saveUserModel(GenericAPIView):
    authentication_classes = [JWTAuthentication]
    serializer_class = saveUserModelSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('saveUserModel', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = saveUserModelSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if(tkn_okay == False):
                        raise Exception("Access token invalid!")
                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        art_terms = req_data.get('art_terms')
                        spatial_context_terms = req_data.get('spatial_context_terms')

                        try:
                            Users.objects.update_or_create(
                                id=decoded['user_id'],
                                defaults={
                                    'user_model': art_terms + "," + spatial_context_terms,
                                }
                            )
                        except Exception as e:
                            log.error("{} Failed to update. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'user_model'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200 #status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update selected artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])