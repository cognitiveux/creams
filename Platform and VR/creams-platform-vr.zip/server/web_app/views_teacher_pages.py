from .views import *
from django.http import HttpResponseNotAllowed

from .views_utils import getChatUUID


def teacherDashboardPage(request):

    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    #published_data , unpublished_data = getInstructorExhibitions(caller)
    
    vr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="vr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                vr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="vr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            vr_exhibitions.append(item)
    except:
        __main = []
    
    #vr_exhibitions = Exhibition.objects.filter(exhibition_type="vr").values()
    
    ar_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="ar")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                ar_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="ar").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            ar_exhibitions.append(item)
    except:
        __main = []
    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()

    mr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="mr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                mr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="mr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            mr_exhibitions.append(item)
    except:
        __main = []
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    template = loader.get_template('web_app/teacher/dashboard.html')
    context = {
		'title': "Teacher Dashboard",
		'header_content': 'Index header content',
        'user' : caller,
        #'unpublished': unpublished_data,
        #'published': published_data,
        'vr_exhibitions': vr_exhibitions,
        'ar_exhibitions': ar_exhibitions,
        'mr_exhibitions': mr_exhibitions,
	}   
        
    return HttpResponse(template.render(context, request))


def teacherDashboardPagePOC3(request):

    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    published_data , unpublished_data = getInstructorExhibitions(caller)

    template = loader.get_template('web_app/teacher/dashboard-poc3.html')
    context = {
		'title': "Teacher Dashboard",
		'header_content': 'Index header content',
        'user' : caller,
        'unpublished': unpublished_data,
        'published': published_data,
	}   
        
    return HttpResponse(template.render(context, request))


def teacherCommunicationPage(request):

    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])

    template = loader.get_template('web_app/teacher/communication.html')
    context = {
		'title': "Teacher Communication",
        'user' : caller,
	}

    return HttpResponse(template.render(context, request))


def teacherAssessmentMainPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        
    caller = get_object_or_404(Users,id = decoded['user_id'])
    input = request.GET.get('filter')
    #published_data , unpublished_data = getInstructorExhibitions(caller,input)

    vr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="vr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                vr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="vr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            vr_exhibitions.append(item)
    except:
        __main = []
    
    #vr_exhibitions = Exhibition.objects.filter(exhibition_type="vr").values()
    
    ar_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="ar")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                ar_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="ar").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            ar_exhibitions.append(item)
    except:
        __main = []
    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()

    mr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="mr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                mr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="mr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            mr_exhibitions.append(item)
    except:
        __main = []
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    template = loader.get_template('web_app/teacher/assessment_main_page.html')
    context = {
		'title': "Assessment",
		'header_content': 'Index header content',
        'user' : caller,
        'value': str(input),
        #'exhibitions': unpublished_data + published_data,
        "vr_exhibitions": vr_exhibitions,
        "ar_exhibitions": ar_exhibitions,
        "mr_exhibitions": mr_exhibitions,
        'help_title': "Assessment Page",
        'help_text': "You can click on any exhibition to see more details.",
	}   

    return HttpResponse(template.render(context, request))


def teacherExhibitionsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    #published_data , unpublished_data = getInstructorExhibitions(caller)
    
    vr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="vr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                vr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="vr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            vr_exhibitions.append(item)
    except:
        __main = []
    
    #vr_exhibitions = Exhibition.objects.filter(exhibition_type="vr").values()
    
    ar_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="ar")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                ar_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="ar").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            ar_exhibitions.append(item)
    except:
        __main = []
    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()

    mr_exhibitions = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            exh_items = Exhibition.objects.filter(id=item['assignment_fk_id'],exhibition_type="mr")
            for exh_item in exh_items:
                instructor = Users.objects.get(id=exh_item.instructor_fk_id)
                exh_item.instructor = instructor.name + " " + instructor.surname
                mr_exhibitions.append(exh_item)
    except:
        __coad = []
    try:
        __main = Exhibition.objects.filter(instructor_fk_id=caller.id,exhibition_type="mr").all()
        for item in __main:
            instructor = Users.objects.get(id=item.instructor_fk_id)
            item.instructor = instructor.name + " " + instructor.surname
            mr_exhibitions.append(item)
    except:
        __main = []
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    template = loader.get_template('web_app/teacher/exhibitions.html')
    context = {
		'title': "Teacher Exhibitions",
		'header_content': 'Index header content',
        'user' : caller,
        'vr_exhibitions': vr_exhibitions,
        'ar_exhibitions': ar_exhibitions,
        'mr_exhibitions': mr_exhibitions,
	}   
        
    return HttpResponse(template.render(context, request))


def teacherInitExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])
    spaces = []
    for r in ExhibitionSpaceModel.SPACE_CHOICES:
        spaces.append(r[0])

    template = loader.get_template('web_app/teacher/new_exhibition.html')

    context = {
		'title': "Initiate an exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'spaces': spaces,
        'art_terms_list': ArtTerms.objects.values(),
        'spatial_context_terms_list': SpatialContextTerms.objects.values(),
        'help_title': "Create Exhibition",
        'help_text': "You should fill all the required fields and click on the submit button.",
	}
    return HttpResponse(template.render(context, request))


# def teacherSelectStudentsAndCoadvisorsPage(request):
#     access_tkn = request.COOKIES.get('access_tkn')
#     refresh_tkn = request.COOKIES.get('refresh_tkn')
#     if not access_tkn:
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)
    
#     tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
#     if( tkn_okay == False):
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)
    
#     if( instr == False):
#         if decoded['role'] == STUDENT:
#             return HttpResponseRedirect('/web_app/student/dashboard/')
#         elif decoded['role'] == ARTIST:
#             return HttpResponseRedirect('/web_app/artist/dashboard/')
#         else:
#             return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
#     exhibition = get_object_or_404(Exhibition, id=request.GET.get('q'), instructor_fk_id=decoded['user_id'])

#     caller = get_object_or_404(Users,id = decoded['user_id'])
#     template = loader.get_template('web_app/teacher/select_students_and_coadvisors.html')
#     context = {
# 		'title': "Student Selection",
# 		'header_content': 'Index header content',
#         'edit' : False,
#         'user' : caller,
#         'exhibition' : exhibition,
#         'students' : [],
#         'instructors':[],
#         'help_title': "Select Students and Co-Advisors",
#         'help_text': "You should select the students you would like to assign to this exhibition. Additionally, you should select other instructors you would like to be co-advisors.",
# 	}   

    
#     return HttpResponse(template.render(context, request)) 


# def teacherAssessStudentsPage(request):
#     access_tkn = request.COOKIES.get('access_tkn')
#     refresh_tkn = request.COOKIES.get('refresh_tkn')
#     if not access_tkn:
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)
    
#     tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
#     if( tkn_okay == False):
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)
    
#     if( instr == False):
#         if decoded['role'] == STUDENT:
#             return HttpResponseRedirect('/web_app/student/dashboard/')
#         elif decoded['role'] == ARTIST:
#             return HttpResponseRedirect('/web_app/artist/dashboard/')
#         else:
#             return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
#     caller = get_object_or_404(Users,id = decoded['user_id'])
#     requested_exhibition_id = request.GET.get('q')

#     valid_q = Exhibition.objects.filter(id=requested_exhibition_id).values()
#     if(len(valid_q) == 0 ):
#         url = reverse('display403Page')
#         return HttpResponseRedirect(url)
    
#     valid_q = Exhibition.objects.filter(id=requested_exhibition_id,instructor_fk_id=caller.id).values()
#     exh = Exhibition.objects.filter(id=requested_exhibition_id).values()[0]
#     coadv = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exh["id"],instructor_fk_id=caller.id).values()

#     if(len(valid_q) == 0 and len(coadv) == 0):
#         url = reverse('display403Page')
#         return HttpResponseRedirect(url)
    
#     __list_students = AssignedExhibitionStudents.objects.filter(assignment_fk_id=requested_exhibition_id).values('student_fk_id')
#     students = []
#     for i in range(0,1):
#         for item in __list_students:
#             stud = Users.objects.get(id = item['student_fk_id'])
#             stud.head = stud.name[0]
#             stud.flag = decodeHeaderColouring(stud.head)
#             students.append(stud)

#     template = loader.get_template('web_app/teacher/list_students.html')
#     context = {
# 		'title': "Student Assessment",
# 		'header_content': 'Index header content',
#         'user' : caller,
#         'exh_id': requested_exhibition_id,
#         #'first': students[0:21],
#         #'rest': students[22:],
#         "students": students,
#         'help_title': "Student Selection",
#         'help_text': "You can click on the `Assess` button on any student card to assess them.",
# 	}   

    
#     return HttpResponse(template.render(context, request)) 


def teacherAssessmentPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])
    requested_exhibition_id = request.GET.get('exhibition')
    requested_student_id = request.GET.get('student')
    
    student = get_object_or_404(Users,id = requested_student_id, role= STUDENT)
    exhibition = get_object_or_404(Exhibition,id = requested_exhibition_id)
    exhibition.status_class = exhibitionStatusClassDecoder(exhibition.status)
    try:
        outdoor_exhibition = OutdoorExhibition.objects.get(exhibition_fk_id=exhibition.id)
        __outdoor_artworks = OutdoorArtwork.objects.filter(exhibition_fk_id=outdoor_exhibition.id).values()
    except:
        __outdoor_artworks = []

    try:
        indoor_exhibition = VR_Exhibition.objects.get(exhibition_fk_id=exhibition.id)
        __indoor_artworks = IndoorArtworks.objects.filter(vr_exhibition_fk_id=indoor_exhibition.id).values()
    except:
        __indoor_artworks = []

    artworks = []
    for item in __outdoor_artworks:
        actual_artwork =  get_object_or_404(Artwork,id = item['artwork_fk_id'])
        item['src'] = actual_artwork.src
        item['name'] = actual_artwork.name
        artworks.append(item)

    for item in __indoor_artworks:
        actual_artwork =  get_object_or_404(Artwork,id = item['artwork_fk_id'])
        item['src'] = actual_artwork.src
        item['name'] = actual_artwork.name
        artworks.append(item)

    valid_s = AssignedExhibitionStudents.objects.filter(student_fk_id=requested_student_id, assignment_fk=requested_exhibition_id).values()
    
    if(len(valid_s) == 0):
        url = reverse('display403Page')
        return HttpResponseRedirect(url)
    
    advisory = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id, assignment_fk=requested_exhibition_id).values()

    try:
        vr = VR_Exhibition.objects.get(exhibition_fk_id=requested_exhibition_id,student_fk_id=requested_student_id).id
        vr_exists = True
    except:
        vr = -1
        vr_exists = False
        
    if(len(advisory) != 0):
        template = loader.get_template('web_app/teacher/assessment/coadvisor.html')
        context = {
		    'title': "Student Assessment",
		    'header_content': 'Index header content',
            'user': caller,
            'student_id': requested_student_id,
            'exh_id': requested_exhibition_id,
            'vr' : vr,
            'exists':vr_exists
	    }   

        return HttpResponse(template.render(context, request)) 
    else:  
        template = loader.get_template('web_app/teacher/assessment/main_advisor.html')
        stud = Users.objects.filter(id=requested_student_id).values()[0]
        pre_ass = "Enter Assessment"

        try:
            uniqueCheck = GeneralAssessment.objects.filter(instructor_fk_id=decoded['user_id'],assignment_fk_id=requested_exhibition_id,student_fk_id=requested_student_id).values()[0]
            pre_ass = uniqueCheck['assessement']
        except Exception as e:
            pass

        context = {
	    	'title': "Student Assessment",
	    	'header_content': 'Index header content',
            'user': caller,
            'student_id':requested_student_id,
            'exh_id': requested_exhibition_id,
            'f_name': stud['name'],
            'l_name': stud['surname'],
            'assessment': pre_ass,
            'exhibition' : exhibition,
            'student' : student,
            'artworks': artworks,
            'vr' : vr,
            'exists':vr_exists
	    }   

        return HttpResponse(template.render(context, request)) 
    

def teacherEditExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    requested_id = request.GET.get('id')
    
    #exhibition = get_object_or_404(Exhibition, id=requested_id,instructor_fk_id=decoded['user_id'])

    exhibition = Exhibition.objects.none()
    exhibition_row = Exhibition.objects.filter(id=requested_id).first()
    if exhibition_row:
        if exhibition_row.instructor_fk_id == decoded['user_id']:
            exhibition = exhibition_row
        else:
            coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
            if coadvisor_row:
                exhibition = exhibition_row
    
    caller = get_object_or_404(Users,id = decoded['user_id'])
    spaces = []
    for r in ExhibitionSpaceModel.SPACE_CHOICES:
        spaces.append(r[0])

    personalization_model_list = []
    if exhibition:
        personalization_model_csv = Exhibition.objects.filter(id=exhibition.id).first()
        if personalization_model_csv.personalization_model:
            personalization_model_list = [item.strip() for item in personalization_model_csv.personalization_model.split(',')]

    art_terms_list = []
    art_terms_rows = ArtTerms.objects.values()

    for item in art_terms_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in personalization_model_list:
            current_term['selected'] = True
        art_terms_list.append(current_term)

    spatial_context_terms_list = []
    spatial_context_rows = SpatialContextTerms.objects.values()

    for item in spatial_context_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in personalization_model_list:
            current_term['selected'] = True
        spatial_context_terms_list.append(current_term)

    template = loader.get_template('web_app/teacher/edit_exhibition.html')
    context = {
		'title': "Edit Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibition' : exhibition,
        'spaces': spaces,
        'art_terms_list': art_terms_list,
        'spatial_context_terms_list': spatial_context_terms_list,
        'help_title': "Edit Exhibition",
        'help_text': "You should fill all the required fields and click on the submit button.",
	}
 
    return HttpResponse(template.render(context, request))
 

def teacherViewExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    requested_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    try:
        exhibition = get_object_or_404(Exhibition, id=requested_id,instructor_fk_id=caller.id)
        exhibition.main = True
    except:
        temp = get_object_or_404(AssignedExhibitionInstructor, instructor_fk_id=caller.id,assignment_fk_id = requested_id )
        exhibition = get_object_or_404(Exhibition, id=requested_id)
        exhibition.main = False
    template = loader.get_template('web_app/teacher/view_exhibition.html')

    exhibition.status_class = exhibitionStatusClassDecoder(exhibition.status)
    context = {
		'title': "View Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibition' : exhibition,

	}
 
    return HttpResponse(template.render(context, request))
 

def teacherEditStudentsAndCoadvisorsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    requested_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    
    #exhibition = get_object_or_404(Exhibition, id=requested_id,instructor_fk_id=decoded['user_id'])
    is_main_instructor = False
    exhibition = Exhibition.objects.none()
    exhibition_row = Exhibition.objects.filter(id=requested_id).first()
    if exhibition_row:
        if exhibition_row.instructor_fk_id == decoded['user_id']:
            exhibition = exhibition_row
            is_main_instructor = True
        else:
            coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
            if coadvisor_row:
                exhibition = exhibition_row
    
    template = loader.get_template('web_app/teacher/select_students_and_coadvisors.html')

    exhibition_item = Exhibition.objects.filter(
        id=requested_id
    ).first()
    if exhibition_item.exhibition_type == "vr":
        _students = AssignedExhibitionStudents.objects.filter(assignment_fk_id=exhibition.id).values('student_fk_id')
    elif exhibition_item.exhibition_type == "ar":
        _students = AR_Exhibition.objects.filter(exhibition_fk_id=exhibition.id).values('student_fk_id')
    elif exhibition_item.exhibition_type == "mr":
        _students = MR_Exhibition.objects.filter(exhibition_fk_id=exhibition.id).values('student_fk_id')

    _instructors = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition.id).values('instructor_fk_id') 

    students = []
    if exhibition_item.exhibition_type == "vr":
        for item in _students:
            students.append(item['student_fk_id'])
    elif exhibition_item.exhibition_type == "ar":
        for item in _students:
            students.append(item['student_fk_id'])
    elif exhibition_item.exhibition_type == "mr":
        for item in _students:
            students.append(item['student_fk_id'])

    instructors = []
    for item in _instructors:
        instructors.append(item['instructor_fk_id'])

    context = {
		'title': "View Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibition' : exhibition,
        'edit' : True,
        'students' : students,
        'instructors':instructors,
        "requested_id": requested_id,
        "is_main_instructor": is_main_instructor,
        'help_title': "Select Students and Co-Advisors",
        'help_text': "You should select the students you would like to assign to this exhibition. Additionally, you should select other instructors you would like to be co-advisors.",
	}
 
    return HttpResponse(template.render(context, request))


def teacherAssessStudentsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    requested_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    
    #exhibition = get_object_or_404(Exhibition, id=requested_id,instructor_fk_id=decoded['user_id'])
    
    exhibition = Exhibition.objects.none()
    exhibition_row = Exhibition.objects.filter(id=requested_id).first()
    if exhibition_row:
        if exhibition_row.instructor_fk_id == decoded['user_id']:
            exhibition = exhibition_row
        else:
            coadvisor_row = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition_row.id,instructor_fk_id=decoded['user_id'])
            if coadvisor_row:
                exhibition = exhibition_row
    
    template = loader.get_template('web_app/teacher/assess_students.html')

    #_students = AssignedExhibitionStudents.objects.filter(assignment_fk_id=exhibition.id).values('student_fk_id')
    #_instructors = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exhibition.id).values('instructor_fk_id') 

    # instructors = []
    # for item in _instructors:
    #     instructors.append(item['instructor_fk_id'])

    if exhibition.exhibition_type == "vr":
        _students = AssignedExhibitionStudents.objects.filter(assignment_fk_id=exhibition.id)
    elif exhibition.exhibition_type == "ar":
        _students = AR_Exhibition.objects.filter(exhibition_fk_id=exhibition.id)
    elif exhibition.exhibition_type == "mr":
        _students = MR_Exhibition.objects.filter(exhibition_fk_id=exhibition.id)
    
    students = []
    for item in _students:
        if exhibition.exhibition_type == "vr":
            oStudent_fk_id = item.student_fk_id
        elif exhibition.exhibition_type == "ar":
            oStudent_fk_id = item.student_fk_id
        elif exhibition.exhibition_type == "mr":
            oStudent_fk_id = item.student_fk_id

        students_row = Users.objects.filter(id=oStudent_fk_id).first()
        oStudent = {}
        oStudent["exhibition_id"] = requested_id
        oStudent["fullname"] = students_row.name + " " + students_row.surname
        oStudent["email"] = students_row.email
        oStudent["organization"] = students_row.organization
        oStudent["class_level"] = students_row.class_level
        oStudent["communication"] = "/web_app/chat/" + getChatUUID(decoded['user_id'], students_row.id)

        oStudent["is_curatorial_avail"] = False
        curatorial_row = CuratorialStatus.objects.filter(
            instructor_fk_id=decoded['user_id'],
            student_fk_id=students_row.id,
            assignment_fk_id=exhibition.id,
        )

        if curatorial_row:
            oStudent["is_curatorial_avail"] = True

        oStudent["curatorial_assessment_avail"] = False
        curatorial_assessment_row = CuratorialGroupArtworks.objects.filter(
            student_fk_id=students_row.id,
            assignment_fk_id=exhibition.id,
        ).first()

        if curatorial_assessment_row:
            if curatorial_assessment_row.student_description:
                oStudent["curatorial_assessment_avail"] = True
        
        oStudent["curatorial"] = "/web_app/teacher/curatorial/describe_groups/?id=" + str(requested_id) + "&student_id=" + str(students_row.id)
        oStudent["final_assessment"] = "/web_app/teacher/curatorial/final_assessment/?id=" + str(requested_id) + "&student_id=" + str(students_row.id)
        vr_exhibition_row = VR_Exhibition.objects.filter(exhibition_fk_id=exhibition.id,student_fk_id=oStudent_fk_id).first()
        oStudent["has_vr_exhibition"] = False
        if vr_exhibition_row:
            oStudent["has_vr_exhibition"] = True
            oStudent["vr_exhibition"] = "/web_app/visitor/vr_display/?assign=" + str(vr_exhibition_row.id)
        students.append(oStudent)

    context = {
		'title': "View Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibition' : exhibition,
        'edit' : True,
        'students' : students,
        #'instructors':instructors,
        "requested_id": requested_id,
        'help_title': "Select Students and Co-Advisors",
        'help_text': "You should select the students you would like to assign to this exhibition. Additionally, you should select other instructors you would like to be co-advisors.",
	}
 
    return HttpResponse(template.render(context, request))


def shenkar(request):
	template = loader.get_template('web_app/shenkar.html')
	context = {
		'title': "Index title",
		'header_content': 'Index header content'
	}
	return HttpResponse(template.render(context, request))


def teacherCuratorialDescribeGroupsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != INSTRUCTOR:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')
    student_fk_id = request.GET.get('student_id')

    # Check if instructor is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        instructor_fk_id=decoded['user_id'],
        student_fk_id=student_fk_id,
        assignment_fk_id=exhibition_id
    )

    student_groups_list = []

    student_groups_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=student_fk_id,
    )

    for item in student_groups_rows:
        current_group = {}
        current_group['id'] = item.id
        current_group['name'] = item.name
        current_group['student_description'] = item.student_description
        current_group['instructor_feedback'] = item.instructor_feedback
        student_groups_list.append(current_group)

    expanded_narrative = ""

    if student_groups_rows:
        expanded_narrative = student_groups_rows[0].expanded_description

    first_group_id = None

    if student_groups_list:
        first_group_id = student_groups_list[0]['id']

    first_group_artworks_list = []

    if first_group_id:
        curatorial_selected_artworks_rows = CuratorialSelectedArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=student_fk_id,
            group_fk_id = first_group_id
        )

        for item in curatorial_selected_artworks_rows:
            current_artwork = {}
            artwork_obj = Artwork.objects.filter(id=item.artwork_fk_id).first()
            current_artwork["id"] = item.artwork_fk_id

            if artwork_obj:
                current_artwork['src'] = artwork_obj.src
            else:
                current_artwork['src'] = ''

            first_group_artworks_list.append(current_artwork)

    template = loader.get_template('web_app/teacher/curatorial_describe_groups.html')
    context = {
		'title': "Teacher Curatorial Artworks Groups",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'student_id': student_fk_id,
        'groups': student_groups_list,
        'first_group_artworks_list': first_group_artworks_list,
        'expanded_narrative': expanded_narrative,
	}

    return HttpResponse(template.render(context, request))


class instructorCuratorialGetGroupArtworks(RetrieveAPIView):
    """
    get: Get data of all groups of artworks based on the exhibition.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = instructorCuratorialGetGroupArtworksSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('instructorCuratorialGetGroupArtworks', response_types)

    parameters = openapi.Parameter(
        'exhibition_id',
        in_=openapi.IN_QUERY,
        description='The ID of the exhibition',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    student_parameter = openapi.Parameter(
        'student_id',
        in_=openapi.IN_QUERY,
        description='The ID of the student',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[parameters, student_parameter]
    )
    def get(self, request):
        '''
        Get data of all groups of artworks based on the exhibition.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = instructorCuratorialGetGroupArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                        if( decoded['role'] != INSTRUCTOR):
                            raise Exception("User account unauthorized!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)

                    exhibition_id = req_data.get('exhibition_id')
                    student_id = req_data.get('student_id')
                    student_groups_list = []

                    student_groups_rows = CuratorialGroupArtworks.objects.filter(
                        assignment_fk_id=exhibition_id,
                        student_fk_id=student_id,
                    )

                    for item in student_groups_rows:
                        current_group = {}
                        current_group['id'] = item.id
                        current_group['name'] = item.name
                        current_group['student_description'] = item.student_description
                        current_group['instructor_feedback'] = item.instructor_feedback

                        current_group_images_list = []

                        curatorial_selected_artworks_rows = CuratorialSelectedArtworks.objects.filter(
                            assignment_fk_id=exhibition_id,
                            student_fk_id=student_id,
                            group_fk_id=item.id
                        )

                        for item in curatorial_selected_artworks_rows:
                            current_artwork = {}
                            artwork_obj = Artwork.objects.filter(id=item.artwork_fk_id).first()
                            current_artwork["id"] = item.artwork_fk_id

                            if artwork_obj:
                                current_artwork['src'] = str(artwork_obj.src)
                            else:
                                current_artwork['src'] = ''

                            current_group_images_list.append(current_artwork)

                        current_group["images_list"] = current_group_images_list
                        student_groups_list.append(current_group)

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_ARRAY] = student_groups_list
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of all groups of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class instructorCuratorialSaveGroupDescription(GenericAPIView):
    """
    post:
    Saves the instructor's description for the student's group of curatorial artworks
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = instructorCuratorialSaveGroupDescriptionSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('instructorCuratorialSaveGroupDescription', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Saves the instructor's description for the student's group of curatorial artworks  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = instructorCuratorialSaveGroupDescriptionSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != INSTRUCTOR):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        group_id = req_data.get('group_id')
                        student_id = req_data.get('student_id')
                        instructor_feedback = req_data.get('instructor_feedback')

                        try:
                            CuratorialGroupArtworks.objects.filter(
                                id=group_id,
                                student_fk_id=student_id,
                                assignment_fk_id=assignment_fk_id,
                            ).update(
                                instructor_feedback=instructor_feedback
                            )
                        except Exception as e:
                            log.error("{} Failed to update instructor feedback for group of artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save instructor feedback for group of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class instructorSaveAssessment(CreateAPIView):
    """
    post:
    Save the final assessment data (e.g., description and pdf file)
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = instructorSaveAssessmentSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'], # MISSING ON DESCRIPTION
        ['unsupported_media_type'],
        ['internal_server_error']
    ]

    parameters = openapi.Parameter(
        'exhibition_id',
        in_=openapi.IN_QUERY,
        description='The ID of the exhibition',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    student_parameter = openapi.Parameter(
        'student_id',
        in_=openapi.IN_QUERY,
        description='The ID of the student',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    response_dict = build_fields('instructorSaveAssessment', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        manual_parameters=[parameters, student_parameter]
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Save the final assessment data (e.g., description and pdf file)  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( decoded['role'] != INSTRUCTOR):
                raise Exception("User account unauthorized!")

        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = instructorSaveAssessmentSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))

                        file_obj = req_data.get('file')
                        instructor_final_assessment = req_data.get('final_assessment')
                        exhibition_id = req_data.get('exhibition_id')
                        student_id = req_data.get('student_id')

                        filename_uuid = generate_random_uuid()
                        file_src = "/code/media/assessments/" + filename_uuid + ".pdf"

                        with open(file_src, "wb+") as outf:
                            for chunk in file_obj.chunks():
                                outf.write(chunk)

                        CuratorialGroupArtworks.objects.filter(
                            student_fk_id=student_id,
                            assignment_fk_id=exhibition_id,
                        ).update(
                            instructor_final_assessment=instructor_final_assessment,
	                        final_assessment_src="/media/assessments/" + filename_uuid + ".pdf"
                        )

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'assessment'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save assessment."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


def teacherCuratorialFinalAssessmentPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != INSTRUCTOR:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')
    student_fk_id = request.GET.get('student_id')

    # Check if instructor is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        instructor_fk_id=decoded['user_id'],
        student_fk_id=student_fk_id,
        assignment_fk_id=exhibition_id
    )

    group_artwork_row = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=student_fk_id,
    ).first()

    exhibition_title = ""
    audience = ""
    instructor_final_assessment = ""
    final_assessment_src = ""
    final_assessment_src_exists = 0

    if group_artwork_row:
        exhibition_title = group_artwork_row.exhibition_title
        audience = group_artwork_row.audience
        instructor_final_assessment = group_artwork_row.instructor_final_assessment
        final_assessment_src = group_artwork_row.final_assessment_src

        if final_assessment_src:
            final_assessment_src_exists = 1

    template = loader.get_template('web_app/teacher/curatorial_final_assessment.html')
    context = {
		'title': "Teacher Curatorial Artworks Groups",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'student_id': student_fk_id,
        'exhibition_title': exhibition_title,
        'audience': audience,
        'final_assessment': instructor_final_assessment,
        'final_assessment_src': final_assessment_src,
        'final_assessment_src_exists': final_assessment_src_exists,
	}

    return HttpResponse(template.render(context, request))
