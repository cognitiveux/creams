from .views import *
from django.http import HttpResponseNotAllowed

from thefuzz import (
    fuzz,
    process
)


def studentDashboardPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller      = get_object_or_404(Users,id = decoded['user_id'])
    #exhibitions = getStudentExhibitions(caller)
    #artworks    = getStudentArtworks(caller)
    #twod_artworks = Artwork.objects.filter(art_type="2d").values()
    #threed_artworks = Artwork.objects.filter(art_type="3d").values()

    vr_exhibitions = []
    try:
        #__vrs = VR_Exhibition.objects.filter(student_fk_id=caller.id)
        __vrs = AssignedExhibitionStudents.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.assignment_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            crass = VR_Exhibition.objects.filter(exhibition_fk_id=item.assignment_fk_id, student_fk_id=caller.id).values('id')
            if crass.exists():
                item.student_vr_exhibition_id = crass[0]['id']
            else:
                item.student_vr_exhibition_id = None
            vr_exhibitions.append(item)
    except:
        __vrs = []

    #vr_exhibitions = Exhibition.objects.filter(exhibition_type="vr").values()
    
    ar_exhibitions = []
    try:
        __vrs = AR_Exhibition.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.exhibition_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            ar_exhibitions.append(item)
    except:
        __vrs = []
    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()
    
    mr_exhibitions = []
    try:
        __vrs = MR_Exhibition.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.exhibition_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            mr_exhibitions.append(item)
    except:
        __vrs = []
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    template = loader.get_template('web_app/student/dashboard.html')
    context = {
		'title': "Student Dashboard",
		'header_content': 'Index header content',
        'user' : caller,
        'vr_exhibitions': vr_exhibitions,
        'ar_exhibitions': ar_exhibitions,
        'mr_exhibitions': mr_exhibitions,
        #'twod_artworks': twod_artworks,
        #'threed_artworks': threed_artworks,
	}   

    return HttpResponse(template.render(context, request))


def studentArtworksPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller      = get_object_or_404(Users,id = decoded['user_id'])
    template = loader.get_template('web_app/student/list_artworks.html')
    #artworks    = getStudentArtworks(caller)
    twod_artworks = Artwork.objects.filter(user_fk_id=caller.id, art_type="2d").values()
    threed_artworks = Artwork.objects.filter(user_fk_id=caller.id, art_type="3d").values()
    
    context = {
		'title': "My Artworks",
		'header_content': 'Index header content',
        'user' : caller,
        'twod_artworks': twod_artworks,
        'threed_artworks': threed_artworks,
        #'first': artworks[0:21],
        #'second': artworks[22:]
	}   

    return HttpResponse(template.render(context, request))


def studenExhibitionsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/student/list_exhibitions.html')
    #vr_exhibitions = getStudentVrExhibitions(caller)
    #exhibitions = getStudentExhibitions(caller)

    vr_exhibitions = []
    try:
        #__vrs = VR_Exhibition.objects.filter(student_fk_id=caller.id)
        __vrs = AssignedExhibitionStudents.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.assignment_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            crass = VR_Exhibition.objects.filter(exhibition_fk_id=item.assignment_fk_id, student_fk_id=caller.id).values('id')
            if crass.exists():
                item.student_vr_exhibition_id = crass[0]['id']
            else:
                item.student_vr_exhibition_id = None
            vr_exhibitions.append(item)
    except:
        __vrs = []

    #vr_exhibitions = Exhibition.objects.filter(exhibition_type="vr").values()
    
    ar_exhibitions = []
    try:
        __vrs = AR_Exhibition.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.exhibition_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            ar_exhibitions.append(item)
    except:
        __vrs = []
    #ar_exhibitions = Exhibition.objects.filter(exhibition_type="ar").values()
    
    mr_exhibitions = []
    try:
        __vrs = MR_Exhibition.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.exhibition_fk_id)
            item.exhibition_title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            mr_exhibitions.append(item)
    except:
        __vrs = []
    #mr_exhibitions = Exhibition.objects.filter(exhibition_type="mr").values()

    context = {
		'title': "My Exhibitions",
		'header_content': 'Index header content',
        'user' : caller,
        'vr_exhibitions': vr_exhibitions,
        'ar_exhibitions': ar_exhibitions,
        'mr_exhibitions': mr_exhibitions,
	}   

    return HttpResponse(template.render(context, request))


def studentLoadExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/student/load_exhibition.html')

    context = {
		'title': "Load Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "Load Exhibition",
        'help_text': "Upload the source file that you downloaded from the VR Editor.",
	}
    return HttpResponse(template.render(context, request))


def studentSubmitArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/student/new_artwork.html')

    artwork_type = request.GET.get('artwork_type')

    context = {
		'title': "Submit an artwork",
		'header_content': 'Index header content',
        'user' : caller,
        'art_terms_list': ArtTerms.objects.values(),
        'spatial_context_terms_list': SpatialContextTerms.objects.values(),
        'help_title': "Create Artwork",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that width and height must be in meters.",
        'artwork_type': artwork_type,
	}
    return HttpResponse(template.render(context, request))


def studentSelectTemplatePage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])
    assigned_id = request.GET.get('assign')
    cross = AssignedExhibitionStudents.objects.filter(assignment_fk_id =assigned_id ,student_fk_id =decoded['user_id']).values()
    if not cross:
        return HttpResponseRedirect('/web_app/teacher/dashboard/')
    
    crass = VR_Exhibition.objects.filter(exhibition_fk_id=assigned_id,student_fk_id =decoded['user_id']).values()
    if  len(crass) > 0 :
        return HttpResponseRedirect('/web_app/student/editor/?assign=' + assigned_id)

    template = loader.get_template('web_app/student/templateSelection.html')
    exh = Exhibition.objects.filter(id=assigned_id).values()[0]
    inst = Users.objects.filter(id=exh['instructor_fk_id']).values()[0]
    full_name = inst["name"] + " " + inst["surname"]
    titleExh = exh['exhibition_title']
    sp_type = exh['space_assign']
    context = {
		'title': "Template Selection",
		'header_content': 'Index header content',
        'assignment_id': assigned_id,
        'user' : caller,
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition_title': titleExh,
        'space':  sp_type
	}   

    return HttpResponse(template.render(context, request)) 


def studentViewArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    is_owner = True
    requested_id = request.GET.get('id')
    student_id = decoded['user_id']
    caller = get_object_or_404(Users,id = decoded['user_id'])

    if( stu == False):
        tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
        if ( instr == False):
            return HttpResponseRedirect('/web_app/student/dashboard/')
        
        is_owner = False
        artwork = get_object_or_404(Artwork, id=requested_id)
        instructor_id = decoded['user_id']
        __coadv = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=instructor_id).values('assignment_fk_id')
        __main  = Exhibition.objects.filter(instructor_fk_id=instructor_id).values('id')
        instructors_exhibitions = []
        for item in __coadv:
            instructors_exhibitions.append(item['assignment_fk_id'])
        for item in __main:
            instructors_exhibitions.append(item['id'])

        listed_outdoor_artwork = OutdoorArtwork.objects.filter(artwork_fk_id=requested_id).values('exhibition_fk_id')
        for art in listed_outdoor_artwork:
            if art['exhibition_fk_id'] in instructors_exhibitions:
                student_id = artwork.user_fk_id
                caller = get_object_or_404(Users,id = decoded['user_id'])
            else:
                url = reverse('display403Page')

        creator_obj = get_object_or_404(Users,id=artwork.user_fk_id)
        creator = creator_obj.name + " " + creator_obj.surname        
    else:
        creator = caller.name + " " + caller.surname
        artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=student_id)
    
    if artwork.depth == None:
        artwork.depth = ""
    if artwork.width == None:
        artwork.width = ""
    if artwork.height == None:
        artwork.height = ""
    if artwork.unit == None:
        artwork.unit = ""
    if artwork.year == None:
        artwork.year = ""
        
    #artwork.depth = Decimal(artwork.depth).normalize()
    #artwork.width = Decimal(artwork.width).normalize()
    #artwork.height = Decimal(artwork.height).normalize()
    #artwork.unit = Decimal(artwork.unit).normalize()
    template = loader.get_template('web_app/student/view_artwork.html')
    context = {
		'title': "View Artwork",
        'base' : "user_base.html",
		'header_content': 'Index header content',
        'user' : caller,
        'artwork' : artwork,
        'is_owner': is_owner,
        'creator': creator,
	}

    return HttpResponse(template.render(context, request))
 

def studentEditArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    requested_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=decoded['user_id'])
    
    if artwork.depth == None:
        artwork.depth = ""
    if artwork.width == None:
        artwork.width = ""
    if artwork.height == None:
        artwork.height = ""
    if artwork.unit == None:
        artwork.unit = ""
    if artwork.year == None:
        artwork.year = ""
    #artwork.depth = Decimal(artwork.depth).normalize()
    #artwork.width = Decimal(artwork.width).normalize()
    #artwork.height = Decimal(artwork.height).normalize()
    #artwork.unit = Decimal(artwork.unit).normalize()

    template = loader.get_template('web_app/student/edit_artwork.html')

    personalization_model_csv = Artwork.objects.filter(id=artwork.id).first()
    personalization_model_list = []
    if personalization_model_csv.personalization_model:
        personalization_model_list = [item.strip() for item in personalization_model_csv.personalization_model.split(',')]

    art_terms_list = []
    art_terms_rows = ArtTerms.objects.values()

    for item in art_terms_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in personalization_model_list:
            current_term['selected'] = True
        art_terms_list.append(current_term)

    spatial_context_terms_list = []
    spatial_context_rows = SpatialContextTerms.objects.values()

    for item in spatial_context_rows:
        current_term = {}
        current_term['name'] = item.get("name")
        current_term['selected'] = False
        if item.get("name") in personalization_model_list:
            current_term['selected'] = True
        spatial_context_terms_list.append(current_term)

    context = {
		'title': "Edit Artwork",
		'header_content': 'Index header content',
        'artwork' : artwork,
        'user' : caller,
        'art_terms_list': art_terms_list,
        'spatial_context_terms_list': spatial_context_terms_list,
        'help_title': "Edit Artwork",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that width and height must be in meters.",
	}

    return HttpResponse(template.render(context, request))
 

def studentViewExhibitionPage(request):
    template = loader.get_template('web_app/student/view_exhibition.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller      = get_object_or_404(Users,id = decoded['user_id'])

    assigned_id = request.GET.get('assign')
    exhibition_assign  = get_object_or_404(AssignedExhibitionStudents,student_fk_id = caller.id , assignment_fk_id = assigned_id)

    exhibition  = get_object_or_404(Exhibition, id = assigned_id)
    exhibition.status_class = exhibitionStatusClassDecoder(exhibition.status)

    instr = get_object_or_404(Users,id = exhibition.instructor_fk_id)
    full_name = instr.name + " " + instr.surname
    
    indoor_link = "/web_app/student/template_selection/?assign=" + str(exhibition.id)
    if exhibition.space_assign == "Shenkar Gallery":
        indoor_link = "/web_app/student/editor/?assign=" + str(exhibition.id) + "&height=5&shenkar"

    context = {
		'title': "Exhibition",
		'header_content': 'Index header content',
        'user': caller,
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition': exhibition,
        'indoor_link': indoor_link,
	}

    return HttpResponse(template.render(context, request)) 


def studentAudioFilesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller      = get_object_or_404(Users,id = decoded['user_id'])
    template = loader.get_template('web_app/student/list_audiofiles.html')

    audios = AudioFiles.objects.filter(user_fk_id=caller.id)

    context = {
		'title': "My AudioFiles",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "My Audio Files Page",
        'help_text': "You can listen and delete you audio files.",
        "audios": audios,
	}   

    return HttpResponse(template.render(context, request))


def studentSubmitAudioFilePage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/student/new_audiofile.html')
    context = {
		'title': "Submit an audio file",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "Upload Audiofile",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that the file you try to upload must be and an audio file.",
	}
    return HttpResponse(template.render(context, request))


def studentExhibitionViewerPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    assigned_id = request.GET.get('assign')

    if( stu == False):
        tkn_okay, inst, decoded = at.authenticateInstructor(request,settings)
        if( inst == False):
            return HttpResponseRedirect('/web_app/teacher/dashboard/')

        try:
            virtual = VR_Exhibition.objects.get(id = assigned_id)
            exh = Exhibition.objects.get(id=virtual.exhibition_fk_id,instructor_fk_id = caller.id)
            titleExh = exh.exhibition_title
        except Exception:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
    else:
        try:
            virtual = VR_Exhibition.objects.get(id = assigned_id, student_fk_id= caller.id)
            exh = Exhibition.objects.get(id=virtual.exhibition_fk_id)
            titleExh = exh.exhibition_title
        except Exception:
            return HttpResponseRedirect('/web_app/student/dashboard/')

    
    temp = str(virtual.vr_exhibition)
    filename = "media/" + temp[0:len(temp)]
    payload = open(filename, "r").read()
    try:
        name = "media/" + str(virtual.vr_script)
        ac = open(name, "r").read()
    except Exception:
        ac = ' '
    template = loader.get_template('web_app/bases/vr_base.html')
    context = {
        'title': titleExh,
        'exh_id': virtual.id,
        'custom_exhibition': payload,
        'x_script':ac,
        'social' : False
	}

    return HttpResponse(template.render(context, request))


def studentVideoFilesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller      = get_object_or_404(Users,id = decoded['user_id'])
    template = loader.get_template('web_app/student/list_videos.html')

    videos = VideoFiles.objects.filter(user_fk_id=caller.id)

    context = {
		'title': "My Videos",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "My Video Files Page",
        'help_text': "You can view and delete you videos.",
        "videos": videos,
	}   

    return HttpResponse(template.render(context, request))


def studentSubmitVideoFilePage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/student/new_video.html')
    context = {
		'title': "Submit a video",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "Upload Video File",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that the file you try to upload must be and a video file.",
	}
    return HttpResponse(template.render(context, request))


def studentCommunicationPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    template = loader.get_template('web_app/student/communication.html')
    context = {
		'title': "Student Communication",
        'user' : caller,
	}

    return HttpResponse(template.render(context, request))


def studentCuratorialPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    exhibition_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])

    selected_artworks_completed = 0
    describe_arrangements_completed = 0
    read_feedback_completed = 0
    artworks_groups_completed = 0
    expand_narratives_completed = 0
    final_assessment_completed = 0

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=decoded['user_id'],
        assignment_fk_id=exhibition_id
    )

    # Check if student selected artworks was completed
    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    if student_selected_artworks:
        selected_artworks_completed = 1

    # Check if arrange artworks was completed
    all_artworks_groups_rows = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).count()

    if all_artworks_groups_rows != 0:
        artworks_groups_rows = CuratorialSelectedArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            group_fk_id__isnull=True
        ).count()

        if artworks_groups_rows == 0:
            artworks_groups_completed = 1

    # Check if description of groups was completed (not null, not empty)
    all_curatorial_groups_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    if all_curatorial_groups_rows:
        curatorial_null_groups_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            student_description__isnull=True
        ).count()

        curatorial_empty_groups_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            student_description__exact=''
        ).count()

        if curatorial_null_groups_rows == 0 and curatorial_empty_groups_rows == 0:
            describe_arrangements_completed = 1

    # Check if read and edited description was completed
    all_curatorial_not_read_edited_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).count()

    if all_curatorial_not_read_edited_rows != 0:
        curatorial_not_read_edited_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            is_edited=False
        ).count()

        if curatorial_not_read_edited_rows == 0:
            read_feedback_completed = 1

    # Check if expand narratives was completed
    all_curatorial_expand_narratives_null_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).count()

    if all_curatorial_expand_narratives_null_rows != 0:
        curatorial_expand_narratives_null_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            exhibition_title__isnull=True
        ).count()

        curatorial_expand_narratives_empty_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            exhibition_title__exact=''
        ).count()

        if curatorial_expand_narratives_null_rows == 0 and curatorial_expand_narratives_empty_rows == 0:
            expand_narratives_completed = 1

    # Check if should enable final assessment button
    all_final_assessment_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).count()

    if all_final_assessment_rows != 0:
        curatorial_final_assessment_null_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            instructor_final_assessment__isnull=True
        ).count()

        curatorial_final_assessment_empty_rows = CuratorialGroupArtworks.objects.filter(
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
            instructor_final_assessment__exact=''
        ).count()

        if curatorial_final_assessment_null_rows == 0 and curatorial_final_assessment_empty_rows == 0:
            final_assessment_completed = 1

    template = loader.get_template('web_app/student/curatorial.html')
    context = {
		'title': "Student Curatorial",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'selected_artworks_completed': selected_artworks_completed,
        'describe_arrangements_completed': describe_arrangements_completed,
        'read_feedback_completed': read_feedback_completed,
        'artworks_groups_completed': artworks_groups_completed,
        'expand_narratives_completed': expand_narratives_completed,
        'final_assessment_completed': final_assessment_completed,
	}

    return HttpResponse(template.render(context, request))


def studentCuratorialSelectArtworksPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=decoded['user_id'],
        assignment_fk_id=exhibition_id
    )

    artworks = Artwork.objects.filter(user_fk_id=caller)

    artworks_list = []

    for item in artworks:
        current_artwork = {}
        current_artwork['id'] = item.id
        current_artwork['src'] = item.src
        current_artwork['name'] = item.name
        current_artwork['art_type'] = item.art_type
        current_artwork['is_selected'] = 0
        artworks_list.append(current_artwork)

    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).values('artwork_fk')

    selected_artworks_list = []

    for item in student_selected_artworks:
        selected_artworks_list.append(item.get('artwork_fk'))

    for idx, item in enumerate(artworks_list):
        if item['id'] in selected_artworks_list:
            artworks_list[idx]['is_selected'] = 1

    template = loader.get_template('web_app/student/curatorial_select_artworks.html')
    context = {
		'title': "Student Curatorial Selected Artworks",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'first': artworks_list,
        #'second': artworks_list[22:]
	}

    return HttpResponse(template.render(context, request))


def studentMRSelectArtworksPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    mr_exhibition = get_object_or_404(
        MR_Exhibition,
        student_fk_id=decoded['user_id'],
        id=exhibition_id
    )

    artworks = Artwork.objects.filter(user_fk_id=caller)

    artworks_list = []

    for item in artworks:
        current_artwork = {}
        current_artwork['id'] = item.id
        current_artwork['src'] = item.src
        current_artwork['name'] = item.name
        current_artwork['art_type'] = item.art_type
        current_artwork['is_selected'] = 0
        artworks_list.append(current_artwork)

    student_selected_artworks = MRArtworks.objects.filter(
        mr_exhibition_fk=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).values('artwork_fk')

    selected_artworks_list = []

    for item in student_selected_artworks:
        selected_artworks_list.append(item.get('artwork_fk'))

    for idx, item in enumerate(artworks_list):
        if item['id'] in selected_artworks_list:
            artworks_list[idx]['is_selected'] = 1

    template = loader.get_template('web_app/student/mr_select_artworks.html')
    context = {
		'title': "Student MR Selected Artworks",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'first': artworks_list,
        #'second': artworks_list[22:]
	}

    return HttpResponse(template.render(context, request))


def studentARSelectArtworksPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    ar_exhibition = get_object_or_404(
        AR_Exhibition,
        student_fk_id=decoded['user_id'],
        id=exhibition_id
    )

    artworks = Artwork.objects.filter(user_fk_id=caller)

    artworks_list = []

    for item in artworks:
        current_artwork = {}
        current_artwork['id'] = item.id
        current_artwork['src'] = item.src
        current_artwork['name'] = item.name
        current_artwork['art_type'] = item.art_type
        current_artwork['lat'] = ""
        current_artwork['lng'] = ""
        current_artwork['is_selected'] = 0
        artworks_list.append(current_artwork)

    student_selected_artworks = ARArtworks.objects.filter(
        ar_exhibition_fk=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).values('artwork_fk')

    selected_artworks_list = []

    for item in student_selected_artworks:
        selected_artworks_list.append(item.get('artwork_fk'))

    for idx, item in enumerate(artworks_list):
        if item['id'] in selected_artworks_list:
            artworks_list[idx]['is_selected'] = 1
            oArtwork = ARArtworks.objects.filter(ar_exhibition_fk=exhibition_id, student_fk_id=decoded['user_id'], artwork_fk_id=item['id']).first()
            if oArtwork.lat and oArtwork.lon:
                artworks_list[idx]['lat'] = oArtwork.lat
                artworks_list[idx]['lng'] = oArtwork.lon

    template = loader.get_template('web_app/student/ar_select_artworks.html')
    context = {
		'title': "Student AR Selected Artworks",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'first': artworks_list,
        #'second': artworks_list[22:]
	}

    return HttpResponse(template.render(context, request))


class studentCuratorialSaveSelectedArtworks(GenericAPIView):
    """
    post:
    Update the curatorial artworks based on the students' selections
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialSaveSelectedArtworksSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentCuratorialSaveSelectedArtworks', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Update the curatorial artworks based on the students' selections   '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialSaveSelectedArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        selected_data = req_data.get('selected_data')
                        artwork_ids = selected_data.get('artwork_ids')

                        try:
                            # First, delete any selected artworks rows by excluding the current student's selections
                            CuratorialSelectedArtworks.objects.filter(
                                assignment_fk_id=assignment_fk_id,
                                student_fk_id=decoded['user_id']
                            ).exclude(
                                artwork_fk_id__in=artwork_ids
                            ).delete()

                            ts_now = now()

                            # Then, update the ts_last_updated field or çreate a new row if any of the selected artworks doesn't exist already in db
                            for item in artwork_ids:
                                CuratorialSelectedArtworks.objects.update_or_create(
                                    artwork_fk_id=item,
                                    student_fk_id=decoded['user_id'],
                                    assignment_fk_id=assignment_fk_id,
                                    defaults={
                                        'ts_last_updated': ts_now,
                                    }
                                )
                        except Exception as e:
                            log.error("{} Failed to update selected artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200 #status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update selected artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentMRSaveSelectedArtworks(GenericAPIView):
    """
    post:
    Update the curatorial artworks based on the students' selections
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentMRSaveSelectedArtworksSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentMRSaveSelectedArtworks', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Update the curatorial artworks based on the students' selections   '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentMRSaveSelectedArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        mr_exhibition_fk_id = req_data.get('mr_exhibition_fk')
                        selected_data = req_data.get('selected_data')
                        artwork_ids = selected_data.get('artwork_ids')

                        try:
                            # First, delete any selected artworks rows by excluding the current student's selections
                            MRArtworks.objects.filter(
                                mr_exhibition_fk_id=mr_exhibition_fk_id,
                                student_fk_id=decoded['user_id']
                            ).exclude(
                                artwork_fk_id__in=artwork_ids
                            ).delete()

                            ts_now = now()

                            # Then, update the ts_last_updated field or çreate a new row if any of the selected artworks doesn't exist already in db
                            for item in artwork_ids:
                                MRArtworks.objects.update_or_create(
                                    artwork_fk_id=item,
                                    student_fk_id=decoded['user_id'],
                                    mr_exhibition_fk_id=mr_exhibition_fk_id,
                                    defaults={
                                        'ts_last_updated': ts_now,
                                    }
                                )
                        except Exception as e:
                            log.error("{} Failed to update selected artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200 #status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update selected artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentARSaveSelectedArtworks(GenericAPIView):
    authentication_classes = [JWTAuthentication]
    serializer_class = studentARSaveSelectedArtworksSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentARSaveSelectedArtworks', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentARSaveSelectedArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        ar_exhibition_fk_id = req_data.get('ar_exhibition_fk')
                        selected_data = req_data.get('selected_data')
                        artwork_ids = selected_data.get('artwork_ids')
                        selected_latlng_data = req_data.get('selected_latlng_data')

                        try:
                            # First, delete any selected artworks rows by excluding the current student's selections
                            ARArtworks.objects.filter(
                                ar_exhibition_fk_id=ar_exhibition_fk_id,
                                student_fk_id=decoded['user_id']
                            ).exclude(
                                artwork_fk_id__in=artwork_ids
                            ).delete()

                            ts_now = now()

                            # Then, update the ts_last_updated field or çreate a new row if any of the selected artworks doesn't exist already in db
                            #for item in artwork_ids:
                            for item in selected_latlng_data:
                                print(item.get("lat"))
                                print(item.get("lng"))
                                ARArtworks.objects.update_or_create(
                                    artwork_fk_id=item.get("id"),
                                    student_fk_id=decoded['user_id'],
                                    ar_exhibition_fk_id=ar_exhibition_fk_id,
                                    defaults={
                                        'lat': item.get("lat") or None,
                                        'lon': item.get("lng") or None,
                                        'ts_last_updated': ts_now,
                                    }
                                )
                        except Exception as e:
                            log.error("{} Failed to update selected artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200 #status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to update selected artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentCuratorialSaveGroupArtworks(GenericAPIView):
    """
    post:
    Create a new group of curatorial artworks based on the students' selections
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialSaveGroupArtworksSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentCuratorialSaveSelectedArtworks', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Create a new group of curatorial artworks based on the students' selections  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialSaveGroupArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        group_name = req_data.get('group_name')

                        try:
                            new_group = CuratorialGroupArtworks(
                                name=group_name,
                                student_fk_id=decoded['user_id'],
                                assignment_fk_id=assignment_fk_id,
                            )
                            new_group.save()
                        except Exception as e:
                            log.error("{} Failed to create group of artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Unable to create group of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentCuratorialUpdateGroupArtworks(GenericAPIView):
    """
    post:
    Update the group of curatorial artworks based on the students' selections
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialUpdateGroupArtworksSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentCuratorialUpdateGroupArtworks', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Update the group of curatorial artworks based on the students' selections  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialUpdateGroupArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        artworks_groups_mapping = req_data.get('artworks_groups_mapping')

                        try:
                            # Case of assigning the groups to each artwork
                            for artwork_key, group_key in artworks_groups_mapping.items():
                                CuratorialSelectedArtworks.objects.filter(
                                    artwork_fk_id=artwork_key,
                                    student_fk_id=decoded['user_id'],
                                    assignment_fk_id=assignment_fk_id,
                                ).update(
                                    group_fk_id=group_key
                                )
                        except Exception as e:
                            log.error("{} Failed to update data for group of artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Unable to update data for group of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentCuratorialSaveGroupDescription(GenericAPIView):
    """
    post:
    Saves the student's description for the group of curatorial artworks
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialSaveGroupDescriptionSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentCuratorialSaveGroupDescription', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Saves the student's description for the group of curatorial artworks  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialSaveGroupDescriptionSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        group_id = req_data.get('group_id')
                        student_description = req_data.get('student_description')
                        is_edited = req_data.get('is_edited')

                        try:
                            if is_edited == True:
                                CuratorialGroupArtworks.objects.filter(
                                    id=group_id,
                                    student_fk_id=decoded['user_id'],
                                    assignment_fk_id=assignment_fk_id,
                                ).update(
                                    student_description=student_description,
                                    is_edited=True
                                )
                            else:
                                CuratorialGroupArtworks.objects.filter(
                                    id=group_id,
                                    student_fk_id=decoded['user_id'],
                                    assignment_fk_id=assignment_fk_id,
                                ).update(
                                    student_description=student_description
                                )
                        except Exception as e:
                            log.error("{} Failed to update student description for group of artworks. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save description for group of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


def studentCuratorialArtworksGroupsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Selected and Ungrouped Artworks
    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    selected_artworks_list = []

    for item in student_selected_artworks:
        current_artwork = {}
        current_artwork['id'] = item.artwork_fk_id
        artwork_obj = Artwork.objects.filter(id=item.artwork_fk_id).first()

        if artwork_obj:
            current_artwork['src'] = artwork_obj.src
        else:
            current_artwork['src'] = ''

        current_artwork['name'] = artwork_obj.name
        current_artwork['art_type'] = artwork_obj.art_type

        group_obj = CuratorialGroupArtworks.objects.filter(
            id=item.group_fk_id,
            assignment_fk_id=exhibition_id,
            student_fk_id=decoded['user_id'],
        ).first()

        if group_obj:
            current_artwork['group_id'] = item.group_fk_id
            current_artwork['group_name'] = group_obj.name
        else:
            current_artwork['group_id'] = ''
            current_artwork['group_name'] = ''

        selected_artworks_list.append(current_artwork)

    student_groups_list = []

    student_groups_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    for item in student_groups_rows:
        current_group = {}
        current_group['id'] = item.id
        current_group['name'] = item.name
        student_groups_list.append(current_group)

    template = loader.get_template('web_app/student/curatorial_artworks_groups.html')
    context = {
		'title': "Student Curatorial Artworks Groups",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'first': selected_artworks_list,
        #'second': selected_artworks_list[22:],
        'groups': student_groups_list,
	}

    return HttpResponse(template.render(context, request))


class studentCuratorialGetGroupArtworks(RetrieveAPIView):
    """
    get: Get data of all groups of artworks for the student based on the exhibition.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialGetGroupArtworksSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('studentCuratorialGetGroupArtworks', response_types)

    parameters = openapi.Parameter(
        'exhibition_id',
        in_=openapi.IN_QUERY,
        description='The ID of the exhibition',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[parameters]
    )
    def get(self, request):
        '''
        Get data of all groups of artworks for the student based on the exhibition.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialGetGroupArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, decoded = at.authenticate(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                        if( decoded['role'] != STUDENT):
                            raise Exception("User account unauthorized!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)

                    exhibition_id = req_data.get('exhibition_id')
                    student_groups_list = []

                    student_groups_rows = CuratorialGroupArtworks.objects.filter(
                        assignment_fk_id=exhibition_id,
                        student_fk_id=decoded['user_id'],
                    )

                    for item in student_groups_rows:
                        current_group = {}
                        current_group['id'] = item.id
                        current_group['name'] = item.name
                        current_group['student_description'] = item.student_description
                        current_group['instructor_feedback'] = item.instructor_feedback
                        student_groups_list.append(current_group)

                    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
                        assignment_fk_id=exhibition_id,
                        student_fk_id=decoded['user_id'],
                    )

                    artworks_dct = {}
                    for stud_sel_art in student_selected_artworks:
                        if not stud_sel_art.group_fk_id:
                            artworks_dct[stud_sel_art.artwork_fk_id] = ""
                        else:
                            artworks_dct[stud_sel_art.artwork_fk_id] = stud_sel_art.group_fk_id

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_ARRAY] = student_groups_list
                    content[RESOURCE_OBJ] = artworks_dct
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of all groups of artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


def studentCuratorialDescribeGroupsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=decoded['user_id'],
        assignment_fk_id=exhibition_id
    )

    # Selected and Ungrouped Artworks
    student_selected_artworks = CuratorialSelectedArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        group_fk_id__isnull=True,
    )

    student_groups_list = []

    student_groups_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    for item in student_groups_rows:
        current_group = {}
        current_group['id'] = item.id
        current_group['name'] = item.name
        current_group['student_description'] = item.student_description
        student_groups_list.append(current_group)

    template = loader.get_template('web_app/student/curatorial_describe_groups.html')
    context = {
		'title': "Student Curatorial Artworks Groups",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'groups': student_groups_list,
	}

    return HttpResponse(template.render(context, request))


def studentCuratorialEditGroupsDescriptionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=decoded['user_id'],
        assignment_fk_id=exhibition_id
    )

    student_groups_list = []

    student_groups_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    )

    for item in student_groups_rows:
        current_group = {}
        current_group['id'] = item.id
        current_group['name'] = item.name
        current_group['student_description'] = item.student_description
        current_group['instructor_feedback'] = item.instructor_feedback
        student_groups_list.append(current_group)

    template = loader.get_template('web_app/student/curatorial_edit_groups_description.html')
    context = {
		'title': "Student Curatorial Artworks Edit Groups Description",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'groups': student_groups_list,
	}

    return HttpResponse(template.render(context, request))


def studentCuratorialExpandNarrativesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=decoded['user_id'],
        assignment_fk_id=exhibition_id
    )

    audience = [RoleModel.INSTRUCTOR, RoleModel.STUDENT, RoleModel.ARTIST]
    exhibition_title = ""
    expanded_description = ""

    curatorial_expand_narratives_rows = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=decoded['user_id'],
    ).first()

    if curatorial_expand_narratives_rows:
        exhibition_title = curatorial_expand_narratives_rows.exhibition_title
        expanded_description = curatorial_expand_narratives_rows.expanded_description

    template = loader.get_template('web_app/student/curatorial_expand_narratives.html')
    context = {
		'title': "Student Curatorial Expand Narratives",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'exhibition_title': exhibition_title,
        'expanded_description': expanded_description,
        'audience': audience
	}

    return HttpResponse(template.render(context, request))


class studentCuratorialSaveExpandedNarratives(GenericAPIView):
    """
    post:
    Saves the student's expanded narratives data for the curatorial artworks
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentCuratorialSaveExpandedNarrativesSerializer

    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'],
        ['internal_server_error'],
        ['resource_not_found', 'artwork'],
    ]
    response_dict = build_fields('studentCuratorialSaveExpandedNarratives', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Saves the student's expanded narratives data for the curatorial artworks  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentCuratorialSaveExpandedNarrativesSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                log.debug("{} VALID DATA".format(request_details(request)))
                try:
                    access_tkn = request.COOKIES.get('access_tkn')
                    refresh_tkn = request.COOKIES.get('refresh_tkn')
                    if not access_tkn:
                        raise Exception("No access token provided!")

                    tkn_okay, decoded = at.authenticate(request,settings)
                    if( tkn_okay == False):
                        raise Exception("Access token invalid!")

                    if( decoded['role'] != STUDENT):
                        raise Exception("User account unauthorized!")

                except Exception as e:
                        log.error("{} Internal error: {}".format(request_details(request), str(e)))
                        status_code, _ = get_code_and_response(['unauthorized'])
                        content = {
                            MESSAGE: "Access token is invalid."
                        }
                        return Response(content, status=status_code)

                with transaction.atomic():
                    try:
                        req_data = request.data
                        assignment_fk_id = req_data.get('assignment_fk')
                        exhibition_title = req_data.get('exhibition_title')
                        audience = req_data.get('audience')
                        expanded_description = req_data.get('expanded_description')

                        try:
                            CuratorialGroupArtworks.objects.filter(
                                student_fk_id=decoded['user_id'],
                                assignment_fk_id=assignment_fk_id,
                            ).update(
                                exhibition_title=exhibition_title,
                                audience=audience,
                                expanded_description=expanded_description
                            )
                        except Exception as e:
                            log.error("{} Failed to save the student's expanded narratives data. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = 200
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save the student's expanded narratives data."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


def studentCuratorialFinalAssessmentPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, student, decoded = at.authenticateStudent(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if decoded['role'] != STUDENT:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    caller = get_object_or_404(Users,id = decoded['user_id'])

    exhibition_id = request.GET.get('id')
    student_fk_id = decoded['user_id']

    # Check if student is allowed to access exhibition
    curatorial_status = get_object_or_404(
        CuratorialStatus,
        student_fk_id=student_fk_id,
        assignment_fk_id=exhibition_id
    )

    group_artwork_row = CuratorialGroupArtworks.objects.filter(
        assignment_fk_id=exhibition_id,
        student_fk_id=student_fk_id,
    ).first()

    exhibition_title = ""
    audience = ""
    instructor_final_assessment = ""
    final_assessment_src = ""

    if group_artwork_row:
        exhibition_title = group_artwork_row.exhibition_title
        audience = group_artwork_row.audience
        instructor_final_assessment = group_artwork_row.instructor_final_assessment
        final_assessment_src = group_artwork_row.final_assessment_src

    template = loader.get_template('web_app/student/curatorial_final_assessment.html')
    context = {
		'title': "Student Curatorial Artworks Final Assessment",
        'user' : caller,
        'exhibition_id': exhibition_id,
        'student_id': student_fk_id,
        'exhibition_title': exhibition_title,
        'audience': audience,
        'final_assessment': instructor_final_assessment,
        'final_assessment_src': final_assessment_src,
	}

    return HttpResponse(template.render(context, request))


def studentArtworkAssociatedMediaPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')

    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)

    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    is_owner = True
    requested_id = request.GET.get('id')
    student_id = decoded['user_id']
    caller = get_object_or_404(Users,id = decoded['user_id'])
    artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=student_id)

    associated_media_list = []

    associated_media_rows = ArtworksAssociatedMedia.objects.filter(
        artwork_fk_id=requested_id,
        student_fk_id=decoded['user_id'],
        is_threed_file=False,
    )

    for item in associated_media_rows:
        current_media = {}
        current_media['uuid'] = item.uuid
        current_media['media_src'] = item.media_src
        current_media['original_media_name'] = item.original_media_name
        associated_media_list.append(current_media)

    template = loader.get_template('web_app/student/artwork_associated_media.html')
    context = {
		'title': "Artwork Associated Media",
        'base' : "user_base.html",
        'user' : caller,
        'artwork' : artwork,
        'existing_media': associated_media_list,
	}

    return HttpResponse(template.render(context, request))


def studentArtworkThreedFilesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')

    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, stu, decoded = at.authenticateStudent(request,settings)

    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    is_owner = True
    requested_id = request.GET.get('id')
    student_id = decoded['user_id']
    caller = get_object_or_404(Users,id = decoded['user_id'])
    artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=student_id)

    associated_media_list = []

    associated_media_rows = ArtworksAssociatedMedia.objects.filter(
        artwork_fk_id=requested_id,
        student_fk_id=decoded['user_id'],
        is_threed_file=True,
    )

    for item in associated_media_rows:
        current_media = {}
        current_media['uuid'] = item.uuid
        current_media['media_src'] = item.media_src
        current_media['original_media_name'] = item.original_media_name
        associated_media_list.append(current_media)

    template = loader.get_template('web_app/student/artwork_threed_files.html')
    context = {
		'title': "Artwork 3D Files",
        'base' : "user_base.html",
        'user' : caller,
        'artwork' : artwork,
        'existing_media': associated_media_list,
	}

    return HttpResponse(template.render(context, request))


class studentSaveAssociatedMedia(CreateAPIView):
    """
    post:
    Save the associated media of an artwork
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentSaveAssociatedMediaSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'], # MISSING ON DESCRIPTION
        ['unsupported_media_type'],
        ['internal_server_error']
    ]

    response_dict = build_fields('studentSaveAssociatedMedia', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        manual_parameters=[]
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Save the associated media of an artwork  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, decoded = at.authenticate(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            if( decoded['role'] != STUDENT):
                raise Exception("User account unauthorized!")

        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentSaveAssociatedMediaSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        artwork_fk_id = req_data.get('artwork_id')
                        
                        is_threed_file = False
                        if (req_data.get('save_art_type') == "3d"):
                            is_threed_file = True

                        req_files = request.FILES

                        ts_now = now()

                        uuid = generate_random_uuid()

                        if is_threed_file:
                            path_threed_files = os.path.join("/code/media/threed_files/", uuid) 
                            os.mkdir(path_threed_files) 
                        else:
                            path_associated_media = os.path.join("/code/media/associated_media/", uuid) 
                            os.mkdir(path_associated_media) 

                        for f in req_files.getlist('file'):
                            original_file_name = f
                            file_ext = str(f).rsplit('.', 1)[-1]

                            if is_threed_file:
                                code_media_src = "/code/media/threed_files/" + uuid + "/" + str(f)
                                media_src = "media/threed_files/" + uuid + "/" + str(f)
                            else:
                                code_media_src = "/code/media/associated_media/" + uuid + "/" + str(f)
                                media_src = "media/associated_media/" + uuid + "/" + str(f)

                            with open(code_media_src, "wb+") as outf:
                                for chunk in f.chunks():
                                    outf.write(chunk)

                            new_assoc_media = ArtworksAssociatedMedia(
                                artwork_fk_id = artwork_fk_id,
                                student_fk_id = decoded['user_id'],
                                uuid = uuid,
                                media_src = media_src,
                                original_media_name = file_ext,
                                is_threed_file = is_threed_file,
                                ts_added = ts_now,
                            )
                            new_assoc_media.save()

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save associated media."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentGetArtworkAssociatedMedia(RetrieveAPIView):
    """
    get: Get data of associated media based on the provided artwork.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentGetArtworkAssociatedMediaSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('studentGetArtworkAssociatedMedia', response_types)

    parameters = openapi.Parameter(
        'artwork_id',
        in_=openapi.IN_QUERY,
        description='The ID of the artwork',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[parameters]
    )
    def get(self, request):
        '''
        Get data of associated media based on the provided artwork.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentGetArtworkAssociatedMediaSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, decoded = at.authenticate(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                        if( decoded['role'] != STUDENT):
                            raise Exception("User account unauthorized!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)


                    artwork_fk_id = req_data.get('artwork_id')

                    is_threed_file = False
                    if (req_data.get('save_art_type') == "3d"):
                        is_threed_file = True

                    associated_media_list = []

                    associated_media_rows = ArtworksAssociatedMedia.objects.filter(
                        artwork_fk_id=artwork_fk_id,
                        student_fk_id=decoded['user_id'],
                        is_threed_file=is_threed_file,
                    )

                    for item in associated_media_rows:
                        current_media = {}
                        current_media['uuid'] = item.uuid
                        current_media['media_src'] = item.media_src
                        current_media['original_media_name'] = item.original_media_name
                        associated_media_list.append(current_media)

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_ARRAY] = associated_media_list
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of associated media for artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class KRSaveFiles(CreateAPIView):
    """
    post:
    Save the associated media of an artwork
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = KRSaveFilesSerializer
    parser_classes = (parsers.FormParser, parsers.MultiPartParser, parsers.FileUploadParser)
    response_types = [
        ['success'],
        ['unauthorized'],
        ['bad_request'],
        ['method_not_allowed'], # MISSING ON DESCRIPTION
        ['unsupported_media_type'],
        ['internal_server_error']
    ]

    response_dict = build_fields('KRSaveFiles', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        manual_parameters=[]
    )
    def post(self, request, *args, **kwargs):
        ''' Post:  Save the associated media of an artwork  '''

        log.debug("{} Received request".format(request_details(request)))
        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, decoded = at.authenticate(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")

            # if( decoded['role'] != STUDENT):
            #     raise Exception("User account unauthorized!")

        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = KRSaveFilesSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))

                        req_files = request.FILES

                        ts_now = now()

                        uuid = generate_random_uuid()

                        path_threed_files = os.path.join("/code/media/kr_files/", uuid) 
                        os.mkdir(path_threed_files) 

                        for f in req_files.getlist('file'):
                            original_file_name = f
                            file_ext = str(f).rsplit('.', 1)[-1]

                            code_media_src = "/code/media/kr_files/" + uuid + "/" + str(f)
                            media_src = "media/kr_files/" + uuid + "/" + str(f)

                            with open(code_media_src, "wb+") as outf:
                                for chunk in f.chunks():
                                    outf.write(chunk)

                            new_assoc_media = KnowledgeRepository(
                                uuid = uuid,
                                media_src = media_src,
                                original_media_name = file_ext,
                                ts_added = ts_now,
                            )
                            new_assoc_media.save()

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'artwork'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to save associated media."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class KRGetFiles(RetrieveAPIView):
    """
    get: Get data of associated media based on the provided artwork.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = KRGetFilesSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('KRGetFiles', response_types)

    parameters = openapi.Parameter(
        'artwork_id',
        in_=openapi.IN_QUERY,
        description='The ID of the artwork',
        type=openapi.TYPE_INTEGER,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[parameters]
    )
    def get(self, request):
        '''
        Get data of associated media based on the provided artwork.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = KRGetFilesSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, decoded = at.authenticate(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                        if( decoded['role'] != STUDENT):
                            raise Exception("User account unauthorized!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)


                    associated_media_list = []

                    associated_media_rows = KnowledgeRepository.objects.filter(
                        kr_type=1,
                    )

                    for item in associated_media_rows:
                        current_media = {}
                        current_media['uuid'] = item.uuid
                        current_media['media_src'] = item.media_src
                        current_media['original_media_name'] = item.original_media_name
                        associated_media_list.append(current_media)

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_ARRAY] = associated_media_list
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of associated media for artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class studentRecommendedArtworks(RetrieveAPIView):
    """
    get: Get data of all recommended artworks for the student based on the comma-separated keywords.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = studentRecommendedArtworksSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('studentRecommendedArtworks', response_types)

    keywords_param = openapi.Parameter(
        'keywords',
        in_=openapi.IN_QUERY,
        description='Comma-separated keywords that will be used for recommendation of artworks/exhibitions',
        type=openapi.TYPE_STRING,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[keywords_param]
    )
    def get(self, request):
        '''
        Get data of all recommended artworks for the student based on the comma-separated keywords.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = studentRecommendedArtworksSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, decoded = at.authenticate(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                        if( decoded['role'] != STUDENT):
                            raise Exception("User account unauthorized!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)

                    keywords = req_data.get('keywords')
                    incoming_keywords_list = keywords.split(",")
                    incoming_keywords_string = ' '.join(incoming_keywords_list)

                    # Personalization model for artworks
                    artwork_rows = Artwork.objects.filter(user_fk_id=decoded['user_id'])

                    for artwork_row in artwork_rows:
                        pm_artworks = artwork_row.personalization_model
                        pm_artworks_list = pm_artworks.split(",")
                        pm_artworks_string = ' '.join(pm_artworks_list)
                        similarity_score_artworks = fuzz.token_sort_ratio(incoming_keywords_string, pm_artworks_string)
                        print("artworkid: ", artwork_row.id, " | similarity_score_artworks: ", similarity_score_artworks)

                    # Personalization model for exhibitions
                    if decoded['role'] == INSTRUCTOR:
                        exhibition_rows = Exhibition.objects.filter(instructor_fk_id=decoded['user_id'])

                        for exhibition_row in exhibition_rows:
                            pm_exhibitions = exhibition_row.personalization_model
                            pm_exhibitions_list = pm_exhibitions.split(",")
                            pm_exhibitions_string = ' '.join(pm_exhibitions_list)
                            similarity_score_exhibitions = fuzz.token_sort_ratio(incoming_keywords_string, pm_exhibitions_string)
                            print("similarity_score_exhibitions: ", similarity_score_exhibitions)

                    recommended_artworks_list = []

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_ARRAY] = recommended_artworks_list
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get recommended artworks."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])