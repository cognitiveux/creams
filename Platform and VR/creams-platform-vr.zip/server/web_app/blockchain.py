from django.db import transaction
from datetime import datetime

from .models import Block
from .logging import logger as log

import pytz


class Blockchain:
    def __init__(self):
        self.chain = self.load_chain()
        if not self.chain:
            self.create_genesis_block()

    def create_genesis_block(self):
        try:
            if not Block.objects.exists():
                with transaction.atomic():
                    genesis_block = Block(
                        index=0,
                        timestamp=datetime.now(pytz.utc),
                        data="Genesis Block",
                        previous_hash="0"
                    )
                    genesis_block.hash = genesis_block.calculate_hash()
                    genesis_block.save()
                    self.chain = self.load_chain()
        except Exception as e:
            log.error("Error occurred while creating genesis block: {}".format(str(e)))
            raise

    def load_chain(self):
        return list(Block.objects.all().order_by('index'))

    def get_latest_block(self):
        if self.chain:
            return self.chain[-1]
        else:
            return self.create_genesis_block()

    def add_block(self, data):
        try:
            with transaction.atomic():
                latest_block = self.get_latest_block()
                new_block = Block(
                    index=latest_block.index + 1,
                    timestamp=datetime.now(pytz.utc),
                    data=data,
                    previous_hash=latest_block.hash
                )
                new_block.hash = new_block.calculate_hash()
                new_block.save()
                self.chain = self.load_chain()
        except Exception as e:
            log.error("Error occurred while adding block: {}".format(str(e)))
            raise

    def is_chain_valid(self):
        blocks = Block.objects.all().order_by('index')
        invalid_blocks = []

        for i in range(1, len(blocks)):
            current_block = blocks[i]
            previous_block = blocks[i - 1]

            if current_block.hash != current_block.calculate_hash():
                log.debug("Invalid hash for block: {}".format(current_block.index))
                invalid_blocks.append(current_block.index)

            if current_block.previous_hash != previous_block.hash:
                log.debug("Previous hash mismatch for block: {}".format(current_block.index))
                invalid_blocks.append(current_block.index)

        if invalid_blocks:
            return False

        return True

    def print_chain(self):
        for block in self.chain:
            log.debug("Block: {} Data: {} Hash: {} Previous Hash: {}".format(block.index, block.data, block.hash, block.previous_hash))
