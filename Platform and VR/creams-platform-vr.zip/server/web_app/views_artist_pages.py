from .views import *
from django.http import HttpResponseNotAllowed

def artistDashboardPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        
    caller      = get_object_or_404(Users,id = decoded['user_id'])
    exhibitions = getStudentExhibitions(caller)
    artworks    = getStudentArtworks(caller)
    template = loader.get_template('web_app/artist/dashboard.html')
    context = {
		'title': "Artist Dashboard",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibitions': exhibitions,
        'artworks': artworks,
	}   

    return HttpResponse(template.render(context, request))

def artistArtworksPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller      = get_object_or_404(Users,id = decoded['user_id'])
    artworks    = getStudentArtworks(caller)
    template = loader.get_template('web_app/artist/list_artworks.html')
    context = {
		'title': "My Artworks",
		'header_content': 'Index header content',
        'user' : caller,
        'first': artworks[0:21],
        'second': artworks[22:]
	}   

    return HttpResponse(template.render(context, request))


def artistSubmitArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        
    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/artist/new_artwork.html')

    context = {
		'title': "Submit an artwork",
		'header_content': 'Index header content',
        'user' : caller,
        'art_terms_rows': ArtTerms.objects.values(),
        'spatial_context_terms_rows': SpatialContextTerms.objects.values(),
        'help_title': "Create Artwork",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that width and height must be in meters.",
	}
    return HttpResponse(template.render(context, request))



def artistViewArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    requested_id = request.GET.get('id')
    student_id = decoded['user_id']
    caller = get_object_or_404(Users,id = decoded['user_id'])

    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        

    creator = caller.name + " " + caller.surname
    artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=student_id)

    artwork.depth = Decimal(artwork.depth).normalize()
    artwork.width = Decimal(artwork.width).normalize()
    artwork.height = Decimal(artwork.height).normalize()
    artwork.unit = Decimal(artwork.unit).normalize()
    template = loader.get_template('web_app/artist/view_artwork.html')
    context = {
		'title': "View Artwork",
        'base' : "user_base.html",
		'header_content': 'Index header content',
        'user' : caller,
        'artwork' : artwork,
        'creator': creator,
	}
 
    return HttpResponse(template.render(context, request))


def artistEditArtworkPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        
    requested_id = request.GET.get('id')
    caller = get_object_or_404(Users,id = decoded['user_id'])
    artwork = get_object_or_404(Artwork, id=requested_id,user_fk_id=decoded['user_id'])
    artwork.depth = Decimal(artwork.depth).normalize()
    artwork.width = Decimal(artwork.width).normalize()
    artwork.height = Decimal(artwork.height).normalize()
    artwork.unit = Decimal(artwork.unit).normalize()

    template = loader.get_template('web_app/artist/edit_artwork.html')
    context = {
		'title': "Edit Artwork",
		'header_content': 'Index header content',
        'artwork' : artwork,
        'user' : caller,
        'art_terms_rows': ArtTerms.objects.values(),
        'spatial_context_terms_rows': SpatialContextTerms.objects.values(),
        'help_title': "Edit Artwork",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that width and height must be in meters.",
	}
 
    return HttpResponse(template.render(context, request))
 
 
def artistAudioFilesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller      = get_object_or_404(Users,id = decoded['user_id'])
    template = loader.get_template('web_app/artist/list_audiofiles.html')
    context = {
		'title': "My AudioFiles",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "My Audio Files Page",
        'help_text': "You can listen and delete you audio files.",
	}   

    return HttpResponse(template.render(context, request))


def artistSubmitAudioFilePage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, art, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( art == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/artist/new_audiofile.html')
    context = {
		'title': "Submit an artwork",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "Upload Audiofile",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that the file you try to upload must be and an audio file.",
	}
    return HttpResponse(template.render(context, request))



def artistVideoFilesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller      = get_object_or_404(Users,id = decoded['user_id'])
    template = loader.get_template('web_app/artist/list_videos.html')
    context = {
		'title': "My Videos",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "My Video Files Page",
        'help_text': "You can view and delete you videos.",
	}   

    return HttpResponse(template.render(context, request))


def artistSubmitVideoFilePage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, stu, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( stu == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/artist/new_video.html')
    context = {
		'title': "Submit a video",
		'header_content': 'Index header content',
        'user' : caller,
        'help_title': "Upload Video File",
        'help_text': "You should fill all the required fields and click on the submit button. It is important to remember that the file you try to upload must be and a video file.",
	}
    return HttpResponse(template.render(context, request))



def artistExhibitionsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( artist == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')

    caller = get_object_or_404(Users,id = decoded['user_id'])   
    template = loader.get_template('web_app/artist/list_exhibitions.html')
    vr_exhibitions = getStudentVrExhibitions(caller)

    context = {
		'title': "My Exhibitions",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibitions': vr_exhibitions
	}   

    return HttpResponse(template.render(context, request))

def artistInitExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( artist == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])
    spaces = []
    for r in ExhibitionSpaceModel.SPACE_CHOICES:
        spaces.append(r[0])
    template = loader.get_template('web_app/artist/new_exhibition.html')
    context = {
		'title': "Initiate an exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'spaces': spaces,
        'help_title': "Create Exhibition",
        'help_text': "You should fill all the required fields and click on the submit button.",
	}
    return HttpResponse(template.render(context, request))


def artistViewExhibitionPage(request):
    template = loader.get_template('web_app/artist/view_exhibition.html')
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('login')
        return HttpResponseRedirect(url)
    
    if( artist == False):
        if decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        elif decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
        
    caller      = get_object_or_404(Users,id = decoded['user_id'])
    
    assigned_id = request.GET.get('assign')
    exhibition_assign  = get_object_or_404(AssignedExhibitionStudents,student_fk_id = caller.id , assignment_fk_id = assigned_id)

    exhibition  = get_object_or_404(Exhibition, id = assigned_id)
    exhibition.status_class = exhibitionStatusClassDecoder(exhibition.status)

    instr = get_object_or_404(Users,id = exhibition.instructor_fk_id)
    full_name = instr.name + " " + instr.surname

    context = {
		'title': "Exhibition",
		'header_content': 'Index header content',
        'user': caller,
        'exh_id': assigned_id,
        'instructor': full_name,
        'exhibition': exhibition,

	}   

    
    return HttpResponse(template.render(context, request)) 



def artistExhibitionViewerPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    caller = get_object_or_404(Users,id = decoded['user_id'])   
    assigned_id = request.GET.get('assign')

    if( artist == False):
        tkn_okay, inst, decoded = at.authenticateInstructor(request,settings)
        if( inst == False):
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        
        try:
            virtual = VR_Exhibition.objects.get(id = assigned_id)
            exh = Exhibition.objects.get(id=virtual.exhibition_fk_id,instructor_fk_id = caller.id)
            titleExh = exh.exhibition_title
        except Exception:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
    else:
        try:
            virtual = VR_Exhibition.objects.get(id = assigned_id, student_fk_id= caller.id)
            exh = Exhibition.objects.get(id=virtual.exhibition_fk_id)
            titleExh = exh.exhibition_title
        except Exception:
            return HttpResponseRedirect('/web_app/student/dashboard/')

    
    temp = str(virtual.vr_exhibition)
    filename = "media/" + temp[0:len(temp)]
    payload = open(filename, "r").read()
    try:
        name = "media/" + str(virtual.vr_script)
        ac = open(name, "r").read()
    except Exception:
        ac = ' '
    template = loader.get_template('web_app/bases/vr_base.html')
    context = {
        'title': titleExh,
        'exh_id': virtual.id,
        'custom_exhibition': payload,
        'x_script':ac,
        'social' : False
	}   

    return HttpResponse(template.render(context, request))



def artistEditExhibitionPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    tkn_okay, artist, decoded = at.authenticateArtist(request,settings)
    if( tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if( artist == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == INSTRUCTOR:
            return HttpResponseRedirect('/web_app/teacher/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    requested_id = request.GET.get('id')
    
    exhibition = get_object_or_404(Exhibition, id=requested_id,instructor_fk_id=decoded['user_id'])
    caller = get_object_or_404(Users,id = decoded['user_id'])
    spaces = []
    for r in ExhibitionSpaceModel.SPACE_CHOICES:
        spaces.append(r[0])

    template = loader.get_template('web_app/artist/edit_exhibition.html')
    context = {
		'title': "Edit Exhibition",
		'header_content': 'Index header content',
        'user' : caller,
        'exhibition' : exhibition,
        'spaces': spaces,
        'help_title': "Edit Exhibition",
        'help_text': "You should fill all the required fields and click on the submit button.",
	}
 
    return HttpResponse(template.render(context, request))