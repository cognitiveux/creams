import base64
import datetime
import hashlib
import json
from re import sub
from turtle import distance
from django.conf import settings
from django.utils.timezone import now
from django.db.models import F, ExpressionWrapper, DecimalField
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from .application_error import ApplicationError
from .authentication_tools import auth_tools as at
from .watermarker import watermarker as wm
from .preassigner import doer as assign

from math import radians, cos, sin, asin, sqrt
from .models import *
from .logging import logger as log
from web_app.models import (
    ResetPassword,
    Users,
)

import requests
import ssl
import smtplib
import uuid


EMAIL_BODY = """
Hi,\n\nTo verify your CREAMS {} please use the following code:{}\n\n
If you did not request this code, please let us know.\n\nThanks,\nCreams Team
"""

EMAIL_HTML="""
<html>
    <body>
        <p>Hi,<br><br>
            To verify your CREAMS  {}
            please use the following code:<br><br>
            <strong>{}</strong>
        </p>
        <p>If you did not request this code, please let us know.</p><br><br>
        <p>Thanks,<br>
        Creams Team</p>
    </body>
</html>
"""

def build_email_object(verification_type, verification_code, fromaddr, toaddr):
    """
    Args:
        verification_type (str):
            The verification type , which is included as a key in settings.VERIFICATION_TYPES
            and settings.MODEL_MAPPING
        verification_code (str):
            The verification code that will be displayed in the email
        fromaddr (str):
            The email of the sender
        toaddr (str):
            The email of the receiver
    Returns:
        MIMEMultipart object with the message.
        Text built lives in views_utils.EMAIL_BODY, views_utils.EMAIL_HTML
    """
    msg = MIMEMultipart("alternative")
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = settings.VERIFICATION_TYPES.get(verification_type).get('msg_subject')
    text = EMAIL_BODY.format(settings.VERIFICATION_TYPES.get(verification_type).get('literal'),verification_code)
    html = EMAIL_HTML.format(settings.VERIFICATION_TYPES.get(verification_type).get('literal'),verification_code)
    part1 = MIMEText(text, "plain")
    part2 = MIMEText(html, "html")
    msg.attach(part1)
    msg.attach(part2)
    return msg

def generate_random_uuid(length=32):
    """
    Generates a random UUID as a ``length``-character hexadecimal string

        Returns:
            (str): The UUID
    """
    return uuid.uuid4().hex[0:length]


def get_ip_address(request):
    '''Returns the client's IP address from the `request` META attribute

        Args:
            request (rest_framework.request.Request): The request object

        Returns:
            ip (str): Client's IP address
    '''
    ip = None

    if isinstance(request, dict):
        x_forwarded_for = request['META']['HTTP_X_FORWARDED_FOR']

        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request['META']['REMOTE_ADDR']
    else:
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')

        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0]
        else:
            ip = request.META.get('REMOTE_ADDR')

    return ip

def request_details(request):
    '''
    Returns details for the request as a string. This is a helper function for logging.

    Args:
        request (rest_framework.request.Request):
            The request object

    Returns:
        <ip> <user> if possible else <ip>
    '''
    username = None
    if isinstance(request, dict):
        user = request.get('user')
        if user:
            username =  user.get('username')
        else:
            username = request['data'].get('username')
    else:
        try:
            access_granted,decoded = at.authenticate(request,settings)
            username = decoded['sub']
        except Exception:
            username = None

    if not username:
        username = 'anonymous'

    return get_ip_address(request)+" - "+username+" - "


def serialize_request(request):
    '''
    Serializes a django.http.request object to be passed as a parameter in tasks

    Args:
        request (django.http.request):
            The request object that will be serialized
    Returns:
        dict:
            The serialized dictionary
    '''
    username = None

    try:
        username = request.user.email
    except Exception as e:
        try:
            username = request.user.get_username()
        except Exception as e:
            username = None

    # Only the required properties for logging are serialized
    result = {
        'user': {
            'username': username,
            'id': request.user.id,
        },
        'data': request.data,
        'META': {
            'HTTP_X_FORWARDED_FOR': request.META.get('HTTP_X_FORWARDED_FOR'),
            'REMOTE_ADDR': request.META.get('REMOTE_ADDR'),
            'HTTP_USER_AGENT': request.META.get('HTTP_USER_AGENT'),
            'HTTP_AUTHORIZATION': request.META.get('HTTP_AUTHORIZATION'),
        },
    }
    return result


def send_verification_email(email, verification_code, verification_type):
    """
    Sends an email containing the verification_code to the email
    Args:
        email (str): The email address.
        verification_code (str): The verification code.
        verification_type (str): The verification type.
    """
    log.info("Will send email to address: {}".format(email))
    fromaddr = settings.GLOBAL_SETTINGS.get('FROM_EMAIL')
    fromaddr_alias = settings.GLOBAL_SETTINGS.get('FROM_EMAIL_ALIAS')
    toaddr = email
    password = settings.GLOBAL_SETTINGS.get('EMAIL_PASSWORD')
    msg = build_email_object(verification_type, verification_code, fromaddr_alias, toaddr)

    try:
        context = ssl.create_default_context()

        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(fromaddr, password)
            server.sendmail(
                fromaddr, toaddr, msg.as_string()
            )
            log.info("Email successfully sent to address: {}".format(email))
    except Exception as e:
        log.error("Failed to send verification email to address: {}. Reason: {}".format(email, str(e)))
        raise

# This function sorts a QuerySet based on its distance from a coordinate set.
def sortGeo(demo_list,lat,lon):
    artworks_list = {}
    cnt = 0
    for item in demo_list:
        artworks_list[cnt] = [item['lat'],item['lon'],item['id']]
        cnt = cnt + 1
        
    tmp_list = []
    for k, v  in artworks_list.items():      
        temp_ins = []
        temp_ins.append(v)
        temp_ins.append(k)
        tmp_list.append(temp_ins) 
        
    artworks_list = sorted(tmp_list, key=lambda x: geoDistance(float(lat),float(lon),x[0][0],x[0][1]))
    sorted_list = []
    for st in artworks_list:
        sorted_list.append(demo_list[st[1]])
        
    return sorted_list

# This function calculates the distance between two sets of (x,y) coordinates in the earth
def geoDistance(lat1,lon1,lat2,lon2):
    # The math module contains a function named
    # radians which converts from degrees to radians.
    lon1 = radians(lon1)
    lon2 = radians(lon2)
    lat1 = radians(lat1)
    lat2 = radians(lat2)
      
    # Haversine formula
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
 
    c = 2 * asin(sqrt(a))
    
    # Radius of earth in kilometers. Use 3956 for miles
    r = 6371
    # calculate the result
    return(c * r)
   
# This function transforms an image to a base64 encoded string
def getBase64(src):
    with open("media/" + src, "rb") as image_file:
        return base64.b64encode(image_file.read())
    
def changeExhibitionState(exh_id,new_state):
    Exhibition.objects.filter(id=exh_id).update(
    status= new_state
    )
    
def chechRole(user_id,role):
    try: 
        return Users.objects.filter(id=user_id).values()[0]["role"] == role
    except:
        return False

def watermark(path_to_image:str):
    return wm.watermark_with_transparency(filename=path_to_image)

def assignDefaultAssignment(student_fk_id):
    assign.assignDefault(student_fk_id)


def exhibitionStatusClassDecoder(status):
    class__ = ''
    if status == "Temporary Stored":
        class__ = "redText"
    if status == "Published":
        class__ =  "greenText"
    if status == "Accepting Artworks":
        class__ =  "orangeText"
    if status == "Ready to be Assessed":
        class__ =  "yellowText"
    if status == "Assessed":
        class__ =  "blueText"
    if status == "Assessment Started":
        class__ =  "cyanText"

    return class__


def decodeHeaderColouring(character):
    if character >= 'A' and character < 'F':
        return 'warning'
    if character >= 'G' and character < 'L':
        return 'info'
    if character >= 'M' and character < 'R':
        return 'success'
    if character >= 'S' and character < 'Z':
        return 'primary'
    

def getInstructorExhibitions(caller,filter=None):   
    unpublished_data = []
    published_data = []
    try:
        __coad = AssignedExhibitionInstructor.objects.filter(instructor_fk_id=caller.id).values()
        for item in __coad:
            if filter == None:
                exh_item = Exhibition.objects.get(id = item['assignment_fk_id'])
            else:
                exh_item = Exhibition.objects.get(id = item['assignment_fk_id'], status = filter)
            exh_item.status_class = exhibitionStatusClassDecoder(exh_item.status)
            exh_item.participants = findParticipants(exh_item.id)
            exh_item.main         = False
            if exh_item.status == ExhibitionStatus.Published:
                published_data.append(exh_item)
            else:
                unpublished_data.append(exh_item)
    except:
        __coad = []
    try:
        if filter == None:
            __main = Exhibition.objects.filter(instructor_fk_id=caller.id).all()
        else:
            __main = Exhibition.objects.filter(instructor_fk_id=caller.id, status = filter).all()
        for item in __main:
            item.status_class = exhibitionStatusClassDecoder(item.status)
            item.participants = findParticipants(item.id)
            item.main         = True
            if item.status == ExhibitionStatus.Published:
                published_data.append(item)
            else:
                unpublished_data.append(item)
    except:
        __main = []


    return published_data, unpublished_data


def findParticipants(assignment_id):
    return int(AssignedExhibitionStudents.objects.filter(assignment_fk_id=assignment_id).values("id").count())


def getStudentExhibitions(caller,filter=None):
    student_exhibitions = []
    try:
        __exhs = AssignedExhibitionStudents.objects.filter(student_fk_id=caller.id).values()
        for item in __exhs:
            if filter == None:
                exh_item = Exhibition.objects.get(id = item['assignment_fk_id'])
            else:
                exh_item = Exhibition.objects.get(id = item['assignment_fk_id'], status = filter)
            exh_item.status_class = exhibitionStatusClassDecoder(exh_item.status)
            student_exhibitions.append(exh_item)
    except:
        __exhs = []
    

    return student_exhibitions


def getStudentArtworks(caller):
    student_artworks = []
    try:
        __arts = Artwork.objects.filter(user_fk_id=caller.id)
        for item in __arts:
            student_artworks.append(item)
    except:
        __arts = []
    

    return student_artworks


def getStudentVrExhibitions(caller):
    student_vr_exhibitions = []
    try:
        __vrs = VR_Exhibition.objects.filter(student_fk_id=caller.id)
        for item in __vrs:  
            assignment = Exhibition.objects.get(id=item.exhibition_fk_id)
            item.title = assignment.exhibition_title
            teacher = Users.objects.get(id=assignment.instructor_fk_id)
            item.teacher = teacher.name + " " + teacher.surname
            item.image = assignment.image
            item.start_date = assignment.start_date
            item.end_date = assignment.end_date
            student_vr_exhibitions.append(item)
    except:
        __vrs = []
    

    return student_vr_exhibitions



def numerize(string:str):
    sum = 0
    for letter in string:
        sum += ord(letter)

    return sum


def getChatUUID(curr_sender_fk_id, curr_rcver_fk_id):
    curr_chat_uuid = ""

    # Check if chat already exists between sender and receiver
    comm_srv_row_obj = CommunicationService.objects.filter(
        sender_fk_id=curr_sender_fk_id,
        rcver_fk_id=curr_rcver_fk_id
    ) | CommunicationService.objects.filter(
        sender_fk_id=curr_rcver_fk_id,
        rcver_fk_id=curr_sender_fk_id
    )

    comm_srv_row_obj = comm_srv_row_obj.first()

    if comm_srv_row_obj:
        curr_chat_uuid = comm_srv_row_obj.uuid
    else:
        with transaction.atomic():
            try:
                comm_srv_uuid = generate_random_uuid()
                ts_now = now()

                new_comm_srv = CommunicationService(
                    uuid=comm_srv_uuid,
                    sender_fk_id=curr_sender_fk_id,
                    rcver_fk_id=curr_rcver_fk_id,
                    ts_added=ts_now,
                )
                new_comm_srv.save()
                curr_chat_uuid = comm_srv_uuid
            except Exception as e:
                raise

    return curr_chat_uuid