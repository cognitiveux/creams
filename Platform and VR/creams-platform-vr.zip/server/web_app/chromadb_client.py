import chromadb
import json
import os

_client = None

def get_client():
    global _client
    if _client is None:
        # Initialize the chromadb client only once
        _client = chromadb.Client()

        # Path to a temporary file used as a flag
        flag_file = '/code/webapp_chromadb_initialized.flag'

        # Check if the flag file exists
        if not os.path.exists(flag_file):
            with open("/code/web_app/study_data.json") as f:
                data = json.load(f)

                for item in data:
                    name = item.get('name')
                    name = name.replace(' ', '_')
                    print("Adding name to chromadb collection: ", name)
                    descr = item.get('description')
                    descr_split = descr.split(".")
                    ids = [str(i) for i in range(len(descr_split))]
                    client_obj = _client.get_or_create_collection(name=name)
                    client_obj.add(documents=descr_split, ids=ids)

            print("Init chromadb success")

            # Create the flag file to indicate the initialization is done
            with open(flag_file, 'w') as f:
                f.write('Initialization complete.')

    return _client
