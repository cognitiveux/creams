from datetime import timedelta
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser
from django.db import models
from django.utils.timezone import now
from django.utils import timezone

import uuid
import os

from PIL import Image
from io import BytesIO
from django.core.files.base import ContentFile

import hashlib


class ArtTerms(models.Model):
	name = models.CharField(max_length=200)
	ts_added = models.DateTimeField(default=now)
	ts_last_updated = models.DateTimeField(default=now)


class SpatialContextTerms(models.Model):
	name = models.CharField(max_length=200)
	ts_added = models.DateTimeField(default=now)
	ts_last_updated = models.DateTimeField(default=now)


class ExtendedOrganizations(models.Model):
    name = models.CharField(max_length=500)
    ts_added = models.DateTimeField(default=now)
    ts_last_updated = models.DateTimeField(default=now)

    def __str__(self):
        return self.name


class OrganizationModel(models.Model):
    AUTH = "AUTH"
    CUT = "CUT"
    CUX = "CUX"
    NTNU = "NTNU"
    SHENKAR = "SHENKAR"
    UPAT = "UPAT"

    ORGANIZATION_CHOICES = (
        (AUTH, "AUTH"),
        (CUT, "CUT"),
        (CUX, "CUX"),
        (NTNU, "NTNU"),
        (SHENKAR, "SHENKAR"),
        (UPAT, "UPAT"),
    )


class RoleModel(models.Model):
    INSTRUCTOR = "INSTRUCTOR"
    STUDENT = "STUDENT"
    ARTIST = "ARTIST"

    ROLE_CHOICES = (
        (INSTRUCTOR, "INSTRUCTOR"),
        (STUDENT, "STUDENT"),
        (ARTIST, "ARTIST"),
    )
 
 
class ClassAndLevelModel(models.Model):
    A1 = "Group A1"
    A2 = "Group A2"
    B1 = "Group B1"
    B2 = "Group B2"
    C1 = "Group C1"
    C2 = "Group C2"
    D1 = "Group D1"
    D2 = "Group D2"
    PROFESSOR = "PROFESSOR"
    ASSOCIATE_PROFESSOR = "ASSOCIATE PROFESSOR"
    ASSISTANT_PROFESSOR = "ASSISTANT PROFESSOR"
    LECTURER = "LECTURER"
    ARTIST = "ARTIST"

    LEVEL_CHOICES = (
        (A1, "Group A1"),
        (A2, "Group A2"),
        (B1, "Group B1"),
        (B2, "Group B2"),
        (C1, "Group C1"),
        (C2, "Group C2"),
        (D1, "Group D1"),
        (D2, "Group D2"),
        (PROFESSOR, "PROFESSOR"),
        (ASSOCIATE_PROFESSOR, "ASSOCIATE PROFESSOR"),
        (ASSISTANT_PROFESSOR, "ASSISTANT PROFESSOR"),
        (LECTURER, "LECTURER"),
        (ARTIST, "ARTIST"),
    )

    STUDENT_CHOICES = (
        (A1, "Group A1"),
        (A2, "Group A2"),
        (B1, "Group B1"),
        (B2, "Group B2"),
        (C1, "Group C1"),
        (C2, "Group C2"),
        (D1, "Group D1"),
        (D2, "Group D2"),
    )

    TEACHER_CHOICES = (
        (PROFESSOR, "PROFESSOR"),
        (ASSOCIATE_PROFESSOR, "ASSOCIATE PROFESSOR"),
        (ASSISTANT_PROFESSOR, "ASSISTANT PROFESSOR"),
        (LECTURER, "LECTURER"),
    )
        
    ARTIST_CHOICES = (
        (ARTIST, "ARTIST"),
    )


class ExhibitionSpaceModel(models.Model):
    #DefaultSpace = "Default Space"
    ModularSpace = "Modular Space"
    ShenkarGallery = "Shenkar Gallery"
    #SeparateSpaces = "Separate Spaces"
    #SharedRooms = "Shared Rooms"
    #SharedFloor = "Shared Floor"
 
    SPACE_CHOICES = (
        #(DefaultSpace, "Default Space"),
        (ModularSpace, "Modular Space"),
        (ShenkarGallery, "Shenkar Gallery"),
        #(SeparateSpaces, "Separate Spaces"),
        #(SharedRooms , "Shared Rooms"),
        #(SharedFloor , "Shared Floor"),
    )
 
 
class ExhibitionStatus(models.Model):
    TemporaryStored = "Temporary Stored"
    AcceptingArtworks = "Accepting Artworks"
    ReadyToBeAssessed = "Ready to be Assessed"
    AssessmentStarted = "Assessment Started"
    Assessed = "Assessed"
    Published = "Published"
 
    STATUS_CHOICES = (
        (TemporaryStored , "Temporary Stored"),
        (AcceptingArtworks , "Accepting Artworks"),
        (ReadyToBeAssessed , "Ready to be Assessed"),
        (AssessmentStarted , "Assessment Started"),
        (Assessed , "Assessed"),
        (Published, "Published"),
    )
    
  
class Users(AbstractBaseUser):
    email = models.EmailField(max_length=50, unique=True)
    name = models.CharField(max_length=50)
    organization = models.CharField(max_length=15, choices=OrganizationModel.ORGANIZATION_CHOICES)
    password = models.CharField(max_length=500)
    role = models.CharField(max_length=15, choices=RoleModel.ROLE_CHOICES)
    surname = models.CharField(max_length=50)
    c_register_task_id = models.CharField(max_length=100, default="")
    c_reset_task_id = models.CharField(max_length=100, default="")
    ts_entry_added = models.DateTimeField(default=now)
    ts_last_updated = models.DateTimeField(default=now)
    class_level =	models.CharField(max_length=30,choices=ClassAndLevelModel.LEVEL_CHOICES)
    user_model = models.CharField(max_length=1000, null=True, blank=True, default=None)
    user_model_two = models.CharField(max_length=1000, null=True, blank=True, default=None)
    user_model_implicit = models.CharField(max_length=1000, null=True, blank=True, default=None)
    user_model_implicit_two = models.CharField(max_length=1000, null=True, blank=True, default=None)

    USERNAME_FIELD = 'email'


class ActiveUsers(models.Model):
    """
    Contains information about users who have verified their accounts
    """
    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
    )
    verification_code = models.CharField(max_length=50)
    ts_activation = models.DateTimeField(null=True, default=None)
    frequent_request_count = models.IntegerField(default=0) # number of requests made within an hour
    ts_added = models.DateTimeField(default=now)


class ResetPassword(models.Model):
    """
    Contains reset password records
    """
    def calculate_expiration():
        """
        A function to fill the expiration time of the reset code
        Returns (datetime):
            The expiration time which is found in settings
        """
        return now()+timedelta(seconds=settings.RESET_PASSWORD_INTERVAL)

    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE
    )
    frequent_request_count = models.IntegerField(default=0) # number of requests made within an hour
    reset_code = models.CharField(max_length=50)
    ts_expiration_reset = models.DateTimeField(null=True, default=calculate_expiration) # when this code will expire
    ts_reset = models.DateTimeField(null=True) # when the user actualy reset their password
    ts_requested = models.DateTimeField(default=now) # when this reset code was requested


class Exhibition(models.Model):
    exhibition_title = models.CharField(max_length=200)
    start_date = models.DateField(null=False)
    end_date = models.DateField(null=False)
    instructor_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
          to_field='id',
        default=1,
    )
    space_assign = models.CharField(max_length=15, choices=ExhibitionSpaceModel.SPACE_CHOICES)
    message = models.CharField(max_length=2000, default=' ')
    image = models.ImageField(upload_to='images')
    status = models.CharField(max_length=30,choices=ExhibitionStatus.STATUS_CHOICES)
    personalization_model = models.CharField(max_length=1000, null=True, blank=True, default="")
    personalization_model_two = models.CharField(max_length=1000, null=True, blank=True, default="")
    exhibition_type = models.CharField(max_length=10, null=True, blank=True, default="")
    ar_exhibition_type = models.CharField(max_length=50, null=True, blank=True, default="")
    ts_last_updated = models.DateTimeField(default=now)

    def __str__(self):
        return self.exhibition_title 

    def save(self, *args, **kwargs):
        # Check if an image is being uploaded
        if self.image:
            # Open the uploaded image
            img = Image.open(self.image)
            
            # Resize the image
            max_size = (800, 800)  # Maximum size for the longest dimension
            img.thumbnail(max_size, Image.LANCZOS)
            
            # Save the resized image to a BytesIO object with compression
            img_io = BytesIO()
            img_format = 'JPEG' if img.format in ['JPEG', 'JPG'] else 'PNG'

            if img_format == 'JPEG':
                # Compress JPEG image (lower quality means higher compression)
                img.save(img_io, format='JPEG', quality=70, optimize=True)
            else:
                # For PNG, save normally (Pillow doesn't support quality setting for PNG)
                img.save(img_io, format='PNG', optimize=True)

            img_io.seek(0)
            
            # Generate a random string using uuid4
            random_string = uuid.uuid4().hex

            # Extract the file extension
            file_extension = os.path.splitext(self.image.name)[1]

            # Create the new filename with the random string and original extension
            new_filename = f"{random_string}{file_extension}"

            # Replace the image field with the resized and compressed image and new filename
            self.image = ContentFile(img_io.read(), name=new_filename)
        
        # Call the parent class's save method
        super().save(*args, **kwargs)


class AssignedExhibitionStudents(models.Model):
    class Meta:
        unique_together = (('student_fk', 'assignment_fk'),)

    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id')
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id')

    
class AssignedExhibitionInstructor(models.Model):
    class Meta:
        unique_together = (('instructor_fk', 'assignment_fk'),)

    instructor_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id')
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id')


class GeneralAssessment(models.Model):
    instructor_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id',related_name='instructor')
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id',related_name='student')
    assessement = models.CharField(max_length=2000)
    
    
class Artwork(models.Model):
    src = models.FileField(upload_to='images')
    name = models.CharField(max_length=200)
    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        default=1,
          to_field='id'
    )
    year =  models.IntegerField(null=True, blank=True, default=None)
    height = models.DecimalField(max_digits=20, decimal_places=6, null=True, blank=True, default=None)
    width = models.DecimalField(max_digits=20,  decimal_places=6, null=True, blank=True, default=None)
    depth = models.DecimalField(max_digits=20,  decimal_places=6, null=True, blank=True, default=None)
    unit = models.DecimalField(max_digits=20,   decimal_places=6, null=True, blank=True, default=None)
    technique = models.CharField(max_length=200, null=True, blank=True, default=None)
    genre = models.CharField(max_length=200, null=True, blank=True, default=None)
    art_type = models.CharField(max_length=200, null=True, blank=True, default=None)
    personalization_model = models.CharField(max_length=1000, null=True, blank=True, default=None)
    personalization_model_two = models.CharField(max_length=1000, null=True, blank=True, default=None)
    copyright_text = models.CharField(max_length=200, null=True, blank=True, default=None)
    unique_hash = models.CharField(max_length=64, unique=True, null=True, blank=True, default=None)
 
    def __str__(self):
        return self.src
    
    def save(self, *args, **kwargs):
        # Check if an image is being uploaded
        if self.src:
            # Open the uploaded image
            img = Image.open(self.src)
            
            # Resize the image
            max_size = (800, 800)  # Maximum size for the longest dimension
            img.thumbnail(max_size, Image.LANCZOS)
            
            # Save the resized image to a BytesIO object with compression
            img_io = BytesIO()
            img_format = 'JPEG' if img.format in ['JPEG', 'JPG'] else 'PNG'

            if img_format == 'JPEG':
                # Compress JPEG image (lower quality means higher compression)
                img.save(img_io, format='JPEG', quality=70, optimize=True)
            else:
                # For PNG, save normally (Pillow doesn't support quality setting for PNG)
                img.save(img_io, format='PNG', optimize=True)

            img_io.seek(0)
            
            # Replace the image field with the resized and compressed image
            self.src = ContentFile(img_io.read(), name=self.src.name)

            # Generate a unique hash for the NFT (simulated uniqueness)
            # hasher = hashlib.sha256()
            # hasher.update(img_io.read())
            # self.unique_hash = hasher.hexdigest()

        # Call the parent class's save method
        super().save(*args, **kwargs)
    
   
class OutdoorExhibition(models.Model):
    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
          default=1,
          to_field='id'
    )
    exhibition_fk = models.ForeignKey(
        Exhibition,
        on_delete=models.CASCADE,
        to_field='id',
          default=42,
    )
    
    def __str__(self):
        return self.title


class OutdoorArtwork(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id')
    exhibition_fk =  models.ForeignKey(OutdoorExhibition, on_delete=models.CASCADE, to_field='id')
    lat = models.DecimalField(max_digits=20, decimal_places=15)
    lon = models.DecimalField(max_digits=20, decimal_places=15) 
    description = models.CharField(max_length=500, null=True)
    ts_last_updated = models.DateTimeField(default=now)

    
    def __str__(self):
        return self.lat + ' ' + self.lon
     
     
class VR_Templates(models.Model):
    basis = models.FileField(upload_to='templates')
    name = models.CharField(max_length=200)
    rooms = models.IntegerField()
    thumbnail = models.ImageField(upload_to='templates/thumbnails',null=True)
    
    def __str__(self):
        return self.basis
    

class VR_Exhibition(models.Model):
    student_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE, 
        to_field='id'
    )
    exhibition_fk = models.ForeignKey(
        Exhibition,  		
        on_delete=models.CASCADE, 
        to_field='id'
    )
    vr_exhibition = models.FileField(upload_to='vr_exhibitions')
    vr_script = models.FileField(upload_to='vr_exhibitions/scripts',null=True)


class AR_Exhibition(models.Model):
    class Meta:
        unique_together = (('student_fk', 'exhibition_fk'),)

    student_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE, 
        to_field='id'
    )
    exhibition_fk = models.ForeignKey(
        Exhibition,  		
        on_delete=models.CASCADE, 
        to_field='id'
    )


class MR_Exhibition(models.Model):
    class Meta:
        unique_together = (('student_fk', 'exhibition_fk'),)

    student_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE, 
        to_field='id'
    )
    exhibition_fk = models.ForeignKey(
        Exhibition,  		
        on_delete=models.CASCADE, 
        to_field='id'
    )
    
    
class AudioFiles(models.Model):
    src = models.FileField(upload_to='audiofiles')
    name = models.CharField(max_length=200)
    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        default=1,
          to_field='id'
    )
    description = models.CharField(max_length=2000, default="")
    ts_added = models.DateTimeField(default=now)
    
    
class VideoFiles(models.Model):
    src = models.FileField(upload_to='videos')
    name = models.CharField(max_length=200)
    user_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        default=1,
          to_field='id'
    )
    description = models.CharField(max_length=2000, default="")
    ts_added = models.DateTimeField(default=now)
    

class IndoorArtworks(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id')
    vr_exhibition_fk =  models.ForeignKey(VR_Exhibition, on_delete=models.CASCADE, to_field='id')
    ts_last_updated = models.DateTimeField(default=now)


class MRArtworks(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id')
    mr_exhibition_fk =  models.ForeignKey(MR_Exhibition, on_delete=models.CASCADE, to_field='id')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id')
    ts_last_updated = models.DateTimeField(default=now)


class ARArtworks(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id')
    ar_exhibition_fk =  models.ForeignKey(AR_Exhibition, on_delete=models.CASCADE, to_field='id')
    lat = models.DecimalField(max_digits=20, decimal_places=15, null=True, blank=True, default=None)
    lon = models.DecimalField(max_digits=20, decimal_places=15, null=True, blank=True, default=None)
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id')
    ts_last_updated = models.DateTimeField(default=now)


class CommunicationService(models.Model):
    uuid = models.CharField(max_length=100, unique=True, null=False)
    sender_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        related_name='comm_srvc_sender',
    )
    rcver_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        related_name='comm_srvc_rcver',
    )
    ts_added = models.DateTimeField(default=now)


class Chat(models.Model):
    comm_srvc_fk = models.ForeignKey(
        CommunicationService,
        on_delete=models.CASCADE,
        to_field='uuid'
    )
    sender_fk = models.ForeignKey(
        Users,
        on_delete=models.CASCADE,
        related_name='chat_sender',
    )
    msg = models.CharField(max_length=2000, default="")
    ts_added = models.DateTimeField(default=now)


class CuratorialStatus(models.Model):
    instructor_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id', related_name='cur_instr')
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id', related_name='cur_assign')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id', related_name='cur_student')
    is_step_a_select_artworks_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_b_arrange_groups_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_c_describe_arrangements_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_d_read_feedback_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_e_arrange_narratives_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_f_expand_narratives_complete = models.BooleanField(default=False, null=True, blank=True)
    is_step_g_vr_space_complete = models.BooleanField(default=False, null=True, blank=True)
    ts_last_updated = models.DateTimeField(default=now)


class CuratorialGroupArtworks(models.Model):
    name = models.CharField(max_length=100, default="")
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id', related_name='group_artwork_assign')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id', related_name='group_artwork_student')
    student_description = models.CharField(max_length=2000, default="")
    instructor_feedback = models.CharField(max_length=2000, default="")
    is_edited = models.BooleanField(default=False, null=True, blank=True)
    exhibition_title = models.CharField(max_length=1000, default="", null=True, blank=True)
    audience = models.CharField(max_length=15, choices=RoleModel.ROLE_CHOICES, default=RoleModel.INSTRUCTOR, null=True, blank=True)
    expanded_description = models.CharField(max_length=5000, default="", null=True, blank=True)
    instructor_final_assessment = models.CharField(max_length=2000, default="")
    final_assessment_src = models.CharField(max_length=2000, default="")
    ts_last_updated = models.DateTimeField(default=now)


class CuratorialSelectedArtworks(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id', related_name='selected_artwork')
    assignment_fk = models.ForeignKey(Exhibition, on_delete=models.CASCADE, to_field='id', related_name='selected_artwork_assign')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id', related_name='selected_artwork_student')
    group_fk = models.ForeignKey(CuratorialGroupArtworks, on_delete=models.CASCADE, to_field='id', related_name='selected_artwork_group', blank=True, null=True)
    ts_last_updated = models.DateTimeField(default=now)


class ArtworksAssociatedMedia(models.Model):
    artwork_fk =  models.ForeignKey(Artwork, on_delete=models.CASCADE, to_field='id', related_name='assoc_media_artwork')
    student_fk = models.ForeignKey(Users, on_delete=models.CASCADE, to_field='id', related_name='assoc_media_student')
    uuid = models.CharField(max_length=2000, default="")
    media_src = models.CharField(max_length=2000, default="")
    original_media_name = models.CharField(max_length=2000, default="")
    is_threed_file = models.BooleanField(default=False)
    ts_added = models.DateTimeField(default=now)


class KnowledgeRepository(models.Model):
    uuid = models.CharField(max_length=2000, default="")
    media_src = models.CharField(max_length=2000, default="")
    original_media_name = models.CharField(max_length=2000, default="")
    kr_type = models.IntegerField(default=1)
    ts_added = models.DateTimeField(default=now)


class Block(models.Model):
    index = models.IntegerField()
    timestamp = models.DateTimeField()
    data = models.TextField()
    previous_hash = models.CharField(max_length=64)
    hash = models.CharField(max_length=64, blank=True)

    def calculate_hash(self):
        hash_string = (
            str(self.index) +
            str(self.timestamp) +
            str(self.data) +
            str(self.previous_hash)
        )
        return hashlib.sha256(hash_string.encode()).hexdigest()

    def save(self, *args, **kwargs):
        if not self.hash:
            self.hash = self.calculate_hash()
        super().save(*args, **kwargs)
