from .views import *


class ChatMgmtCreate(CreateAPIView):
    """
    post:
    Creates a new chat instance
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ChatMgmtCreateSerializer
    permission_classes = (permissions.IsAuthenticated,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['resource_not_allowed', 'user'],
        ['resource_not_found', 'user'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ChatMgmtCreate', response_types)

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ]
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))
        decoded = None

        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')

            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, decoded = at.authenticate(request,settings)

            if(tkn_okay == False):
                raise Exception("Access token invalid!")            
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)

        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ChatMgmtCreateSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        curr_sender_fk_id = decoded.get('user_id')
                        curr_rcver_fk_id = req_data.get('rcver_fk')

                        # Check if chat already exists between sender and receiver
                        row_obj = CommunicationService.objects.filter(
                            sender_fk_id=curr_sender_fk_id,
                            rcver_fk_id=curr_rcver_fk_id
                        ) | CommunicationService.objects.filter(
                            sender_fk_id=curr_rcver_fk_id,
                            rcver_fk_id=curr_sender_fk_id
                        )

                        row_obj = row_obj.first()

                        if row_obj:
                            log.debug("{} Chat already exists. uuid: {} sender: {} receiver: {}.".format(
                                    request_details(request),
                                    row_obj.uuid,
                                    curr_sender_fk_id,
                                    curr_rcver_fk_id
                                )
                            )
                        else:
                            log.debug("{} Chat not exists. Will be created.".format(request_details(request)))
                            comm_srv_uuid = generate_random_uuid()
                            ts_now = now()

                            new_comm_srv = CommunicationService(
                                uuid=comm_srv_uuid,
                                sender_fk_id=curr_sender_fk_id,
                                rcver_fk_id=curr_rcver_fk_id,
                                ts_added=ts_now,
                            )
                            new_comm_srv.save()
                            log.debug("{} Chat created. uuid: {} sender: {} receiver: {}.".format(
                                    request_details(request),
                                    comm_srv_uuid,
                                    curr_sender_fk_id,
                                    curr_rcver_fk_id
                                )
                            )

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'user'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to create chat."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class ChatMgmtSendMsg(CreateAPIView):
    """
    post:
    Stores the received message for the chat instance
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ChatMgmtSendMsgSerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['resource_not_allowed', 'user'],
        ['resource_not_found', 'user'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ChatMgmtSendMsg', response_types)

    @swagger_auto_schema(
        responses=response_dict,
    )
    def post(self, request, *args, **kwargs):
        log.debug("{} Received request".format(request_details(request)))
        decoded = None

        try:
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')

            if not access_tkn:
                raise Exception("No access token provided!")

            tkn_okay, decoded = at.authenticate(request,settings)

            if(tkn_okay == False):
                raise Exception("Access token invalid!")
        except Exception as e:
                log.error("{} Internal error: {}".format(request_details(request), str(e)))
                status_code, _ = get_code_and_response(['unauthorized'])
                content = {
                    MESSAGE: "Access token is invalid."
                }
                return Response(content, status=status_code)

        try:
            response = {}
            data = {}
            req_data = request.data
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ChatMgmtSendMsgSerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                with transaction.atomic():
                    try:
                        log.debug("{} VALID DATA".format(request_details(request)))
                        comm_srvc_fk_id = req_data.get('comm_srvc_fk')
                        sender_fk_id = req_data.get('sender_fk')
                        msg = req_data.get('msg')

                        try:
                            with transaction.atomic():
                                ts_now = now()
                                new_chat = Chat(
                                    comm_srvc_fk_id=comm_srvc_fk_id,
                                    sender_fk_id=sender_fk_id,
                                    msg=msg,
                                    ts_added=ts_now,
                                )
                                new_chat.save()
                        except Exception as e:
                            log.info("{} Failed to save msg. Reason: {}".format(request_details(request), str(e)))
                            raise

                        status_code, message = get_code_and_response(['success'])
                        content = {}
                        content[MESSAGE] = message
                        content[RESOURCE_NAME] = 'user'
                        response = {}
                        response[CONTENT] = content
                        response[STATUS_CODE] = status_code
                        log.debug("{} SUCCESS".format(request_details(request)))
                        data = response
                    except ApplicationError as e:
                        log.info("{} ERROR: {}".format(request_details(request), str(e)))
                        response = {}
                        response[CONTENT] = e.get_response_body()
                        response[STATUS_CODE] = e.status_code
                        data = response

        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Unable to send message."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])


class ChatMgmtHistory(RetrieveAPIView):
    """
    get: Get data of chat history.
    """
    authentication_classes = [JWTAuthentication]
    serializer_class = ChatMgmtHistorySerializer
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error']
    ]
    response_dict = build_fields('ChatMgmtHistory', response_types)

    parameters = openapi.Parameter(
        'comm_srvc_fk',
        in_=openapi.IN_QUERY,
        description='The ID of the communication service',
        type=openapi.TYPE_STRING,
        required=True,
    )

    @swagger_auto_schema(
        responses=response_dict,
        security=[{'Bearer': []}, ],
        manual_parameters=[parameters]
    )
    def get(self, request):
        '''
        Get data of chat history based on the provided communication service ID.
        '''
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            serialized_item = ChatMgmtHistorySerializer(data=req_data)

            if not serialized_item.is_valid():
                log.debug("{} VALIDATION ERROR: {}".format(
                        request_details(request),
                        serialized_item.formatted_error_response()
                    )
                )
                response = {}
                response[CONTENT] = serialized_item.formatted_error_response(include_already_exists=True)
                response[STATUS_CODE] = status.HTTP_400_BAD_REQUEST
                data = response
            else:
                try:
                    log.debug("{} VALID DATA".format(request_details(request)))
                    try:
                        access_tkn = request.COOKIES.get('access_tkn')
                        refresh_tkn = request.COOKIES.get('refresh_tkn')
                        if not access_tkn:
                            raise Exception("No access token provided!")

                        tkn_okay, decoded = at.authenticate(request,settings)
                        if( tkn_okay == False):
                            raise Exception("Access token invalid!")

                    except Exception as e:
                            log.error("{} Internal error: {}".format(request_details(request), str(e)))
                            status_code, _ = get_code_and_response(['unauthorized'])
                            content = {
                                MESSAGE: "Access token is invalid."
                            }
                            return Response(content, status=status_code)


                    comm_srvc_fk_id = req_data.get('comm_srvc_fk')

                    # Check if chat already exists between sender and receiver
                    row_obj = CommunicationService.objects.filter(
                        uuid=comm_srvc_fk_id,
                        sender_fk_id=decoded['user_id']
                    ) | CommunicationService.objects.filter(
                        uuid=comm_srvc_fk_id,
                        rcver_fk_id=decoded['user_id']
                    )

                    if not row_obj:
                        log.debug("{} User: {} does not have access to chat: {}".format(
                                request_details(request),
                                decoded['user_id'],
                                comm_srvc_fk_id
                            )
                        )
                        raise Exception("User account unauthorized!")

                    chat_history_rows = Chat.objects.filter(
                        comm_srvc_fk_id=comm_srvc_fk_id
                    )

                    row_obj = row_obj.first()

                    sender_fk_id = row_obj.sender_fk_id
                    rcver_fk_id = row_obj.rcver_fk_id
                    chat_other_user_fk_id = rcver_fk_id

                    if sender_fk_id != decoded['user_id']:
                        chat_other_user_fk_id = sender_fk_id
                    else:
                        chat_other_user_fk_id = rcver_fk_id

                    user_row_obj = Users.objects.filter(id=chat_other_user_fk_id).first()

                    user_name = user_row_obj.name
                    user_surname = user_row_obj.surname

                    chat_history = ""

                    for c in chat_history_rows:
                        sender_row = Users.objects.filter(
                            id=c.sender_fk_id
                        ).first()

                        if c.sender_fk_id == decoded['user_id']:
                            chat_history += "<span style='float:right;'><strong>" + c.msg + "</strong> " + sender_row.name + " (" + c.ts_added.strftime("%a, %d %b %Y %H:%M:%S GMT") + ")" + "</span></br>"
                        else:
                            chat_history += "<span><strong>" + c.msg + "</strong> " + sender_row.name + " (" + c.ts_added.strftime("%a, %d %b %Y %H:%M:%S GMT") + ")" + "</span></br>"

                        chat_history += "</br>"

                    resource_obj_ret = {
                        'chat_history': chat_history,
                    }

                    status_code, message = get_code_and_response(['success'])
                    content = {}
                    content[MESSAGE] = message
                    content[RESOURCE_OBJ] = resource_obj_ret
                    response = {}
                    response[CONTENT] = content
                    response[STATUS_CODE] = status_code
                    log.debug("{} SUCCESS".format(request_details(request)))
                    data = response
                except ApplicationError as e:
                    log.info("{} ERROR: {}".format(request_details(request), str(e)))
                    response = {}
                    log.info("e.get_response_body(): {}".format(e.get_response_body()))
                    log.info("e.status_code: {}".format(e.status_code))
                    response[CONTENT] = e.get_response_body()
                    response[STATUS_CODE] = e.status_code
                    data = response
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to get data of associated media for artwork."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
