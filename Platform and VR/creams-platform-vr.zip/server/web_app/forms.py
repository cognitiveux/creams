from django.forms import ModelForm
from .models import *
from django import forms

class ExtendedOrganizationsForm(forms.ModelForm):
    class Meta:
        model = ExtendedOrganizations
        fields = ['name']

class ExhibitionForm(ModelForm):
    message = forms.CharField(max_length=2000,required=False)
    ts_last_updated = forms.DateTimeField(required=False)
    instructor = forms.IntegerField(required=False)
    
    class Meta:
        model = Exhibition
        fields = '__all__'
        
class VRExhibitionForm(ModelForm):
    student = forms.IntegerField(required=False)
    vr_script = forms.FileField(required=False)
    class Meta:
        model = VR_Exhibition
        fields = '__all__'
        
              
class ArtWorkForm(ModelForm):  
    user  = forms.IntegerField(required=False)
    class Meta:  
        model = Artwork  
        fields = '__all__'  
              
class UpdateArtWorkForm(ModelForm):  
    user  = forms.IntegerField(required=False)
    src  = forms.FileField(required=False)
    name  = forms.CharField(required=False)
    year  = forms.IntegerField(required=False)
    height  = forms.DecimalField(required=False)
    width  = forms.DecimalField(required=False)
    depth  = forms.DecimalField(required=False)
    unit  = forms.DecimalField(required=False)
    technique  = forms.CharField(required=False)
    genre  = forms.CharField(required=False)
    art_type  = forms.CharField(required=False)
    personalization_model = forms.CharField(required=False)
    class Meta:  
        model = Artwork  
        fields = ['src', 'name', 'year', 'height', 'width', 'depth', 'unit', 'technique', 'genre', 'art_type', 'personalization_model']
              
class UpdateAssignmentForm(ModelForm):  
    exhibition_title    = forms.CharField(required=False)
    image               = forms.FileField(required=False)
    start_date          = forms.DateField(required=False)
    end_date            = forms.DateField(required=False)
    space_assign        = forms.CharField(required=False)
    message             = forms.CharField(required=False)
    status              = forms.CharField(required=False)
    personalization_model = forms.CharField(required=False)
    ts_last_update      = forms.DateTimeField(required=False)
    class Meta:  
        model = Exhibition  
        fields = ['exhibition_title', 'start_date', 'end_date', 'image', 'space_assign', 'message', 'status', 'ts_last_update', 'personalization_model']

        
class OutdoorArtWorkForm(ModelForm):  
    description = forms.CharField(max_length=500,required=False)
    ts_last_updated = forms.DateTimeField (required=False)

    class Meta:  
        model = OutdoorArtwork  
        fields = '__all__'          

class OutdoorExhibitionForm(ModelForm):
    class Meta:
        model= OutdoorExhibition
        fields = '__all__'        

class GeneralAssessmentForm(ModelForm):  

    class Meta:  
        model = GeneralAssessment  
        fields = '__all__'          


class AudioFilesForm(ModelForm):  
    user  = forms.IntegerField(required=False)
    description  = forms.CharField(required=False)
    class Meta:  
        model = AudioFiles  
        fields = '__all__' 


class VideoFilesForm(ModelForm):  
    user  = forms.IntegerField(required=False)
    description  = forms.CharField(required=False)
    class Meta:  
        model = VideoFiles  
        fields = '__all__'