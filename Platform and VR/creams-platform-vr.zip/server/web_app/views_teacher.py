from .views import *
from django.http import HttpResponseNotAllowed


class getStudentsOfAnAssignment(RetrieveAPIView):
    """
    get: Get all students of an assignment.
    """
    permission_classes = (permissions.AllowAny,)
    response_types = [
        ['success'],
        ['bad_request'],
        ['unauthorized'],
        ['method_not_allowed'],
        ['unsupported_media_type'],
        ['internal_server_error'],
        ['resource_not_found', 'assignment'],
    ]
    
    response_dict = build_fields('getStudentsOfAnAssignment', response_types)
    
    parameters = [openapi.Parameter(
        'exh_id',
        in_=openapi.IN_QUERY,
        description='The id of the exhibition assignment',
        type=openapi.TYPE_NUMBER,
        required=True,
    )]
                  

    @swagger_auto_schema(
        responses=response_dict,
        security=[],
        manual_parameters=parameters
    )
    
    def get(self, request):
        '''
        Get all students of an assignment. 
        '''
        error_message = "ERROR!"
        try:    
            access_tkn = request.COOKIES.get('access_tkn')
            refresh_tkn = request.COOKIES.get('refresh_tkn')
            if not access_tkn:
                raise Exception("No access token provided!")
            tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
            if( tkn_okay == False):
                raise Exception("Access token invalid!")
            if( instr == False):
                raise Exception("User account unauthorized!")
        
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['unauthorized'])
            content = {
                MESSAGE: error_message
            }
            return Response(content, status=status_code)
        try:
            response = {}
            data = {}
            req_data = request.GET
            serialized_request = serialize_request(request)
            log.debug("{} START".format(request_details(request)))
            exh_id = req_data.get('exh_id')

            try:
                log.debug("{} VALID DATA".format(request_details(request)))
                exhibition_actual = Exhibition.objects.filter(id=exh_id,instructor_fk_id=decoded['user_id']).values()
                if(len(exhibition_actual) == 0):
                    exhibition_actual = AssignedExhibitionInstructor.objects.filter(assignment_fk_id=exh_id,instructor_fk_id=decoded['user_id']).values()
                    if(len(exhibition_actual) == 0):
                        raise ApplicationError(['resource_not_found', 'assignment'])
                
                student_list = AssignedExhibitionStudents.objects.filter(assignment_fk_id=exh_id).values()
                
                status_code, message = get_code_and_response(['success'])
                
                content = {}
                content[MESSAGE] = message
                header_data = {}
                header_data["students"] = []
                for a in student_list:
                    st = Users.objects.filter(id=a['student_fk_id']).values()[0]
                    data = {}
                    data["id"] = a['student_fk_id']
                    data["name"] = st['name']
                    data["surname"] = st['surname']

                    header_data["students"].append(data)

                content[RESOURCE_OBJ] = header_data     
                response = {}
                response[CONTENT] = content
                response[STATUS_CODE] = status_code
                log.debug("{} SUCCESS".format(request_details(request)))
                data = response
            except ApplicationError as e:
                log.info("{} ERROR: {}".format(request_details(request), str(e)))
                response = {}
                log.info("e.get_response_body(): {}".format(e.get_response_body()))
                log.info("e.status_code: {}".format(e.status_code))
                response[CONTENT] = e.get_response_body()
                response[STATUS_CODE] = e.status_code
                data = response

            
        except Exception as e:
            log.error("{} Internal error: {}".format(request_details(request), str(e)))
            status_code, _ = get_code_and_response(['internal_server_error'])
            content = {
                MESSAGE: "Failed to fetch students."
            }
            return Response(content, status=status_code)

        return Response(data[CONTENT], status=data[STATUS_CODE])
    
