import psycopg2

DEFAULT_EXHIBITION_ID = 1
EXHIBITION_TABLE      = 'web_app_assignedexhibitionstudents'

def assignDefault(student_fk_id):
    try:
        conn = psycopg2.connect("dbname=postgres user=postgres host=creams-postgres-poc-final")
        cursor = conn.cursor()
        postgres_insert_query = f" INSERT INTO {EXHIBITION_TABLE} (assignment_fk_id,student_fk_id) VALUES (%s,%s);"
        record_to_insert = (DEFAULT_EXHIBITION_ID,student_fk_id)
        cursor.execute(postgres_insert_query, record_to_insert)
        conn.commit()
        print("Added default successfully")
    except Exception as e:
        print("Error occurred: {}".format(str(e)))
    finally:
        cursor.close()
        conn.close()
