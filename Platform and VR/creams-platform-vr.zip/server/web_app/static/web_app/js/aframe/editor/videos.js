$(document).ready(function() {

    $(".btnAssignVideo").click(function() {
        if((TYPE == 'video' || TYPE == 'artwork') && document.getElementById("chkVideoAsMeta").checked){
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-video');
            let INDEX_ID = getID(META_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(META_OBJECT_CLASS_IDENTIFIER);
            abox.id = "video-meta-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-parent-id', ACTIVE_ELEMENT);

            //abox.setAttribute('src', $(this).data("video-src"));
            abox.setAttribute('data-video-id', $(this).data("video-id"));
            abox.setAttribute('data-meta-name', $(this).data("video-name"));

            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'associated-material');
            
            abox.setAttribute('width', 2.5);
            abox.setAttribute('height', 1.5);
        
            abox.setAttribute('setassociatedmaterialrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('position', {
                x: 2.5,
                y: 2,
                z: 0.2
            });
            abox.setAttribute('src', '#video-' + $(this).data("video-id"));
            oWall.parentElement.appendChild(abox);
            //updateDOM();
            toastr.info("Associated video");
            FillObjectsList();
        }
        else if(TYPE == 'wall' && !document.getElementById("chkVideoAsMeta").checked) {
            if (ACTIVE_ELEMENT.includes("ceiling")) {
                console.warn("Wrong type of wall");
                return;
            }
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-video');
            let INDEX_ID = getID(VIDEO_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(VIDEO_OBJECT_CLASS_IDENTIFIER);
            abox.id = "video-aframe-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-wall-id', ACTIVE_ELEMENT);

            //abox.setAttribute('src', $(this).data("video-src"));
            abox.setAttribute('data-video-id', $(this).data("video-id"));
            abox.setAttribute('data-video-name', $(this).data("video-name"));

            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'video');
            
            abox.setAttribute('width', 2.5);
            abox.setAttribute('height', 1.5);
        
            abox.setAttribute('setvideorules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('position', {
                x: 2.5,
                y: 2,
                z: 0.2
            });
            abox.setAttribute('src', '#video-' + $(this).data("video-id"));
            oWall.appendChild(abox);
            //updateDOM();
            toastr.info("Added video on wall");
            FillObjectsList();
        }
        else {
            toastr.warning("Please select a wall to assign a video or select an existing video and associate material on it.");
        }
    });
});