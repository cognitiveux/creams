$(document).ready(function() {
    $("#lstObjects").change(function() {
        if ($(this).find(":selected").val()) {
            $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");

            ACTIVE_ELEMENT = $(this).find(":selected").val();
            TYPE = $("#" + ACTIVE_ELEMENT).attr("type");

            console.log(TYPE);

            if (TYPE == "artwork" || TYPE == "object" || TYPE == "video" || TYPE == "associated-material") {
                $("#divTextHandling").hide("slow");
                $("#divSizeHandling").show("slow");
                $("#divPositioning").show("slow");
                $("#divDeleteObject").show("slow");
            }
            else if (TYPE == "text" || TYPE == "associated-text") {
                $("#txtObjectText").val($("#" + ACTIVE_ELEMENT).attr("data-text-full"));
                $("#divTextHandling").show("slow");
                $("#divSizeHandling").show("slow");
                $("#divPositioning").show("slow");
                $("#divDeleteObject").show("slow");
            }
        }
    });

    $("#btnToggleAllAssociatedMaterial").click(function() {
        $.each($("." + META_OBJECT_CLASS_IDENTIFIER), function() {
            if ($(this).attr("visible")) {
                $(this).attr("visible", false);
            }
            else {
                $(this).attr("visible", true);
            }
        });
        $.each($("." + META_TEXT_OBJECT_CLASS_IDENTIFIER), function() {
            if ($(this).attr("visible")) {
                $(this).attr("visible", false);
            }
            else {
                $(this).attr("visible", true);
            }
        });
    });

    $("#btnStopAllVideos").click(function() {
        $.each($("video"), function() {
            $(this)[0].pause()
        });
        IsVideoPlaying = false;
    });

    $.each($("." + META_OBJECT_CLASS_IDENTIFIER), function() {
        if ($(this).attr("visible")) {
            $(this).attr("visible", false);
        }
        else {
            $(this).attr("visible", true);
        }
    });
    $.each($("." + META_TEXT_OBJECT_CLASS_IDENTIFIER), function() {
        if ($(this).attr("visible")) {
            $(this).attr("visible", false);
        }
        else {
            $(this).attr("visible", true);
        }
    });

    $.each($("video"), function() {
        $(this)[0].pause()
    });
    IsVideoPlaying = false;

    $(".a-loader-title").hide();
    $(".a-enter-ar").hide();
});

function FillObjectsList() {
    $("#lstObjects").empty();
    $.each($("." + ARTWORK_CLASS_IDENTIFIER), function() {
        let artwork_name = this.getAttribute("data-artwork-name");
        $("#lstObjects").append($("<option />").val(this.id).text(artwork_name + " (" + this.id + ")"));
    });
    $.each($("." + THREE_D_OBJECT_CLASS_IDENTIFIER), function() {
        let artwork_name = this.getAttribute("data-artwork-name");
        $("#lstObjects").append($("<option />").val(this.id).text(artwork_name + " (" + this.id + ")"));
    });
    $.each($("." + TEXT_OBJECT_CLASS_IDENTIFIER), function() {
        let text_short = this.getAttribute("data-text-short");
        $("#lstObjects").append($("<option />").val(this.id).text(text_short + " (" + this.id + ")"));
    });
    $.each($("." + VIDEO_OBJECT_CLASS_IDENTIFIER), function() {
        let video_name = this.getAttribute("data-video-name");
        $("#lstObjects").append($("<option />").val(this.id).text(video_name + " (" + this.id + ")"));
    });
    $.each($("." + META_OBJECT_CLASS_IDENTIFIER), function() {
        let meta_name = this.getAttribute("data-meta-name");
        $("#lstObjects").append($("<option />").val(this.id).text(meta_name + " (" + this.id + ")"));
    });
    $.each($("." + META_TEXT_OBJECT_CLASS_IDENTIFIER), function() {
        let meta_name = this.getAttribute("data-meta-name");
        $("#lstObjects").append($("<option />").val(this.id).text(meta_name + " (" + this.id + ")"));
    });
    $("#lstObjects").val(ACTIVE_ELEMENT);
    $("#lstObjects")[0].dispatchEvent(new Event("change"));
}

function SelectObject() {
    $("#lstObjects").val(ACTIVE_ELEMENT);
    $("#lstObjects")[0].dispatchEvent(new Event("change"));
}

FillObjectsList();

/**
 * This function gets the next possible correct id of an asset based on its identifier.
 * 
 * @param {*} class_identifier : Class name of assets
 * @returns Integer
 */
function getID(class_identifier) {
    let items = document.getElementsByClassName(class_identifier);
    let data_ids = [];

    data_ids.push(0);

    for (let i = 0; i < items.length; i++)
        data_ids.push(items[i].getAttribute('data-increment-id'));

    return Math.max(...data_ids) + 1;
}

function updateDOM() {
    let z = document.getElementById(ACTIVE_ELEMENT);
    //document.querySelector('#' + z.id).flushToDOM(true);
}

/**
 * Initialize aframe components.
 */
function activateArtworkChangeFunctionForABoxes() {
    // var places = document.getElementsByTagName('a-box');
    // var len = places.length;
    // for (let i = 0; i < len; i++) {
    //     var child = places[i];
    //     if (child.getAttribute('type') === "element") {
    //         child.setAttribute('setwallrules', 'txt:' + child.getAttribute('id'));
    //     } else {
    //         child.setAttribute('setartworkrules', 'txt:' + child.getAttribute('id'));
    //         child.setAttribute('clickhandler', 'txt:' + child.getAttribute('id'));
    //     }
    //     //child.flushToDOM(true);
    // }

    // places = document.getElementsByTagName('a-entity');
    // len = places.length;
    // for (let i = 0; i < len; i++) {
    //     var child = places[i];
    //     if (child.getAttribute('id') != null && child.getAttribute('id') != "rig" && child.getAttribute('id') != "ambient") {
    //         child.setAttribute('setlabelrules', 'txt:' + child.getAttribute('id'));
    //     }
    //     //child.flushToDOM(true);
    // }

    // places = document.getElementsByTagName('a-plane');
    // len = places.length;
    // for (let i = 0; i < len; i++) {
    //     var child = places[i];
    //     if (child.classList.contains(AUDIO_CLASS_IDENTIFIER)) {
    //         child.setAttribute('setartworkrules', 'txt:' + child.getAttribute('id'));
    //         child.setAttribute('clickhandler', 'txt:' + child.getAttribute('id'));
    //     }
    //     //child.flushToDOM(true);
    // }

    // places = document.getElementsByTagName('a-video');
    // len = places.length;
    // for (let i = 0; i < len; i++) {
    //     var child = places[i];
    //     child.setAttribute('setartworkrules', 'txt:' + child.getAttribute('id'));
    //     child.setAttribute('clickhandler', 'txt:' + child.getAttribute('id'));
    //     //child.flushToDOM(true);
    // }

    places = document.getElementsByTagName('rw-wall');
    len = places.length;
    for (let i = 0; i < len; i++) {
        var child = places[i];
        child.setAttribute('setwallrules', 'txt:' + child.getAttribute('id'));
    }

    places = document.getElementsByTagName('rw-ceiling');
    len = places.length;
    for (let i = 0; i < len; i++) {
        var child = places[i];
        child.setAttribute('setwallrules', 'txt:' + child.getAttribute('id'));
    }

    let floor_handlers = document.querySelector("[type=floor]");

    floor_handlers.setAttribute('setfloorrules', 'txt:floor');

}

activateArtworkChangeFunctionForABoxes();

/**
 * This function makes the meta artifacts go away, it is called on save.
 */
function hideMetaArtifacts() {
    let list_of_artifacts = document.getElementsByClassName(META_OBJECT_CLASS_IDENTIFIER);
    for (let i = 0; i < list_of_artifacts.length; i++) {
        list_of_artifacts[i].setAttribute('visible', false);
        //list_of_artifacts[i].flushToDOM(true);
    }
}

/**
 * This function makes the meta artifacts visible.
 */
function showMetaArtifacts() {
    let list_of_artifacts = document.getElementsByClassName(META_OBJECT_CLASS_IDENTIFIER);
    for (let i = 0; i < list_of_artifacts.length; i++) {
        list_of_artifacts[i].setAttribute('visible', true);
        //list_of_artifacts[i].flushToDOM(true);
    }
}

/**
 * This function is called in order to show the meta artifacts that already exist on the database version of the exhibition.
 */
//showMetaArtifacts();

/**
 * This function saves the exhibition. In order to correctly save the exhibition
 * we have to remove some elements.
 */
function saveExhibit() {
    document.querySelector('a-scene').flushToDOM(true);
    
    let submitButton = document.getElementById('btnSaveExhibition');
    submitButton.disabled = true;
    //hideMetaArtifacts();
    //removeUnusedArtworksFromAssetList();

    let exh = document.getElementsByTagName('a-scene')[0].cloneNode(true);
    
    exh.getElementsByTagName('a-assets')[0].remove();

    exh.getElementsByTagName('canvas')[0].remove();
    let falseCameras = exh.getElementsByTagName('a-entity');
    let toBeDeletedIds = [];
    for (let i = 0; i < falseCameras.length; i++)
        if (falseCameras[i].getAttribute('camera') !== null)
            toBeDeletedIds.push(i);
    for (let i = 0; i < toBeDeletedIds.length; i++) {
        falseCameras[i].remove();
    }

    //exh.getElementsByTagName('a-camera').forEach(b=>b.removeAttribute('position'));
    Array.from(exh.getElementsByTagName('a-camera')).forEach(b => b.removeAttribute('position'));
    
    /**
     * Remove one extra camera that messes up gravity
     */
    // exh.getElementsByTagName('a-camera')[0].remove();
    //exh = exh.outerHTML;
    exh = exh.innerHTML;

    /**
     * Remove items that mess up gravity
     */
    while (exh.includes('velocity=""'))
        exh = exh.replace('velocity=""', ' ');
    while (exh.includes('geometry=""'))
        exh = exh.replace('geometry=""', ' ');
    while (exh.includes('material=""'))
        exh = exh.replace('material=""', ' ');
    while (exh.includes('static-body=""'))
        exh = exh.replace('static-body=""', 'static-body');
    while (exh.includes('dynamic-body=""'))
        exh = exh.replace('dynamic-body=""', 'dynamic-body');

    console.log(exh);
    
    var xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange", function () {
        // Only run if the request is complete
        if (xhr.readyState !== 4) return;
        // Process our return data
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            //syncArtworks(response['resource_id']);
            Swal.fire({
                text: "Your exhibition has been successfully saved!",
                icon: "success",
                timer: 2000,
                buttonsStyling: false,
                confirmButtonText: "Ok, got it!",
                customClass: {
                    confirmButton: "btn btn-primary"
                }
            }).then(function (result) {
                submitButton.disabled = false;
                //location.href = "/web_app/student/dashboard/";
            });
        } else {
            Swal.fire({
                text: "Something went wrong!",
                icon: "error",
                timer: 2000,
                buttonsStyling: false,
                confirmButtonText: "Ok, got it!",
                customClass: {
                    confirmButton: "btn btn-primary"
                }
            });
        }
    });

    xhr.open("POST", "/web_app/exhibitions/indoor/create/vr", false);
    /*INSERT DATA*/
    let formData = new FormData(); // creates an object, optionally fill from <form>
    formData.append("vr_exhibition ", new Blob([exh], {
        type: "text/plain"
    }), "" + USER_ID + "_" + exh_id + ".txt");
    // formData.append("vr_script ", new Blob([getNewScript(items)], {
    //     type: "text/plain"
    // }), "" + USER_ID + "_" + exh_id + ".js");

    formData.append("exhibition_fk", exh_id); // appends a field
    xhr.send(formData);
}

function saveExhibitionAndDownload(e) {
    saveExhibit();
    window.open("/media/vr_exhibitions/" + USER_ID + "_" + exh_id + ".txt", '_blank');
}

function cancelExhibit() {
    const backto = "/web_app/student/exhibitions/";
    Swal.fire({
        text: "Are you sure you would like to cancel your changes? Any unsaved changes will be lost.",
        icon: "warning",
        showCancelButton: true,
        buttonsStyling: false,
        confirmButtonText: "Yes, cancel the changes and leave",
        cancelButtonText: "No, continue editing the exhibition",
        customClass: {
            confirmButton: "btn btn-primary",
            cancelButton: "btn btn-active-light"
        }
    }).then(function (result) {
        if (result.value) {
            location.replace(backto);
        } else if (result.dismiss === 'cancel') {}
    });
}