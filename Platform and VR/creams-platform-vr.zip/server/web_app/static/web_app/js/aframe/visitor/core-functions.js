$(document).ready(function() {
    $("#btnToggleAllAssociatedMaterial").click(function() {
        $.each($("." + META_OBJECT_CLASS_IDENTIFIER), function() {
            if ($(this).attr("visible")) {
                $(this).attr("visible", false);
            }
            else {
                $(this).attr("visible", true);
            }
        });
        $.each($("." + META_TEXT_OBJECT_CLASS_IDENTIFIER), function() {
            if ($(this).attr("visible")) {
                $(this).attr("visible", false);
            }
            else {
                $(this).attr("visible", true);
            }
        });
    });

    $("#btnStopAllVideos").click(function() {
        $.each($("video"), function() {
            $(this)[0].pause()
        });
        IsVideoPlaying = false;
    });

    $.each($("." + META_OBJECT_CLASS_IDENTIFIER), function() {
        if ($(this).attr("visible")) {
            $(this).attr("visible", false);
        }
        else {
            $(this).attr("visible", true);
        }
    });
    $.each($("." + META_TEXT_OBJECT_CLASS_IDENTIFIER), function() {
        if ($(this).attr("visible")) {
            $(this).attr("visible", false);
        }
        else {
            $(this).attr("visible", true);
        }
    });

    $.each($("video"), function() {
        $(this)[0].pause()
    });
    IsVideoPlaying = false;

    $(".a-loader-title").hide();
    $(".a-enter-ar").hide();
});