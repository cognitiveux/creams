$(document).ready(function() {
    $(".btnAssignTwodArtwork").click(function() {
        if ((TYPE == 'artwork' || TYPE == 'video') && document.getElementById("chkArtworkAsMeta").checked) {
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-image');
            let INDEX_ID = getID(META_OBJECT_CLASS_IDENTIFIER);

            abox.classList.add(META_OBJECT_CLASS_IDENTIFIER);
            abox.id = "two-d-artwork-aframe-meta-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-parent-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'associated-material');

            abox.setAttribute('position', {
                x: 2.5,
                y: 2.5,
                z: 1.2
            });
            
            abox.setAttribute('setassociatedmaterialrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute("data-artwork-id", $(this).data("artwork-id"));
            abox.setAttribute("data-meta-name", $(this).data("artwork-name"));
            artwork_width = $(this).data("artwork-width") * 0.0002645833; // 1px = 0.0002645833m
            artwork_height = $(this).data("artwork-height") * 0.0002645833;
            abox.setAttribute("width", artwork_width);
            abox.setAttribute("height", artwork_height);
            scale_value = 1.5/artwork_width;
            if (artwork_width <= artwork_height) {
                scale_value = 1.5/artwork_height;
            }
            abox.setAttribute('scale', {
                x: scale_value,
                y: scale_value,
                z: 1
            });
            abox.setAttribute('src', '#two-d-artwork-' + $(this).data("artwork-id"));
            oWall.parentElement.appendChild(abox);

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     element.setAttribute("visible", true);
            //     // element.setAttribute('shadow', "cast: false");
            //     // element.setAttribute('shadow', "receive: false");
            //     // element.setAttribute('setbuttonrules', 'txt:' + ACTIVE_ELEMENT);
            //     // element.setAttribute('clickhandler', 'txt:' + ACTIVE_ELEMENT);
            // });

            //abox.flushToDOM(true);
            toastr.info("Associated the artwork");
            FillObjectsList();
        }
        else if(TYPE == 'wall' && !document.getElementById("chkArtworkAsMeta").checked) {
            if (ACTIVE_ELEMENT.includes("ceiling")) {
                console.warn("Wrong type of wall");
                return;
            }
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-image');
            let INDEX_ID = getID(ARTWORK_CLASS_IDENTIFIER);

            abox.classList.add(ARTWORK_CLASS_IDENTIFIER);
            abox.id = "two-d-artwork-aframe-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-wall-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'artwork');

            if(ACTIVE_ELEMENT == "room0-pillar"){
                abox.setAttribute('position', {
                    x: 0,
                    y: -.8,
                    z: 0.05
                });
            }
            else {
                abox.setAttribute('position', {
                    x: 1.525,
                    y: 2,
                    z: 0.02
                });
            }
            
            abox.setAttribute('setartworkrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute("data-artwork-id", $(this).data("artwork-id"));
            abox.setAttribute("data-artwork-name", $(this).data("artwork-name"));
            artwork_width = $(this).data("artwork-width") * 0.0002645833; // 1px = 0.0002645833m
            artwork_height = $(this).data("artwork-height") * 0.0002645833;
            abox.setAttribute("width", artwork_width);
            abox.setAttribute("height", artwork_height);
            scale_value = 1.5/artwork_width;
            if (artwork_width <= artwork_height) {
                scale_value = 1.5/artwork_height;
            }
            abox.setAttribute('scale', {
                x: scale_value,
                y: scale_value,
                z: 1
            });
            abox.setAttribute('src', '#two-d-artwork-' + $(this).data("artwork-id"));
            oWall.appendChild(abox);

            // let abtn = document.createElement('a-image');
            // let INDEX_ID_FOR_BUTTON = getID(META_BUTTON_CLASS_IDENTIFIER);
            // abtn.classList.add(META_BUTTON_CLASS_IDENTIFIER);
            // abtn.id = "meta-button-" + INDEX_ID_FOR_BUTTON;
            // abtn.setAttribute('data-increment-id', INDEX_ID_FOR_BUTTON);
            // abtn.setAttribute('data-meta-parent-object-id', abox.id);
            // abtn.setAttribute('depth', '0.2');
            // abtn.setAttribute('src', '#btn-creams');
            // abtn.setAttribute('position', {
            //     // x: 2.165,//1.525
            //     // y: 1.27,//2
            //     x: 1.525+(artwork_width*scale_value/2),
            //     y: 2+(artwork_height*scale_value/2),
            //     z: 0.2
            // });
            // abtn.setAttribute('scale', {
            //     x: .5,
            //     y: .5,
            //     z: .5
            // });
            // abtn.setAttribute('shadow', "cast: false");
            // abtn.setAttribute('shadow', "receive: false");
            // abtn.setAttribute('visible', false);
            // abtn.setAttribute('setbuttonrules', 'txt:' + abox.id);
            // abtn.setAttribute('clickhandler', 'txt:' + abox.id);
            // oWall.appendChild(abtn);

            //abox.flushToDOM(true);
            toastr.info("Added 2D artwork on wall");
            FillObjectsList();
        }
        else {
            toastr.warning("Please select a wall to assign an artwork or select an existing artwork and associate material on it.");
        }
    });

    $(".btnAssignThreedArtwork").click(function() {
        if ((TYPE == 'artwork' || TYPE == 'video') && document.getElementById("chkArtworkAsMeta").checked) {
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-entity');
            let INDEX_ID = getID(META_OBJECT_CLASS_IDENTIFIER);
            
            abox.classList.add(META_OBJECT_CLASS_IDENTIFIER);
            abox.id = "three-d-artwork-aframe-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-parent-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'associated-material');

            if(ACTIVE_ELEMENT == "room0-pillar"){
                abox.setAttribute('position', {
                    x: 0,
                    y: -.8,
                    z: 0.05
                });
            }
            else {
                abox.setAttribute('position', {
                    x: 1.525,
                    y: 2,
                    z: 0.02
                });
            }
            
            abox.setAttribute('setassociatedmaterialrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute("data-artwork-id", $(this).data("artwork-id"));
            abox.setAttribute("data-meta-name", $(this).data("artwork-name"));
            
            var scale_value = 1;
            abox.setAttribute('scale', {
                x: scale_value,
                y: scale_value,
                z: 1
            });

            if ($(this).data("artwork-genre") == "glb") {
                abox.setAttribute('gltf-model', "#three-d-artwork-" + $(this).data("artwork-id") + "-glb");
            }
            else if ($(this).data("artwork-genre") == "gltf") {
                abox.setAttribute('gltf-model', "#three-d-artwork-" + $(this).data("artwork-id") + "-gltf");
            }
            else if ($(this).data("artwork-genre") == "obj") {
                abox.setAttribute('obj-model', "obj: #three-d-artwork-" + $(this).data("artwork-id") + "-obj; mtl: #three-d-artwork-" + $(this).data("artwork-id") + "-mtl");
            }
            oWall.parentElement.appendChild(abox);
            //abox.flushToDOM(true);
            toastr.info("Associated the artwork");
            FillObjectsList();
        }
        else if(TYPE == 'wall' && !document.getElementById("chkArtworkAsMeta").checked) {
            if (ACTIVE_ELEMENT.includes("ceiling")) {
                console.warn("Wrong type of wall");
                return;
            }
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-entity');
            let INDEX_ID = getID(THREE_D_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(THREE_D_OBJECT_CLASS_IDENTIFIER);
            abox.id = "three-d-artwork-aframe-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-wall-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'artwork');

            if(ACTIVE_ELEMENT == "room0-pillar"){
                abox.setAttribute('position', {
                    x: 0,
                    y: -.8,
                    z: 0.05
                });
            }
            else {
                abox.setAttribute('position', {
                    x: 1.525,
                    y: 2,
                    z: 0.02
                });
            }
            
            abox.setAttribute('setartworkrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute("data-artwork-id", $(this).data("artwork-id"));
            abox.setAttribute("data-artwork-name", $(this).data("artwork-name"));
            
            var scale_value = 1;
            abox.setAttribute('scale', {
                x: scale_value,
                y: scale_value,
                z: 1
            });

            if ($(this).data("artwork-genre") == "glb") {
                abox.setAttribute('gltf-model', "#three-d-artwork-" + $(this).data("artwork-id") + "-glb");
            }
            else if ($(this).data("artwork-genre") == "gltf") {
                abox.setAttribute('gltf-model', "#three-d-artwork-" + $(this).data("artwork-id") + "-gltf");
            }
            else if ($(this).data("artwork-genre") == "obj") {
                abox.setAttribute('obj-model', "obj: #three-d-artwork-" + $(this).data("artwork-id") + "-obj; mtl: #three-d-artwork-" + $(this).data("artwork-id") + "-mtl");
            }
            oWall.appendChild(abox);
            //abox.flushToDOM(true);
            toastr.info("Added 3D artwork on wall");
            FillObjectsList();
        }
        else {
            toastr.warning("Please select a wall to assign an artwork or select an existing artwork and associate material on it.");
        }
    });
});