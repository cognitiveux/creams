function ExtractColorValue(str) {
    var value = "#FFFFFF";
    if (typeof str === 'string') {
        var match = str.match(/color:\s*#([0-9a-fA-F]{6})/);
        value = match ? `#${match[1]}` : "#FFFFFF";
    } else if (typeof str === 'object' && str !== null) {
        str = str.color;
        value = str ? str : "#FFFFFF";
    }

    return value;
}

function ExtractIntensityValue(str) {
    var value = 0.7;
    if (typeof str === 'string') {
        var match = str.match(/intensity:\s*([0-9.]+)/);
        value = match ? parseFloat(match[1]) : 0.7;
    } else if (typeof str === 'object' && str !== null) {
        str = str.intensity;
        value = str ? str : 0.7;
    }

    return value;
}

function ExtractLightColorValue(str) {
    var value = "#FFFFFF";
    if (typeof str === 'string') {
        var match = str.match(/color:\s*#([0-9a-fA-F]{6})/);
        value = match ? `#${match[1]}` : "#FFFFFF";
    } else if (typeof str === 'object' && str !== null) {
        str = str.color;
        value = str ? str : "#FFFFFF";
    }

    return value;
}

$(document).ready(function() {
    $("#txtWallsColor")[0].jscolor.fromString(ExtractColorValue(document.getElementsByClassName("creams-walls")[0].getAttribute("material")));
    $("#txtCeilingColor")[0].jscolor.fromString(ExtractColorValue(document.getElementsByClassName("creams-ceiling")[0].getAttribute("material")));
    $("#txtFloorColor")[0].jscolor.fromString(ExtractColorValue(document.getElementsByClassName("creams-floor")[0].getAttribute("material")));

    $("#rngUpdateAmbientLightIntensity").val(ExtractIntensityValue(document.getElementById("ambient").getAttribute("light")) * 100.00);
    $("#txtAmbientLightColor")[0].jscolor.fromString(ExtractLightColorValue(document.getElementById("ambient").getAttribute("light")));

    $("#txtWallsColor").change(function() {
        $(".creams-walls").each(function(){
            this.setAttribute('material', 'color:' + $("#txtWallsColor").val()); 
        });
    });
    
    $("#txtCeilingColor").change(function() {
        $(".creams-ceiling").each(function(){
            this.setAttribute('material', 'color:' + $("#txtCeilingColor").val()); 
        });
    });
    
    $("#txtFloorColor").change(function() {
        $(".creams-floor").each(function(){
            this.setAttribute('material', 'color:' + $("#txtFloorColor").val()); 
        });
    });

    $("#rngUpdateAmbientLightIntensity").change(function() {
        var ambient_light = document.getElementById('ambient');
        ambient_light.setAttribute('light', {
            intensity: parseFloat($("#rngUpdateAmbientLightIntensity").val()) / 100.0
        });
        //ambient_light.flushToDOM(true);
    });

    $("#txtAmbientLightColor").change(function() {
        var ambient_light = document.getElementById('ambient');
        ambient_light.setAttribute('light', {
            color: $("#txtAmbientLightColor").val()
        });
        //ambient_light.flushToDOM(true);
    });
});