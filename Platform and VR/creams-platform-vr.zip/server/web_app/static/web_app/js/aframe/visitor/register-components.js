AFRAME.registerComponent('setartworkrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                var abtn = $("[data-parent-id='" + data.txt + "']");
                abtn.each(function() {
                    if ($(this).attr("visible")) {
                        $(this).attr("visible", false);
                    }
                    else {
                        $(this).attr("visible", true);
                    }
                });
            }
        });
    }
});

AFRAME.registerComponent('setthreedrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                var abtn = $("[data-parent-id='" + data.txt + "']");
                abtn.each(function() {
                    if ($(this).attr("visible")) {
                        $(this).attr("visible", false);
                    }
                    else {
                        $(this).attr("visible", true);
                    }
                });
            }
        });
    }
});

AFRAME.registerComponent('setvideorules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                var video_id = document.getElementById(data.txt).getAttribute('data-video-id');
                var active_element = document.getElementById("video-" + video_id);
                IsVideoPlaying ? active_element.pause() : active_element.play();
                IsVideoPlaying = !IsVideoPlaying;
            }
        });
    }
});

AFRAME.registerComponent('setassociatedmaterialrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                var video_id = document.getElementById(data.txt).getAttribute('data-video-id');
                var active_element = document.getElementById("video-" + video_id);
                if (active_element) {
                    IsVideoPlaying ? active_element.pause() : active_element.play();
                    IsVideoPlaying = !IsVideoPlaying;
                }
            }
        });
    }
});