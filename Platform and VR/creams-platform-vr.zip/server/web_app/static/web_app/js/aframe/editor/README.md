# AFrame Editor README


### Modular Definition of Space

The space creation is accomplished using the /editor_v2/createPlace.html page where the user can create a 2D space by clicking on a canvas element. Any click event results in the addition of a rectangle on the canvas. The first rectangle is always green which mean it will be considered the starting point of the exhibition. There **must** only be **one starting point.** All the other rectangles are pink/redish. If the user clicks on an existing rectangle this rectangle is deleted. If the green rectangle is deleted, the next click on an existing rectangle will turn the clicked rectangle, green. 

After the creation of the 2D blueprint the user can define the height of the room. This blueprint is then translated into a dictionary:

```json
{				"0":{"x":0,"y":1,"starting":true,"up":false,"upTo":-1,"down":true,"downTo":3,"right":false,"rightTo":-1,"left":false,"leftTo":-1},
        "1":{"x":1,"y":0,"starting":false,"up":false,"upTo":-1,"down":false,"downTo":-1,"right":true,"rightTo":3,"left":true,"leftTo":2},
				"2":{"x":2,"y":0,"starting":false,"up":false,"upTo":-1,"down":false,"downTo":-1,"right":true,"rightTo":1,"left":false,"leftTo":-1},
				"3":{"x":0,"y":0,"starting":false,"up":true,"upTo":0,"down":false,"downTo":-1,"right":false,"rightTo":-1,"left":true,"leftTo":1}
}
```

Each key value (0,1,2,3) represents a room.

![vr_modular.png](vr_modular.png)

| Key Value | Explanation |
| --- | --- |
| (x,y) | Coordinates of the room on a cartesian system |
| starting | True or False. The starting room of the exhibition |
| up | True or False. If the room is connected to another room on the up side of it. |
| upTo | The id of the room this room is connected with on the up side of it. |
| down | True or False. If the room is connected to another room on the down side of it. |
| downTo | The id of the room this room is connected with on the down side of it. |
| right | True or False. If the room is connected to another room on the right side of it. |
| rightTo | The id of the room this room is connected with on the right side of it. |
| left | True or False. If the room is connected to another room on the left side of it. |
| leftTo | The id of the room this room is connected with on the left side of it. |

---

### Core Functionalities

This is the main script of the editor. The editor usage can be defined into two phases, these phases are controlled by the `ACTIVE_WALLS` variable, if the `ACTIVE_WALLS` value is true only walls can be selected and if it is false you can select any boxes, or text. The selection functionality is relatively simple, when clicking on an element with the appropriate `ACTIVE_WALLS` flag enabled the corresponding code is executed and the `ACTIVE_ELEMENT` and `TYPE` variables change accordingly.

```jsx
/**
 * Artwork handling AFRAME component.
 */
AFRAME.registerComponent('setartworkrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null" && !ACTIVE_WALLS) {
                ACTIVE_ELEMENT = data.txt;
                TYPE = 'box';
                toastr.info(ACTIVE_ELEMENT + ' is selected ' + TYPE);
                fillData();
            }

        });
    }
});
```

This is an example of the corresponding code that is executed. The AFrame way of registering event handling is through the usage on components, these components actually look like HTML attributes.

The `updateDOM` function is one of the most useful functions on the system, when changing something it’s a good practise to update the DOM in order for your change to be visiblem, this function update the `ACTIVE_ELEMENT` only. Matter of fact most functions are aligned with the `ACTIVE_ELEMENT` variable. Other useful functions are the resizing and moving tools which are universally used in the system and the saving functionalities

---

### Add Sound

This script handles are things related with sound. Firstly all the audio files are fetched from the Database and listed on a Datatable. If the `meta_switch_audio` is not enabled the `Add Sound` button results in the selected sound being used as an ambient sound and a player appears where the user can set the audio to be onloop, pause it or remove it all-together. If the `meta_switch_audio` is enabled, the user has to select an artwork-box (by clicking on it) and then click the `Add Sound` button to add the audio as a clickable sketchbook part of the artwork.

---

### Add Video

This script handles are things related with videos. Firstly all the video files are fetched from the Database and listed on a Datatable. If the `meta_switch` is not enabled the `Add Video` button results in the selected video being used as a video exhibit that is inserted to the wall as box. If the `meta_switch` is enabled, the user has to select an artwork-box (by clicking on it) and then click the `Add Video` button to add the video as a sketchbook part of the artwork.

---

### Asset Management

This script handles how different assets, mainly artworks are being treated by the editor. Some of the main features are the `active artwork selection`, which means filtering out which artworks are currently used on the exhibition. Additionally, this script registers & edits this list that is stored on the database (`syncArtworks` function). Moreover, this script handles the addition of HTML code in order to add assets to a scrollable list on the `Artworks` tab for the artworks and on the `Walls` tab for the textures.

---

### Element Addition

This script is used for the addition of elements on the exhibition. Most of the functions defined here follow the same logic. Remember that `audio` and `video` addition is not defined in this script but in their own dedicated scripts. In order to identify and categorize our elements we use some classes and attributes defined on the `identifiers_and_variables` script, other than that the elements are constructed based on the [AFrame documentation](https://aframe.io/docs/1.4.0/introduction/). Be extra careful when assigning IDs to the elements, use the `getID` function with the correct class identifier. All of the elements are added on a specific location relative to the wall or artwork they’re paired with.

---

### Element Selection

This script is used to create, sync and manage the dropdown list and its elements.

---

### Identifiers and Variables

In general this script is used to define some class identifiers and other useful variables that are used throughout the editor.

---

### Lighting

This script handles all the lighting features of the editor. When the `lighting` tab is enabled a handler for all spotlights is created. Additionally, the ambient light can be edited. Finally, all the variables of a spotlight are explained below (for more details visit the [AFrame documentation](https://aframe.io/docs/1.4.0/components/light.html#spot)).

| Variable | Explanation |
| --- | --- |
| Light Color | From a color input element the user can select their preferred color by clicking on the color tab, sampling from the webpage, entering RGB value or HEX value. |
| Intensity |  The user can set the intensity of the light between 0 and 100. |
| Angle | The user can set the angle of the spotlight between 0 and 80 degrees. |
| Position | For y-axis and x-axis the user must use the arrow buttons to change the position of the spotlight, for z-axis the user must use the z-axis slider that ranges from 0 to 5 (based on the size of the room). |
| Penumbra | The user can set the percent of the spotlight cone that is attenuated due to penumbra between 0% and 100%. |
| Decay | The user can set the amount the light dims along the distance of the light between 0 and 100. |
| Distance | The user can set the distance where intensity becomes 0. If distance is 0, then the point light does not decay with distance. |
| Rotation | The user can set the rotation of the spotlight in three axis (y,x and z). |
| Alias | The user can set an alias to the spotlight in order to identify it easily. |

---

### Sketchbook

This script handles the sketchbook functionalities of the editor.

---
