$(document).ready(function() {
    $("#btnScaleUp").click(function() {
        var oScalingValueForSize = parseFloat($("#txtScalingValueForSize").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.scale.set(active_element.getAttribute("scale").x + oScalingValueForSize, active_element.getAttribute("scale").y + oScalingValueForSize, active_element.getAttribute("scale").z + oScalingValueForSize);
            active_element.setAttribute('scale', {x: active_element.getAttribute('scale').x + oScalingValueForSize, y: active_element.getAttribute('scale').y + oScalingValueForSize, z: active_element.getAttribute('scale').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     element.setAttribute('scale', {x: element.getAttribute('scale').x + oScalingValueForSize/2, y: element.getAttribute('scale').y + oScalingValueForSize/2, z: element.getAttribute('scale').z});
            // });
        }
    });

    $("#btnScaleDown").click(function() {
        var oScalingValueForSize = parseFloat($("#txtScalingValueForSize").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.scale.set(active_element.getAttribute("scale").x - oScalingValueForSize, active_element.getAttribute("scale").y - oScalingValueForSize, active_element.getAttribute("scale").z - oScalingValueForSize);
            active_element.setAttribute('scale', {x: active_element.getAttribute('scale').x - oScalingValueForSize, y: active_element.getAttribute('scale').y - oScalingValueForSize, z: active_element.getAttribute('scale').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     element.setAttribute('scale', {x: element.getAttribute('scale').x - oScalingValueForSize/2, y: element.getAttribute('scale').y - oScalingValueForSize/2, z: element.getAttribute('scale').z});
            // });
        }
    });

    $("#btnRotateUp").click(function() {
        var oScalingValueForRotation = parseFloat($("#txtScalingValueForRotation").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.setAttribute("rotation", {x: active_element.getAttribute("rotation").x + oScalingValueForRotation, y: active_element.getAttribute("rotation").y, z: active_element.getAttribute("rotation").z});
            active_element.setAttribute('rotation', {x: active_element.getAttribute('rotation').x + oScalingValueForRotation, y: active_element.getAttribute('rotation').y, z: active_element.getAttribute('rotation').z});
        }
    });

    $("#btnRotateDown").click(function() {
        var oScalingValueForRotation = parseFloat($("#txtScalingValueForRotation").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.setAttribute("rotation", {x: active_element.getAttribute("rotation").x - oScalingValueForRotation, y: active_element.getAttribute("rotation").y, z: active_element.getAttribute("rotation").z});
            active_element.setAttribute('rotation', {x: active_element.getAttribute('rotation').x - oScalingValueForRotation, y: active_element.getAttribute('rotation').y, z: active_element.getAttribute('rotation').z});
        }
    });

    $("#btnRotateRight").click(function() {
        var oScalingValueForRotation = parseFloat($("#txtScalingValueForRotation").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.setAttribute("rotation", {x: active_element.getAttribute("rotation").x, y: active_element.getAttribute("rotation").y + oScalingValueForRotation, z: active_element.getAttribute("rotation").z});
            active_element.setAttribute('rotation', {x: active_element.getAttribute('rotation').x, y: active_element.getAttribute('rotation').y + oScalingValueForRotation, z: active_element.getAttribute('rotation').z});
        }
    });

    $("#btnRotateLeft").click(function() {
        var oScalingValueForRotation = parseFloat($("#txtScalingValueForRotation").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.setAttribute("rotation", {x: active_element.getAttribute("rotation").x, y: active_element.getAttribute("rotation").y - oScalingValueForRotation, z: active_element.getAttribute("rotation").z});
            active_element.setAttribute('rotation', {x: active_element.getAttribute('rotation').x, y: active_element.getAttribute('rotation').y - oScalingValueForRotation, z: active_element.getAttribute('rotation').z});
        }
    });

    $("#btnPositionUp").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x, active_element.getAttribute('position').y + oScalingValueForPosition, active_element.getAttribute('position').z);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x, y: active_element.getAttribute('position').y + oScalingValueForPosition, z: active_element.getAttribute('position').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x, element.getAttribute('position').y + oScalingValueForPosition, element.getAttribute('position').z);
            //     element.setAttribute('position', {x: element.getAttribute('position').x, y: element.getAttribute('position').y + oScalingValueForPosition, z: element.getAttribute('position').z});
            // });
        }
    });

    $("#btnPositionDown").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x, active_element.getAttribute('position').y - oScalingValueForPosition, active_element.getAttribute('position').z);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x, y: active_element.getAttribute('position').y - oScalingValueForPosition, z: active_element.getAttribute('position').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x, element.getAttribute('position').y - oScalingValueForPosition, element.getAttribute('position').z);
            //     element.setAttribute('position', {x: element.getAttribute('position').x, y: element.getAttribute('position').y - oScalingValueForPosition, z: element.getAttribute('position').z});
            // });
        }
    });

    $("#btnPositionRight").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x + oScalingValueForPosition, active_element.getAttribute('position').y, active_element.getAttribute('position').z);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x + oScalingValueForPosition, y: active_element.getAttribute('position').y, z: active_element.getAttribute('position').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x + oScalingValueForPosition, element.getAttribute('position').y, element.getAttribute('position').z);
            //     element.setAttribute('position', {x: element.getAttribute('position').x + oScalingValueForPosition, y: element.getAttribute('position').y, z: element.getAttribute('position').z});
            // });
        }
    });

    $("#btnPositionLeft").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x - oScalingValueForPosition, active_element.getAttribute('position').y, active_element.getAttribute('position').z);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x - oScalingValueForPosition, y: active_element.getAttribute('position').y, z: active_element.getAttribute('position').z});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x - oScalingValueForPosition, element.getAttribute('position').y, element.getAttribute('position').z);
            //     element.setAttribute('position', {x: element.getAttribute('position').x - oScalingValueForPosition, y: element.getAttribute('position').y, z: element.getAttribute('position').z});
            // });
        }
    });

    $("#btnPositionZBack").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x, active_element.getAttribute('position').y, active_element.getAttribute('position').z - oScalingValueForPosition);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x, y: active_element.getAttribute('position').y, z: active_element.getAttribute('position').z - oScalingValueForPosition});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x, element.getAttribute('position').y, element.getAttribute('position').z - oScalingValueForPosition);
            //     element.setAttribute('position', {x: element.getAttribute('position').x, y: element.getAttribute('position').y, z: element.getAttribute('position').z - oScalingValueForPosition});
            // });
        }
    });

    $("#btnPositionZFront").click(function() {
        var oScalingValueForPosition = parseFloat($("#txtScalingValueForPosition").val()) || .1;
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            //active_element.object3D.position.set(active_element.getAttribute('position').x, active_element.getAttribute('position').y, active_element.getAttribute('position').z + oScalingValueForPosition);
            active_element.setAttribute('position', {x: active_element.getAttribute('position').x, y: active_element.getAttribute('position').y, z: active_element.getAttribute('position').z + oScalingValueForPosition});

            // var abtn = document.querySelectorAll("[data-meta-parent-object-id='" + ACTIVE_ELEMENT + "']");
            // abtn.forEach(function(element) {
            //     //element.object3D.position.set(element.getAttribute('position').x, element.getAttribute('position').y, element.getAttribute('position').z + oScalingValueForPosition);
            //     element.setAttribute('position', {x: element.getAttribute('position').x, y: element.getAttribute('position').y, z: element.getAttribute('position').z + oScalingValueForPosition});
            // });
        }
    });

    $("#btnChangeText").click(function() {
        if (TYPE == "text" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            active_element.setAttribute('text', {
                value: $("#txtObjectText").val(),
            });
            FillObjectsList();
        }
    });

    $("#btnScaleUpObjectText").click(function() {
        var oScalingValueForFontSize = parseFloat($("#txtScalingValueForFontSize").val()) || 1;
        if (TYPE == "text" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            active_element.setAttribute('scale', {
                x: active_element.getAttribute('scale').x + oScalingValueForFontSize,
                y: active_element.getAttribute('scale').y + oScalingValueForFontSize
            });
        }
    });

    $("#btnChangeFont").click(function() {
        if (TYPE == "text" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            active_element.setAttribute('text', {
                font: $("#txtObjectTextFont").val(),
            });
        }
    });

    $("#txtObjectTextFontColor").change(function() {
        if (TYPE == "text" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            active_element.setAttribute('text', {
                color: $("#txtObjectTextFontColor").val(),
            });
        }
    });

    $("#btnScaleDownObjectText").click(function() {
        var oScalingValueForFontSize = parseFloat($("#txtScalingValueForFontSize").val()) || 1;
        if (TYPE == "text" || TYPE == "associated-text") {
            var active_element = document.getElementById(ACTIVE_ELEMENT);
            if (active_element.getAttribute('scale').x > 1) {
                active_element.setAttribute('scale', {
                    x: active_element.getAttribute('scale').x - oScalingValueForFontSize,
                    y: active_element.getAttribute('scale').y - oScalingValueForFontSize
                });
            }
        }
    });

    $("#btnDeleteObject").click(function() {
        if (TYPE == "artwork" || TYPE == "object" || TYPE == "text" || TYPE == "video" || TYPE == "associated-material" || TYPE == "associated-text") {
            document.getElementById(ACTIVE_ELEMENT).remove();
            ACTIVE_ELEMENT = "empty";
            TYPE = "none";
            $("#divSizeHandling").hide("slow");
            $("#divPositioning").hide("slow");
            $("#divTextHandling").hide("slow");
            $("#divDeleteObject").hide("slow");
            FillObjectsList();
            //updateDOM();
        }
    });
});