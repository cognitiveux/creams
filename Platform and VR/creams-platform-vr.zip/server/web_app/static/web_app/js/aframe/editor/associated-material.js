$(document).ready(function() {
    $("#btnAddAssociatedMediaPlaceholder").click(function() {
        if (TYPE == 'artwork' || TYPE == 'object') {
            let oArtwork = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-box');
            let INDEX_ID = getID(META_OBJECT_CLASS_IDENTIFIER);
            
            abox.classList.add(META_OBJECT_CLASS_IDENTIFIER);

            abox.id = "meta-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-parent-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'associated-material');
            
            abox.setAttribute('material', {
                color: "white"
            });
            abox.setAttribute('geometry', {
                width: 0.5,
                height: 0.5
            });
            abox.setAttribute('position', {
                x: 2.5,
                y: 2.5,
                z: 1.2
            });
            abox.setAttribute('scale', {
                x: 1,
                y: 1,
                z: 1
            });
            abox.setAttribute('setassociatedmaterialrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));

            //oArtwork.setAttribute('action_move', 'txt:' + ACTIVE_ELEMENT);

            oArtwork.parentElement.appendChild(abox);
            //updateDOM();
            toastr.info("Placeholder has been associated to the artwork. Go to the Artworks or Videos tab to assign the relevant material");
        }
        else {
            toastr.warning("Please select an artwork to add any associated media");
        }
    });

    $("#btnAddAssociatedTextPlaceholder").click(function() {
        if (TYPE == 'artwork' || TYPE == 'object') {
            let oArtwork = document.getElementById(ACTIVE_ELEMENT);
            let alabel = document.createElement('a-entity');
            let INDEX_ID = getID(META_TEXT_OBJECT_CLASS_IDENTIFIER);

            alabel.classList.add(TEXT_OBJECT_CLASS_IDENTIFIER);
            alabel.setAttribute('type', 'associated-text');
            alabel.setAttribute('data-parent', ACTIVE_ELEMENT);
            alabel.setAttribute('data-id', INDEX_ID);
            alabel.classList.add(ACTIVE_ELEMENT);
            alabel.classList.add(META_OBJECT_CLASS_IDENTIFIER);
            alabel.classList.add(META_TEXT_OBJECT_CLASS_IDENTIFIER);
            alabel.id = ACTIVE_ELEMENT + "-meta-label-" + INDEX_ID;
            alabel.setAttribute('scale', "1.5 1.5 1");
            alabel.setAttribute('position', {
                x: 2.5,
                y: 2.5,
                z: 1.3
            });
            alabel.setAttribute('text', {
                color: '#FFFFFF',
                value: "Insert Meta Text"
            });

            alabel.setAttribute('setassociatedtextrules', 'txt:' + alabel.getAttribute('id'));
            oArtwork.setAttribute('action_move', 'txt:' + ACTIVE_ELEMENT);

            // let plane = document.createElement('a-plane');
            // plane.setAttribute('color', 'red');
            // plane.setAttribute('height', '0.3');

            // alabel.appendChild(plane);
            oArtwork.parentElement.appendChild(alabel);
            //updateDOM();
            toastr.info("Associated text created. Go to the Adjustments tab to make visual changes on the textual element");
        }
        else {
            toastr.warning("Please select an artwork to add any associated text");
        }
    });
});

function FillObjectsListForAssociatedMaterial() {
    $("#lstObjectsForAssociatedMaterial").empty();
    $.each($("." + ARTWORK_CLASS_IDENTIFIER), function() {
        let artwork_name = this.getAttribute("data-artwork-name");
        $("#lstObjectsForAssociatedMaterial").append($("<option />").val(this.id).text(artwork_name + " (" + this.id + ")"));
    });
    $.each($("." + THREE_D_OBJECT_CLASS_IDENTIFIER), function() {
        let artwork_name = this.getAttribute("data-artwork-name");
        $("#lstObjectsForAssociatedMaterial").append($("<option />").val(this.id).text(artwork_name + " (" + this.id + ")"));
    });
    $.each($("." + TEXT_OBJECT_CLASS_IDENTIFIER), function() {
        let text_short = this.getAttribute("data-text-short");
        $("#lstObjects").append($("<option />").val(this.id).text(text_short + " (" + this.id + ")"));
    });
    $.each($("." + VIDEO_OBJECT_CLASS_IDENTIFIER), function() {
        let video_name = this.getAttribute("data-video-name");
        $("#lstObjectsForAssociatedMaterial").append($("<option />").val(this.id).text(video_name + " (" + this.id + ")"));
    });
    $("#lstObjectsForAssociatedMaterial").val(ACTIVE_ELEMENT);
}

function SelectObjectForAssociatedMaterial() {
    $("#lstObjectsForAssociatedMaterial").val(ACTIVE_ELEMENT);
}