/**
 * Script Name: asset_management.js
 * Purpose: Handle assets. Check which artworks are used and show assets on front-end.
 * Author: Michail-Panagiotis Bofos
 * Contact: mbofos@outlook.com
 */

/**
 * List of active assets.
 */
var ACTIVE_ASSETS = [];
/**
 * Get asset list from DOM.
 */
var assetlist = document.getElementsByTagName('a-assets')[0];

/**
 * This function filters all artworks in the asset list to get the artworks inserted by the user.
 * 
 * @param {*} includeAll : Boolean flag that allows all assets to be selected
 * @returns List of Assets (IDs)
 */
function fetchActiveAssets(includeAll) {
    ACTIVE_ASSETS = [];
    for (let i = 0; i < assetlist.children.length; i++) {
        if (includeAll || assetlist.children[i].getAttribute('type') === 'artwork'){
            ACTIVE_ASSETS.push(assetlist.children[i].id);
            //console.log(assetlist.children[i].id);
        }
    }
    return ACTIVE_ASSETS;
}

/**
 * This function adds an artwork on the asset list (a-assets).
 * 
 * @param {*} artwork : JSON item
 */
function insertArtwork(artwork) {
    let nname = "User";
    var asset = document.createElement('img');
    asset.setAttribute('id', artwork['id']);
    asset.setAttribute('src', '/media/' + artwork['src']);
    asset.setAttribute('type', "artwork");
    asset.setAttribute('name', artwork['name']);
    asset.setAttribute('data-height', artwork['height'] * 100);
    asset.setAttribute('data-width', artwork['width'] * 100);
    asset.setAttribute('creator', nname + " " + surname);
    asset.setAttribute('descr', artwork['technique'] + ' ' + artwork['genre']);
    assetlist.appendChild(asset);
}

/**
 * This function get all the assets in the asset list and depending on their type adds them
 * on the front end scrollable list.
 */
function fillScrollableWithAssets() {
    var len = assetlist.children.length;
    for (let i = 0; i < len; i++) {
        var as = assetlist.children[i];
        if (as['attributes']['type']['value'] === 'artwork' || as['attributes']['type']['value'] === 'texture') {
            var div0 = document.createElement('div');
            div0.classList.add('mh-375px', 'scroll-y', 'me-n7', 'pe-7');
            var div1 = document.createElement('div');
            div1.classList.add('border', 'border-hover-primary', 'p-7', 'rounded', 'mb-7');
            var div2 = document.createElement('div');
            div2.classList.add('d-flex', 'flex-stack', 'pb-3');
            var div3 = document.createElement('div');
            div3.classList.add('d-flex');
            var div4 = document.createElement('div');
            div4.classList.add('symbol', 'symbol-150px');

            var am1 = document.createElement('a');
            am1.classList.add('d-block', 'overlay', 'h-100');
            am1.setAttribute('data-fslightbox', 'lightbox-hot-sales');
            am1.setAttribute('href', as.src);

            var div_extra = document.createElement('div');
            div_extra.classList.add('overlay-wrapper');
            div_extra.classList.add('bgi-no-repeat');
            div_extra.classList.add('bgi-position-center');
            div_extra.classList.add('bgi-size-cover');
            div_extra.classList.add('card-rounded');
            div_extra.classList.add('min-h-200px');
            div_extra.classList.add('h-100');

            var img0 = document.createElement('img');
            img0.classList.add('carou-pics');
            img0.setAttribute('id', 'as' + i);
            img0.setAttribute('src', as.src);

            div_extra.appendChild(img0);
            am1.appendChild(div_extra);

            var divm1 = document.createElement('div');
            divm1.classList.add('overlay-layer', 'card-rounded', 'bg-dark', 'bg-opacity-25');
            var i0 = document.createElement('i');
            i0.classList.add('bi', 'bi-eye-fill', 'fs-2x', 'text-white');
            divm1.appendChild(i0);
            am1.appendChild(divm1);

            div4.appendChild(am1);
            var div5 = document.createElement('div');
            div5.classList.add('ms-5');

            var div6 = document.createElement('div');
            div6.classList.add('d-flex', 'align-items-center');
            var p0 = document.createElement('p');
            p0.classList.add('text-dark', 'fw-bold', 'text-hover-primary', 'fs-5', 'me-4');
            p0.textContent = as.getAttribute('name');
            div6.appendChild(p0);

            var span0 = document.createElement('span');
            span0.classList.add('text-muted', 'fw-semibold', 'mb-3');
            span0.textContent = as.getAttribute('creator');
            div5.appendChild(div6);
            div5.appendChild(span0);

            div3.appendChild(div4);
            div3.appendChild(div5);
            div2.appendChild(div3);
            div1.appendChild(div2);

            var div7 = document.createElement('div');
            div7.classList.add('p-0');
            var div8 = document.createElement('div');
            div8.classList.add('d-flex', 'flex-column');

            var p1 = document.createElement('p');
            p1.classList.add('text-gray-700', 'fw-semibold', 'fs-6', 'mb-4');
            p1.textContent = as.getAttribute('descr');
            div8.appendChild(p1);

            var a0 = document.createElement('a');
            a0.classList.add('btn', 'btn-sm', 'btn-primary');
            a0.setAttribute('param1', as.id);
            a0.setAttribute('param2', as.getAttribute('data-width'));
            a0.setAttribute('param3', as.getAttribute('data-height'));
            as.getAttribute('type') === 'artwork'
            if (as.getAttribute('type') === 'artwork')
                a0.setAttribute('onclick', 'assignArtwork(this)');
            else if (as.getAttribute('type') === 'texture')
                a0.setAttribute('onclick', 'assignWallTexture(this)');
            a0.textContent = 'Select';
            div8.appendChild(a0);
            div7.appendChild(div8);

            div1.appendChild(div7);

            div0.appendChild(div1);

            if (as.getAttribute('type') === 'artwork' && img0.src !== '') {
                document.getElementById('lstArtworks').appendChild(div0);
            } else if (as.getAttribute('type') === 'texture' && img0.id !== 'as24') {
                //console.log(img0);
                document.getElementById('tab-panel-walls').appendChild(div0);
            }
        }
    }
}


/**
 * This function returns a list of the artworks that are used in a box or a meta-box in the VR.
 * @returns List of assets (IDs)
 */
function getUsedArtworks() {
    let used_artworks = [];
    let boxes = document.getElementsByTagName('a-box');
    for (let i = 0; i < boxes.length; i++)
        if (boxes[i].getAttribute('type') === 'artwork' || boxes[i].getAttribute('type') === 'meta')
            if (boxes[i].getAttribute('data-artwork') !== null)
                used_artworks.push(boxes[i].getAttribute('data-artwork').toString());

    return used_artworks;
}

/**
 * This function deletes DOM artworks from the asset list. (Used on system.js)
 */
function removeUnusedArtworksFromAssetList() {
    let used = getUsedArtworks();
    let all = fetchActiveAssets(false);

    let to_delete = all.filter(function (obj) {
        return used.indexOf(obj) == -1;
    });

    for (let i = 0; i < to_delete.length; i++) {
        document.getElementById(to_delete[i]).remove();
    }

}

/**
 * This function updates the list of IndoorArtworks (model) on the database. (Used on system.js)
 * 
 * @param {*} vr_exhibition_id : Foreign key, primary key (id) of the vr_exhibitoon
 */
function syncArtworks(vr_exhibition_id) {
    var artworks = getUsedArtworks();
    var xhr3 = new XMLHttpRequest();
    // Setup our listener to process completed requests
    xhr3.onreadystatechange = function () {
        // Only run if the request is complete
        if (xhr3.readyState !== 4) return;
        // Process our return data
        if (xhr3.status >= 200 && xhr3.status < 300) {
            // What to do when the request is successful

        } else {
            console.log('error', xhr3);
        }
    };
    const json = {
        assignment: vr_exhibition_id,
        artworks: artworks
    }
    xhr3.open('POST', '/web_app/artworks/indoor/assign/', false);

    // set `Content-Type` header
    xhr3.setRequestHeader('Content-Type', 'application/json')

    // send rquest with JSON payload
    xhr3.send(JSON.stringify(json))


}


/**
 * Fetch artworks of the student and place them in the asset element
 * 
 */
var xhr3 = new XMLHttpRequest();
// Setup our listener to process completed requests
xhr3.onreadystatechange = function () {
    // Only run if the request is complete
    if (xhr3.readyState !== 4) return;
    // Process our return data
    if (xhr3.status >= 200 && xhr3.status < 300) {
        fetchActiveAssets(true);
        // What to do when the request is successful
        var response = JSON.parse(xhr3.responseText)['resource_obj']['artworks'];
        for (let i = 0; i < response.length; i++) {
            //if (ACTIVE_ASSETS.includes(response[i]['id'].toString()) === false)
            //    insertArtwork(response[i]);
        }
        //fillScrollableWithAssets();

    } else {
        console.log('error', xhr3);
    }
};
xhr3.open('GET', '/web_app/artworks/student_list', false);
xhr3.send();