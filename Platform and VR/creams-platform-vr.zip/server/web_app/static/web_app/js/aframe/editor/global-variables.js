const ARTWORK_CLASS_IDENTIFIER = "artwork_box";
const THREE_D_OBJECT_CLASS_IDENTIFIER = "three_dim";
const TEXT_OBJECT_CLASS_IDENTIFIER = "text";
const VIDEO_OBJECT_CLASS_IDENTIFIER = "video";
const SPOT_LIGHT_OBJECT_CLASS_IDENTIFIER = "spot_lights";
const META_OBJECT_CLASS_IDENTIFIER = "meta_artifact";
const META_TEXT_OBJECT_CLASS_IDENTIFIER = "meta_captions";
const META_BUTTON_CLASS_IDENTIFIER = "meta_button";

const AUDIO_CLASS_IDENTIFIER = "audio_element";

var SELECTED_TAB = "room";
var ACTIVE_ELEMENT = "empty";
var TYPE = "none";
var IsVideoPlaying = false;

function SetSelectedTab(SelectedTab) {
    SELECTED_TAB = SelectedTab;
}