AFRAME.registerComponent('setwallrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        if (el.getAttribute('visible')){
            el.addEventListener('click', function () {
                if (data.txt != "null") {
                    if (
                        (SELECTED_TAB == "artworks" && !document.getElementById("chkArtworkAsMeta").checked) ||
                        (SELECTED_TAB == "labels" && !document.getElementById("chkLabelAsMeta").checked) ||
                        (SELECTED_TAB == "videos" && !document.getElementById("chkVideoAsMeta").checked) ||
                        (SELECTED_TAB == "spotlights")
                        ) {
                        ACTIVE_ELEMENT = data.txt;
                        TYPE = 'wall';
                        SelectObject();
                        $("#lblSelectedWall").html("<strong>Selected wall:</strong> " + ACTIVE_ELEMENT);
                        //$("#lblSelectedElement").html("<strong>Selected element:</strong> none");
                        toastr.info("Selected Wall - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                    }
                }
            });
        }
    }
});

AFRAME.registerComponent('setartworkrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if ((SELECTED_TAB == "artworks" && document.getElementById("chkArtworkAsMeta").checked) ||
                    (SELECTED_TAB == "labels" && document.getElementById("chkLabelAsMeta").checked) ||
                    (SELECTED_TAB == "videos" && document.getElementById("chkVideoAsMeta").checked) ||
                    SELECTED_TAB == "adjustments") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'artwork';
                    SelectObject();
                    $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                    //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                    toastr.info("Selected Artwork - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                }
                else if (SELECTED_TAB == "user-mode") {
                    var abtn = $("[data-parent-id='" + data.txt + "']");
                    abtn.each(function() {
                        if ($(this).attr("visible")) {
                            $(this).attr("visible", false);
                        }
                        else {
                            $(this).attr("visible", true);
                        }
                    });
                }
            }
        });
    }
});

AFRAME.registerComponent('setthreedrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if ((SELECTED_TAB == "artworks" && document.getElementById("chkArtworkAsMeta").checked) ||
                    (SELECTED_TAB == "labels" && document.getElementById("chkLabelAsMeta").checked) ||
                    (SELECTED_TAB == "videos" && document.getElementById("chkVideoAsMeta").checked) ||
                    SELECTED_TAB == "adjustments") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'object';
                    SelectObject();
                    $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                    //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                    toastr.info("Selected Artwork - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                }
                else if (SELECTED_TAB == "user-mode") {
                    var abtn = $("[data-parent-id='" + data.txt + "']");
                    abtn.each(function() {
                        if ($(this).attr("visible")) {
                            $(this).attr("visible", false);
                        }
                        else {
                            $(this).attr("visible", true);
                        }
                    });
                }
            }
        });
    }
});

AFRAME.registerComponent('setlabelrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if (SELECTED_TAB == "adjustments") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'text';
                    SelectObject();
                    $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                    //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                    toastr.info("Selected Text - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                }
            }
        });
    }
});

AFRAME.registerComponent('setvideorules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if ((SELECTED_TAB == "artworks" && document.getElementById("chkArtworkAsMeta").checked) ||
                    (SELECTED_TAB == "labels" && document.getElementById("chkLabelAsMeta").checked) ||
                    (SELECTED_TAB == "videos" && document.getElementById("chkVideoAsMeta").checked) ||    
                    SELECTED_TAB == "adjustments" || SELECTED_TAB == "user-mode") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'video';

                    if (SELECTED_TAB == "user-mode") {
                        var video_id = document.getElementById(ACTIVE_ELEMENT).getAttribute('data-video-id');
                        var active_element = document.getElementById("video-" + video_id);
                        IsVideoPlaying ? active_element.pause() : active_element.play();
                        IsVideoPlaying = !IsVideoPlaying;
                    }
                    else {
                        $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                        //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                        toastr.info("Selected Video - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                        
                        SelectObject();
                    }
                }
            }
        });
    }
});

AFRAME.registerComponent('setassociatedmaterialrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if (SELECTED_TAB == "adjustments" || SELECTED_TAB == "user-mode") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'associated-material';
                    if (SELECTED_TAB == "user-mode") {
                        var video_id = document.getElementById(ACTIVE_ELEMENT).getAttribute('data-video-id');
                        var active_element = document.getElementById("video-" + video_id);
                        IsVideoPlaying ? active_element.pause() : active_element.play();
                        IsVideoPlaying = !IsVideoPlaying;
                    }
                    else {
                        SelectObject();
                        $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                        //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                        toastr.info("Selected Associated Material - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                    }
                }
            }
        });
    }
});

AFRAME.registerComponent('setassociatedtextrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                if (SELECTED_TAB == "adjustments") {
                    ACTIVE_ELEMENT = data.txt;
                    TYPE = 'associated-text';
                    SelectObject();
                    $("#lblSelectedWall").html("<strong>Selected wall:</strong> none");
                    //$("#lblSelectedElement").html("<strong>Selected element:</strong> " + ACTIVE_ELEMENT);
                    toastr.info("Selected Associated Text - Active: " + ACTIVE_ELEMENT + " - Type: " + TYPE);
                }
            }
        });
    }
});

AFRAME.registerComponent('setbuttonrules', {
    schema: {
        txt: {
            default: 'default'
        }
    },
    init: function () {
        var data = this.data;
        var el = this.el;
        el.addEventListener('click', function () {
            if (data.txt != "null") {
                var abtn = $("[data-parent-id='" + data.txt + "']");
                abtn.each(function() {
                    if ($(this).attr("visible")) {
                        $(this).attr("visible", false);
                    }
                    else {
                        $(this).attr("visible", true);
                    }
                });
            }
        });
    }
});
