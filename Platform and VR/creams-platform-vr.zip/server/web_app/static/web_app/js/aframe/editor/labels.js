$(document).ready(function() {
    $("#btnAddLabel").click(function() {
        if(TYPE == 'artwork' && document.getElementById("chkLabelAsMeta").checked){
            var oLabel = document.getElementById("txtLabel").value;
            if(oLabel == "") oLabel = "Meta Label Text";

            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-entity');
            let INDEX_ID = getID(META_TEXT_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(META_TEXT_OBJECT_CLASS_IDENTIFIER);

            abox.id = "label-meta-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-parent-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'associated-text');

            abox.setAttribute('setassociatedtextrules', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            abox.setAttribute("data-text-full", oLabel);
            abox.setAttribute("data-text-short", oLabel.substring(0, 10));
            abox.setAttribute("data-meta-name", oLabel.substring(0, 10));

            abox.setAttribute('position', {
                x: 2.5,
                y: 2.5,
                z: 1.2
            });
            abox.setAttribute('scale', {
                x: 1.5,
                y: 1.5,
                z: 1
            });
            abox.setAttribute('text', {
                color: '#ffffff',
                value: oLabel
            });

            oWall.parentElement.appendChild(abox);
            //updateDOM();
            toastr.info("Associated the label.");
            FillObjectsList();
        }
        else if(TYPE == 'wall' && !document.getElementById("chkLabelAsMeta").checked) {
            if (ACTIVE_ELEMENT.includes("ceiling")) {
                console.warn("Wrong type of wall");
                return;
            }
            var oLabel = document.getElementById("txtLabel").value;
            if(oLabel == "") oLabel = "Label Text";

            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement('a-entity');
            let INDEX_ID = getID(TEXT_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(TEXT_OBJECT_CLASS_IDENTIFIER);

            abox.id = "label-" + INDEX_ID;
            abox.setAttribute('data-increment-id', INDEX_ID);
            abox.setAttribute('data-wall-id', ACTIVE_ELEMENT);
            abox.setAttribute('depth', '0.2');
            abox.setAttribute('type', 'text');

            abox.setAttribute('setlabelrules', 'txt:' + abox.getAttribute('id'));
            //abox.setAttribute('clickhandler', 'txt:' + abox.getAttribute('id'));
            //abox.setAttribute("data-artwork-id", $(this).data("artwork-id"));
            abox.setAttribute("data-text-full", oLabel);
            abox.setAttribute("data-text-short", oLabel.substring(0, 10));

            abox.setAttribute('position', {
                x: 2.75,
                y: 3,
                z: 0.02
            });
            abox.setAttribute('scale', {
                x: 3,
                y: 3,
                z: 1
            });
            abox.setAttribute('text', {
                color: '#ffffff',
                value: oLabel
            });

            oWall.appendChild(abox);
            //updateDOM();
            toastr.info("Added label on wall.");
            FillObjectsList();
        }
        else {
            toastr.warning("Please select a wall to assign a label or select an existing label and associate material on it.");
        }
    });
});