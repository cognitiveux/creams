var oSelectedSpotlightID = null;

$(document).ready(function() {
    $("#btnAddSpotlight").click(function(){
        if(TYPE == "wall"){
            if (ACTIVE_ELEMENT.includes("ceiling")) {
                console.warn("Wrong type of wall");
                return;
            }
            let oWall = document.getElementById(ACTIVE_ELEMENT);
            let abox = document.createElement("a-entity");
            let INDEX_ID = getID(SPOT_LIGHT_OBJECT_CLASS_IDENTIFIER);
            abox.classList.add(SPOT_LIGHT_OBJECT_CLASS_IDENTIFIER);
            abox.id = "spotlight-" + INDEX_ID;
            abox.setAttribute("data-increment-id", INDEX_ID);
            abox.setAttribute("data-wall-id", ACTIVE_ELEMENT);
            abox.setAttribute("data-spotlight-name", "spotlight-" + INDEX_ID);
            abox.setAttribute("position", {
                x: 2.5,
                y: 2.46,
                z: 3
            });
            abox.setAttribute("rotation", {
                x: 0,
                y: 0,
                z: 0
            });
            abox.setAttribute("light", {
                type: "spot",
                color: "#FFFFFF",
                castShadow: true,
                intensity: 0.5,
                angle: 34,
                // shadowCameraVisible: true,
            });
            //SPOT_LIGHTS.push(abox);
            abox.setAttribute("setlabelrules", "txt:" + abox.getAttribute("id"));
            oWall.appendChild(abox);
            // setTimeout(function(){
            //     fixLight();
            // }, 20);
            //abox.flushToDOM(true);
            toastr.info("Added spotlight on wall");
            
            oSelectedSpotlightID = abox.id;
            setTimeout(function(){
                FillSpotlightsList();
            }, 20);
            //$("#divSpotlightTools").show("slow");
            //$("#divDeleteSpotlight").show("slow");
        }
        else {
            toastr.warning("Please select a wall to add a spotlight");
        }
    });

    $("#lstSpotlights").change(function() {
        oSelectedSpotlightID = $(this).find(":selected").val();
        if (oSelectedSpotlightID) {
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            $("#txtSpotlightColor")[0].jscolor.fromString(active_spotlight.getAttribute("light").color);
            $("#rngSpotlightIntensity").val(active_spotlight.getAttribute("light").intensity * 100.0);
            $("#rngSpotlightAngle").val(active_spotlight.getAttribute("light").angle);
            $("#rngSpotlightPenumbra").val(active_spotlight.getAttribute("light").penumbra * 100.0);

            $("#divSpotlightTools").show("slow");
            $("#divDeleteSpotlight").show("slow");
        }
    });

    $("#txtSpotlightColor").change(function() {
        if (oSelectedSpotlightID) {
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("light", {
                color: $("#txtSpotlightColor").val(),
            });
        }
    });

    $("#rngSpotlightIntensity").change(function() {
        if (oSelectedSpotlightID) {
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("light", {
                intensity: $("#rngSpotlightIntensity").val() / 100.0,
            });
        }
    });

    $("#rngSpotlightAngle").change(function() {
        if (oSelectedSpotlightID) {
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("light", {
                angle: $("#rngSpotlightAngle").val(),
            });
        }
    });

    $("#rngSpotlightPenumbra").change(function() {
        if (oSelectedSpotlightID) {
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("light", {
                penumbra: $("#rngSpotlightPenumbra").val() / 100.0,
            });
        }
    });

    $("#btnSpotlightRotateUp").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForRotation = parseFloat($("#txtSpotlightScalingValueForRotation").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("rotation", {x: active_spotlight.getAttribute("rotation").x + oSpotlightScalingValueForRotation, y: active_spotlight.getAttribute("rotation").y, z: active_spotlight.getAttribute("rotation").z});
        }
    });

    $("#btnSpotlightRotateDown").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForRotation = parseFloat($("#txtSpotlightScalingValueForRotation").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("rotation", {x: active_spotlight.getAttribute("rotation").x - oSpotlightScalingValueForRotation, y: active_spotlight.getAttribute("rotation").y, z: active_spotlight.getAttribute("rotation").z});
        }
    });

    $("#btnSpotlightRotateRight").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForRotation = parseFloat($("#txtSpotlightScalingValueForRotation").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("rotation", {x: active_spotlight.getAttribute("rotation").x, y: active_spotlight.getAttribute("rotation").y - oSpotlightScalingValueForRotation, z: active_spotlight.getAttribute("rotation").z});
        }
    });

    $("#btnSpotlightRotateLeft").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForRotation = parseFloat($("#txtSpotlightScalingValueForRotation").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("rotation", {x: active_spotlight.getAttribute("rotation").x, y: active_spotlight.getAttribute("rotation").y + oSpotlightScalingValueForRotation, z: active_spotlight.getAttribute("rotation").z});
        }
    });

    $("#btnSpotlightPositionUp").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForPosition = parseFloat($("#txtSpotlightScalingValueForPosition").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("position", {x: active_spotlight.getAttribute("position").x, y: active_spotlight.getAttribute("position").y + oSpotlightScalingValueForPosition, z: active_spotlight.getAttribute("position").z});
        }
    });

    $("#btnSpotlightPositionDown").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForPosition = parseFloat($("#txtSpotlightScalingValueForPosition").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("position", {x: active_spotlight.getAttribute("position").x, y: active_spotlight.getAttribute("position").y - oSpotlightScalingValueForPosition, z: active_spotlight.getAttribute("position").z});
        }
    });

    $("#btnSpotlightPositionRight").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForPosition = parseFloat($("#txtSpotlightScalingValueForPosition").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("position", {x: active_spotlight.getAttribute("position").x + oSpotlightScalingValueForPosition, y: active_spotlight.getAttribute("position").y, z: active_spotlight.getAttribute("position").z});
        }
    });

    $("#btnSpotlightPositionLeft").click(function() {
        if (oSelectedSpotlightID) {
            var oSpotlightScalingValueForPosition = parseFloat($("#txtSpotlightScalingValueForPosition").val()) || .1;   
            var active_spotlight = document.getElementById(oSelectedSpotlightID);
            active_spotlight.setAttribute("position", {x: active_spotlight.getAttribute("position").x - oSpotlightScalingValueForPosition, y: active_spotlight.getAttribute("position").y, z: active_spotlight.getAttribute("position").z});
        }
    });

    $("#btnDeleteSpotlight").click(function() {
        if (oSelectedSpotlightID) {
            document.getElementById(oSelectedSpotlightID).remove();
            oSelectedSpotlightID = null;
            $("#divSpotlightTools").hide("slow");
            $("#divDeleteSpotlight").hide("slow");
            FillSpotlightsList();
            //updateDOM();
        }
    });
});

function FillSpotlightsList() {
    $("#lstSpotlights").empty();
    //$("#lstSpotlights").append($("<option />").text(""));
    $.each($("." + SPOT_LIGHT_OBJECT_CLASS_IDENTIFIER), function() {
        let spotlight_name = this.getAttribute("data-spotlight-name");
        let wall_id = this.getAttribute("data-wall-id");
        $("#lstSpotlights").append($("<option />").val(this.id).text(spotlight_name + " (wall: " + wall_id + ")"));
    });
    $("#lstSpotlights").val(oSelectedSpotlightID);
    $("#lstSpotlights")[0].dispatchEvent(new Event("change"));
}