function shareOnFacebook(ASSET_TO_SHARE) {
    const navUrl = 'https://www.facebook.com/sharer/sharer.php?u=' + ASSET_TO_SHARE;
    window.open(navUrl, '_blank');
}


function shareOnTwitter(ASSET_TO_SHARE) {
    const navUrl =
        'https://twitter.com/intent/tweet?text=' + ASSET_TO_SHARE;
    window.open(navUrl, '_blank');
}