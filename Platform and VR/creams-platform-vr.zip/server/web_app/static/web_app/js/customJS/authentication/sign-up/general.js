"use strict";

function de_list_python(list) {
    let words = [];
    let word = [];
    let flag = false;
    for (let i = 0; i < list.length; i++) {
        if (list[i] === ';') {
            flag = true;
            continue;
        } else if (flag && list[i] === '&') {
            flag = false;
            if (word.join("") !== " ")
                words.push(word.join(""));
            word = [];
            continue;
        }
        if (flag && list[i] !== ',') {
            word.push(list[i]);
        }
    }
    return words;
}

let real_list_roles = de_list_python(roles);
let rolelist = document.getElementById('el_role');
let real_list_st = de_list_python(student_choices);
let real_list_te = de_list_python(teacher_choices);
let real_list_org = de_list_python(organizations);
let orglist = document.getElementById('el_organization');

for (let rl in real_list_roles) {
    let opt = document.createElement('option');
    opt.value = real_list_roles[rl];
    opt.textContent = real_list_roles[rl];
    //if (real_list_roles[rl] !== 'INSTRUCTOR')
    rolelist.appendChild(opt);
}

let classlist = document.getElementById('el_class');
for (let rl in real_list_te) {
    let opt = document.createElement('option');
    opt.value = real_list_te[rl];
    opt.textContent = real_list_te[rl];
    classlist.appendChild(opt);
}

for (let rl in real_list_org) {
    let opt = document.createElement('option');
    opt.value = real_list_org[rl];
    opt.textContent = real_list_org[rl];
    orglist.appendChild(opt);

}

function onInput(input, list) {
    let selection = input.value;
    if (selection === 'INSTRUCTOR') {
        $('#el_class').show(500);
        $('#el_organization').show(500);
        list.innerHTML = '';
        let rolelist = document.getElementById('el_class');
        // document.getElementById('class').placeholder = "Select instructor position";
        for (let rl in real_list_te) {
            let opt = document.createElement('option');
            opt.value = real_list_te[rl];
            opt.textContent = real_list_te[rl];
            rolelist.appendChild(opt);
        }
    } else if (selection === 'STUDENT') {
        $('#el_class').show(500);
        $('#el_organization').show(500);
        list.innerHTML = '';
        let rolelist = document.getElementById('el_class');
        // document.getElementById('class').placeholder = "Select class";
        for (let rl in real_list_st) {
            let opt = document.createElement('option');
            opt.value = real_list_st[rl];
            opt.textContent = real_list_st[rl];
            rolelist.appendChild(opt);
        }
    } else if (selection === 'ARTIST') {
        list.innerHTML = '';
        $('#el_class').hide(500);
        $('#el_organization').hide(500);
    } else {
        list.innerHTML = '';
        document.getElementById('el_class').placeholder = "Select role first";
    }
}

var btnSubmitID = $("#signup_submit");

var signup = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();

            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    let email = $("#el_email").val();
                    let password = $("#el_password").val();
                    let first = $("#el_firstname").val();
                    let last = $("#el_lastname").val();
                    let role = $("#el_role").val();
                    let org = $("#el_organization").val();
                    let _class = $("#el_class").val();

                    btnSubmitID.disabled = true;
                    var xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            btnSubmitID.disabled = false;
                            window.location.href = "/web_app/verify-account/";

                        } else {
                            btnSubmitID.disabled = false;
                            var response = JSON.parse(xhr.responseText);
                            if (response['already_exists_fields'].includes("email")) {
                                Swal.fire({
                                    text: "This email is already in use. Please try a different one.",
                                    icon: "error",
                                    buttonsStyling: false,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });

                            } else {
                                Swal.fire({
                                    text: "Something went wrong, please try again.",
                                    icon: "error",
                                    buttonsStyling: false,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });
                            }
                        }
                    };
                    xhr.open('POST', '/web_app/account-mgmt/create-user', true);
                    let formData = new FormData();
                    formData.append("email", email);
                    formData.append("password", password); 
                    formData.append("name", first); 
                    formData.append("surname", last); 
                    formData.append("role", role); 
                    if (role === "ARTIST") {
                        formData.append("organization", "CUX"); 
                        formData.append("class_level", "ARTIST"); 
                    } else {
                        formData.append("organization", org); 
                        formData.append("class_level", _class); 
                    }
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();