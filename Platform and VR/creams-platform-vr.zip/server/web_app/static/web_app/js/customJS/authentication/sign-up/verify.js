"use strict";

var btnSubmitID = $("#verify_submit");

var verify = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();

            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    let email = $("#el_email").val();
                    let verification_code = $("#el_verification_code").val();

                    btnSubmitID.disabled = true;
                    var xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            btnSubmitID.disabled = false;
                            let is_activated = response['resource_is_activated'];
                            if (is_activated) {
                                Swal.fire({
                                    text: "Your email and account have been verified.",
                                    icon: "success",
                                    buttonsStyling: false,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });
                                setTimeout(function () {
                                    window.location.href = "/web_app/login/";
                                }, 2000);
                            } else {
                                swal.fire({
                                    text: "Please enter valid activation code and try again.",
                                    icon: "error",
                                    buttonsStyling: false,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });
                            }
                        } else {
                            btnSubmitID.disabled = false;
                            Swal.fire({
                                text: "Please enter valid activation code and try again.",
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }
                    };
                    xhr.open('POST', '/web_app/account-mgmt/activate-account', true);
                    let formData = new FormData();
                    formData.append("email", email);
                    formData.append("verification_code", verification_code); 
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();