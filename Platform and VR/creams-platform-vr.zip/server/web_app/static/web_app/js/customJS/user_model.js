"use strict";

var frmID = document.getElementById('update_user_model_form');
var btnSubmitID = $("#update_user_model_submit");

var user_model_init = function () {
    var initElements = function () {

    }

    return {
        init: function () {
            initElements();
        }
    };
}();


var user_model_update = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {
                if (xhr.readyState !== 4) return;
                if (xhr.status >= 200 && xhr.status < 300) {
                    var response = JSON.parse(xhr.responseText);
                    Swal.fire({
                        text: "Form has been successfully submitted!",
                        icon: "success",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        }
                    });
                } else {
                    Swal.fire({
                        text: "Sorry, looks like there are some errors detected, please try again.",
                        icon: "error",
                        buttonsStyling: false,
                        confirmButtonText: "Ok, got it!",
                        customClass: {
                            confirmButton: "btn btn-primary"
                        }
                    });
                }
            });
            xhr.open("POST", "/web_app/user_model/update", true);
            let formData = new FormData();
            formData.append("art_terms", $("#ddlArtTerms").val());
            formData.append("spatial_context_terms", $("#ddlSpatialContextTerms").val());
            xhr.send(formData);
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();