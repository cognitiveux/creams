const students = document.getElementById("student_table");
const instructors = document.getElementById("instructor_table");
const submitButton = document.getElementById("select_student_coadvisors_submit");
let selected_studs = [];
let selected_instr = [];

function submit() {
    submitButton.disabled = true;
    selected_studs = [];
    for (var i = 0; i < students.childElementCount; i++) {
        var student = students.children[i];
        // EXTRA CAUTION WHEN CHANGING THE TABLE LAYOUT
        if (existing_student_list.includes(parseInt(student.id))) {
            if (student.children[0].children[0].checked === false) {
                deleteStudentConnection(student.id, exh_id);
            }
        } else {
            if (student.children[0].children[0].checked) {
                selected_studs.push(student.id);
                postStudentConnection(student.id, exh_id);
            }
        }
    }
    selected_instr = [];
    for (var i = 0; i < instructors.childElementCount; i++) {
        var instructor = instructors.children[i];
        // EXTRA CAUTION WHEN CHANGING THE TABLE LAYOUT
        if (existing_instructor_list.includes(parseInt(instructor.id))) {
            if (instructor.children[0].children[0].checked === false) {
                deleteAdvisorConnection(instructor.id, exh_id);
            }
        } else {
            if (instructor.children[0].children[0].checked) {
                selected_instr.push(instructor.id);
                postAdvisorConnection(instructor.id, exh_id);
            }
        }
    }

    submitButton.disabled = false;

    let success_message;

    if (EDIT) {
        success_message = "Student & Co-Advisor list updated!";
    } else {
        success_message = "Students & Co-Advisors registered!";
    }

    Swal.fire({
        text: success_message,
        icon: "success",
        buttonsStyling: false,
        timer: 2000,
        confirmButtonText: "Ok, got it!",
        customClass: {
            confirmButton: "btn btn-primary"
        }
    }).then(function (result) {
        if (EDIT) {
            window.location.href = "/web_app/teacher/exhibition/view/?id=" + exh_id;
        } else {
            window.location.href = "/web_app/teacher/dashboard/";
        }
        if (result.isConfirmed) {
            if (EDIT) {
                window.location.href = "/web_app/teacher/exhibition/view/?id=" + exh_id;
            } else {
                window.location.href = "/web_app/teacher/dashboard/";
            }
        }
    });
}

function createTableElement() {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;
    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText)['resource_obj']['users'];
            let student_table = document.getElementById("student_table");
            let instructor_table = document.getElementById("instructor_table");
            let j = 0;
            for (let i = 0; i < response.length; i++) {
                let tr = document.createElement('tr');

                // attr 1
                let td1 = document.createElement('td');
                let in0 = document.createElement('input');
                in0.classList.add('form-check-input');
                if (response[i]['role'] === 'STUDENT') {
                    in0.classList.add('student_checkbox');
                }
                else {
                    in0.classList.add('instructor_checkbox');
                }
                in0.type = 'checkbox';
                in0.value = "";
                td1.appendChild(in0);
                tr.appendChild(td1);
                tr.id = response[i]['id'];
                if (response[i]['role'] === 'STUDENT') {
                    if (existing_student_list.includes(response[i]['id']))
                        in0.checked = true;
                    student_table.appendChild(tr);
                } else {
                    if (existing_instructor_list.includes(response[i]['id']))
                        in0.checked = true;
                    instructor_table.appendChild(tr);
                }
                // att 2 
                let td2 = document.createElement('td');
                td2.textContent = response[i]['name'] + ' ' + response[i]['surname'];
                tr.appendChild(td2);
                // attr 3
                let td3 = document.createElement('td');
                td3.textContent = response[i]['email'];
                tr.appendChild(td3);
                // attr 4
                let td4 = document.createElement('td');
                td4.textContent = response[i]['class_level'];
                tr.appendChild(td4);
                // attr 5
                let td5 = document.createElement('td');
                let a5 = document.createElement('a');
                a5.href = '/web_app/chat/' + response[i]['chat_uuid'];
                a5.target = '_blank';
                a5.textContent = "Open Chat";
                td5.appendChild(a5);
                tr.appendChild(td5);
                // if (response[i]['role'] === 'STUDENT') {
                //     // attr 6
                //     let td6 = document.createElement('td');
                //     let a6 = document.createElement('a');
                //     a6.href = '/web_app/teacher/curatorial/describe_groups/?id=' + exh_id + '&student_id=' + response[i]['id'];
                //     //a6.target = '_blank';
                //     a6.textContent = "Open Curatorial Process";
                //     if (response[i]['is_curatorial_avail'] === false){
                //         a6.style.display = 'none';
                //     }
                //     td6.appendChild(a6);
                //     tr.appendChild(td6);
                //     // attr 7
                //     let td7 = document.createElement('td');
                //     let a7 = document.createElement('a');
                //     a7.href = '/web_app/teacher/curatorial/final_assessment/?id=' + exh_id + '&student_id=' + response[i]['id'];
                //     //a7.target = '_blank';
                //     a7.textContent = "Open Final Assessment";
                //         if (response[i]['is_curatorial_assessment_avail'] === false){
                //             a7.style.display = 'none';
                //     }
                //     td7.appendChild(a7);
                //     tr.appendChild(td7);
                // }
            }
        }
    });
    xhr.open("GET", "/web_app/teacher/other_users_same_org/?id=" + exh_id, false);
    xhr.send();
}

createTableElement();

document.getElementById('selectAllStudentsCheckbox').addEventListener('change', function () {
    let checkboxes = document.querySelectorAll('.student_checkbox');
    checkboxes.forEach(function (checkbox) {
        checkbox.checked = this.checked;
    }, this);
});
document.getElementById('selectAllInstructorsCheckbox').addEventListener('change', function () {
    let checkboxes = document.querySelectorAll('.instructor_checkbox');
    checkboxes.forEach(function (checkbox) {
        checkbox.checked = this.checked;
    }, this);
});

function postStudentConnection(student, assignment) {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
        } else {
            console.log('error', xhr);
        }
    });
    xhr.open("POST", "/web_app/assignment/assign_student", false);
    let formData = new FormData();
    formData.append("student_fk", student);
    formData.append("assignment_fk", assignment);
    xhr.send(formData);
}

function deleteStudentConnection(student, assignment) {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;
    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
        } else {
            console.log('error', xhr);
        }
    });

    xhr.open("DELETE", "/web_app/assignment/remove_assigned_student?assignment-id=" + assignment + "&student-id=" + student, false);
    xhr.send();
}

function postAdvisorConnection(instructor, assignment) {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
        } else {
            console.log('error', xhr);
        }
    });

    xhr.open("POST", "/web_app/assignment/assign_instructors", false);
    let formData = new FormData();
    formData.append("instructor_fk", instructor);
    formData.append("assignment_fk", assignment);
    xhr.send(formData);
}

function deleteAdvisorConnection(instructor, assignment) {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            console.log(response);
        } else {
            console.log('error', xhr);
        }
    });

    xhr.open("DELETE", "/web_app/assignment/remove_assigned_instructor?assignment-id=" + assignment + "&instructor-id=" + instructor, false);
    xhr.send();
}
