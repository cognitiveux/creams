"use strict";

var frmID = document.getElementById('create_exhibition_form');
var btnSubmitID = $("#create_exhibition_submit");
var btnCancelID = $("#create_exhibition_cancel");

function handleFileSelect(evt) {
    var files = evt.target.files;
    for (var i = 0, f; f = files[i]; i++) {
      if (!f.type.match('image.*')) {
        continue;
      }

      var reader = new FileReader();
      reader.onload = (function(theFile) {
        return function(e) {
            $("#imgThumbnail").attr("src", e.target.result)
        };
      })(f);
      reader.readAsDataURL(f);
    }
  }

document.getElementById('image').addEventListener('change', handleFileSelect, false);

var exhbitions_init = function () {
    var initElements = function () {

    }

    return {
        init: function () {
            initElements();
        }
    };
}();


var exhbitions_create = function () {
    var actions = function () {

        $("#belk").on("click", function(e) {
            console.log($("#ddlArtTerms").val());
        });

        btnSubmitID.on("click", function(e) {
            e.preventDefault();
            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    var xhr = new XMLHttpRequest();
                    xhr.addEventListener("readystatechange", function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            Swal.fire({
                                text: "Form has been successfully submitted!",
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });

                            setTimeout(function () {
                                window.location.href = "/web_app/teacher/exhibition/edit/student_list/?id=" + response['resource_id'];
                            }, 2000);
                        } else {
                            Swal.fire({
                                text: "Sorry, looks like there are some errors detected, please try again.",
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }
                    });
                    xhr.open("POST", "/web_app/assignment/create", true);
                    let formData = new FormData();
                    formData.append("exhibition_title ", frmID.elements['exhibition_title'].value);
                    formData.append("start_date ", frmID.elements['start_date'].value);
                    formData.append("end_date  ", frmID.elements['end_date'].value);
                    formData.append("space_assign  ", frmID.elements['space_assign'].value);
                    formData.append("message  ", frmID.elements['message'].value);
                    formData.append("image", frmID.elements['image'].files[0]);
                    formData.append("exhibition_type", GetUrlParameter("type"));
                    formData.append("ar_exhibition_type", frmID.elements['ddlARExhibitionType'].value);
                    formData.append("art_terms", $("#ddlArtTerms").val());
                    formData.append("spatial_context_terms", $("#ddlSpatialContextTerms").val());
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });

        btnCancelID.on("click", function(e) {
            e.preventDefault();
            window.location.href = "/web_app/teacher/exhibitions/"
        });
    }

    return {
        init: function () {
            actions();
            if (GetUrlParameter("type") == "vr") {
                $("#divSpaceType").show();
            }
            if (GetUrlParameter("type") == "ar") {
                $("#divARExhibitionType").show();
            }
        }
    };
}();