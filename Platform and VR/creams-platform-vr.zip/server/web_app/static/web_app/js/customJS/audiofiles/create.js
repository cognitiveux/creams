"use strict";

var frmID = document.getElementById('create_audio_form');
var btnSubmitID = $("#create_audio_submit");
var btnCancelID = $("#create_audio_cancel");

var audios_init = function () {
    var initElements = function () {

    }

    return {
        init: function () {
            initElements();
        }
    };
}();


var audios_create = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();
            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    var xhr = new XMLHttpRequest();
                    xhr.addEventListener("readystatechange", function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            Swal.fire({
                                text: "Form has been successfully submitted!",
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            }).then(function (result) {
                                if (result.isConfirmed) {
                                    modal.hide();
                                }
                            });

                            setTimeout(function () {
                                window.location.href = "/web_app/student/audiofiles/";
                            }, 2000);
                        } else {
                            Swal.fire({
                                text: "Sorry, looks like there are some errors detected, please try again.",
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }
                    });
                    xhr.open("POST", "/web_app/audiofile/create/", true);
                    let formData = new FormData();
                    formData.append("name", frmID.elements['name'].value);
                    //formData.append("description", frmID.elements['description'].value);
                    formData.append("src", frmID.elements['file_input'].files[0]);
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });

        btnCancelID.on("click", function(e) {
            e.preventDefault();
            window.location.href = "/web_app/student/audiofiles/"
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();