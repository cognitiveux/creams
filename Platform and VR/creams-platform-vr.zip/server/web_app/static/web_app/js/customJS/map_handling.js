var GoogleMap;
var markers = [];
let lat = 35.14478368257859;
let lng = 33.410500801214475;
var ACTIVE_ARTWORK_ID = -1;

function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(lat, lng),
        zoom: 15,
    };
    GoogleMap = new google.maps.Map(document.getElementById("googleMap"), mapProp);
    GoogleMap.addListener("click", function (e) {
        for (let i = 0; i < markers.length; i++) {
            markers[i].setMap(null);
        }
        markers = [];
        var marker = new google.maps.Marker({
            position: new google.maps.LatLng(e.latLng),
            draggable: false,
        });

        marker.setMap(GoogleMap);
        markers.push(marker);

        const position = marker.getPosition();
        lat = position.lat();
        lng = position.lng();
        $("#spanModalLat").html(lat);
        $("#spanModalLng").html(lng);
    });    
}



// // jQuery version of the asynchronous geolocation request
// function getCurrentPositionAsync() {
//     return $.Deferred(function(deferred) {
//       navigator.geolocation.getCurrentPosition(
//         deferred.resolve, // Success: resolves the Deferred object
//         deferred.reject    // Failure: rejects the Deferred object
//       );
//     }).promise(); // Convert to a promise
//   }

//   async function initMap() {
//     let defaultLat = lat;
//     let defaultLng = lng;

//     try {
//       // Await the geolocation response
//       const position = await getCurrentPositionAsync();
//       const lat = position.coords.latitude;
//       const lng = position.coords.longitude;
//       initializeMap(lat, lng);
//     } catch (error) {
//       // In case of error (e.g., user denied permission), use default location
//       console.warn("Geolocation failed or denied. Using default location.");
//       initializeMap(defaultLat, defaultLng);
//     }
//   }

//   // Function to initialize the map
//   function initializeMap(lat, lng) {
//     let mapProp = {
//       center: new google.maps.LatLng(lat, lng),
//       zoom: 15,
//     };

//     GoogleMap = new google.maps.Map($("#googleMap")[0], mapProp);

//     GoogleMap.addListener("click", function (e) {
//         for (let i = 0; i < markers.length; i++) {
//             markers[i].setMap(null);
//         }
//         markers = [];
//         var marker = new google.maps.Marker({
//             position: new google.maps.LatLng(e.latLng),
//             draggable: false,
//         });

//         marker.setMap(GoogleMap);
//         markers.push(marker);

//         const position = marker.getPosition();
//         lat = position.lat();
//         lng = position.lng();
//         $("#spanModalLat").html(lat);
//         $("#spanModalLng").html(lng);
//     });
//   }

// $(document).ready(function() {
//     initMap();
// });