"use strict";

var btnSubmitID = $("#reset_password_submit");

var reset_password = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();

            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    let email = $("#el_email").val();
                    let password = $("#el_password").val();
                    let reset_code = $("#el_reset_code").val();

                    btnSubmitID.disabled = true;
                    var xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            btnSubmitID.disabled = false;
                            Swal.fire({
                                text: "Your password has been reset.",
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                            setTimeout(function () {
                                window.location.href = "/web_app/login/";
                            }, 2000);
                        } else {
                            btnSubmitID.disabled = false;
                            Swal.fire({
                                text: "Please check your data and try again.",
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }
                    };
                    xhr.open('POST', '/web_app/account-mgmt/reset-password', true);
                    let formData = new FormData();
                    formData.append("email", email);
                    formData.append("password", password);
                    formData.append("reset_code", reset_code);
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();