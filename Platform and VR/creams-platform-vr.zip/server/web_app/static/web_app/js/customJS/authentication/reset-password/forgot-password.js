"use strict";

var btnSubmitID = $("#request_code_submit");

var request_reset_code = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();

            if ($("#el_email").val() != "") {
                btnSubmitID.disabled = true;
                var xhr = new XMLHttpRequest();
                xhr.addEventListener("readystatechange", function () {
                    if (xhr.readyState !== 4) return;
                    var response = JSON.parse(xhr.responseText);
                    if (xhr.status >= 200 && xhr.status < 300) {
                        Swal.fire({
                            text: "An email has been sent to you including a reset password code in order to create a new password.",
                            icon: "success",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                        setTimeout(function () {
                            window.location.href = "/web_app/reset-password/";
                        }, 2000);
                    } else {
                        btnSubmitID.disabled = false;
                        $("#el_email").val("");
                        Swal.fire({
                            text: "No account found bound to this email.",
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                    }
                });
                xhr.open('POST', '/web_app/account-mgmt/request-password-reset-code', true);
                let formData = new FormData(); 
                formData.append("email", $("#el_email").val()); 
                xhr.send(formData);
            }
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();