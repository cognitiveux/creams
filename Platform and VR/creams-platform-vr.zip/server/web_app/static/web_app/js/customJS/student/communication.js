function createTableElement() {

    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;

    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText)['resource_obj']['users'];
            let instructor_table = document.getElementById("instructor_table");
            let j = 0;
            for (let i = 0; i < response.length; i++) {
                let tr = document.createElement('tr');
                // att 1 
                let td1 = document.createElement('td');
                let a1 = document.createElement('a');
                a1.textContent = response[i]['name'] + ' ' + response[i]['surname'];
                td1.appendChild(a1);
                tr.appendChild(td1);
                // attr 2
                let td2 = document.createElement('td');
                let a2 = document.createElement('a');
                a2.textContent = response[i]['email'];
                td2.appendChild(a2);
                tr.appendChild(td2);
                tr.id = response[i]['id'];
                instructor_table.appendChild(tr);
                // attr 3
                let td3 = document.createElement('td');
                let a3 = document.createElement('a');
                a3.href = '/web_app/chat/' + response[i]['chat_uuid'];
                //a3.target = '_blank';
                a3.textContent = "Open Chat";
                td3.appendChild(a3);
                tr.appendChild(td3);
            }

        } else {
            console.log('error', xhr);
        }
    });

    xhr.open("GET", "/web_app/student/available_instructors", false);
    xhr.send();
}

createTableElement();