function createTableElement() {
    var xhr = new XMLHttpRequest();
    xhr.withCredentials = true;
    xhr.addEventListener("readystatechange", function () {
        if (xhr.readyState !== 4) return;
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText)['resource_obj']['users'];
            let student_table = document.getElementById("student_table");
            //let instructor_table = document.getElementById("instructor_table");
            let j = 0;
            for (let i = 0; i < response.length; i++) {
                let tr = document.createElement('tr');
                // att 1 
                let td1 = document.createElement('td');
                td1.textContent = response[i]['name'] + ' ' + response[i]['surname'];
                tr.appendChild(td1);
                // attr 2
                let td2 = document.createElement('td');
                td2.textContent = response[i]['email'];
                tr.appendChild(td2);
                // attr 3
                let td3 = document.createElement('td');
                td3.textContent = response[i]['class_level'];
                tr.appendChild(td3);
                tr.id = response[i]['id'];
                if (response[i]['role'] === 'STUDENT') {
			        student_table.appendChild(tr);
		        }
                //     instructor_table.appendChild(tr);
                //} else {
                //    student_table.appendChild(tr);
                //}
                // attr 5
                let td5 = document.createElement('td');
                let a5 = document.createElement('a');
                a5.href = '/web_app/chat/' + response[i]['chat_uuid'];
                //a5.target = '_blank';
                a5.textContent = "Open Chat";
                td5.appendChild(a5);
                tr.appendChild(td5);
            }
        } else {
            console.log('error', xhr);
        }
    });
    xhr.open("GET", "/web_app/teacher/other_users_same_org", false);
    xhr.send();
}

createTableElement();