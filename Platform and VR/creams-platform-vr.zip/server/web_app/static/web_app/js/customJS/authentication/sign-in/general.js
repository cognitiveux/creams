"use strict";

var btnSubmitID = $("#signin_submit");

var signin = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();

            if ($("#el_email").val() != "" && $("#el_password").val() != "") {
                btnSubmitID.disabled = true;
                var xhr = new XMLHttpRequest();
                xhr.addEventListener("readystatechange", function () {
                    if (xhr.readyState !== 4) return;
                    var response = JSON.parse(xhr.responseText);
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var tkn_access = response['resource_obj']['access'];
                        var tkn_refresh = response['resource_obj']['refresh'];

                        var base64Url = tkn_access.split('.')[1];
                        var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
                        var jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function (c) {
                            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
                        }).join(''));
                        var resultObj = JSON.parse(jsonPayload);

                        if (resultObj.role === "INSTRUCTOR") {
                            location.href = '/web_app/teacher/dashboard/';

                        } else if (resultObj.role === 'STUDENT') {
                            location.href = '/web_app/student/dashboard/';
                        } else if (resultObj.role === 'ARTIST') {
                            location.href = '/web_app/artist/dashboard/';
                        } else {
                            alert("Something went wrong!");
                        }
                    } else {
                        btnSubmitID.disabled = false;
                        $("#el_password").val("");
                        Swal.fire({
                            text: response['message'],
                            icon: "error",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                    }
                });
                xhr.open('POST', '/web_app/account-mgmt/login', true);
                let formData = new FormData(); 
                formData.append("email", $("#el_email").val()); 
                formData.append("password", $("#el_password").val());
                xhr.send(formData);
            }
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();