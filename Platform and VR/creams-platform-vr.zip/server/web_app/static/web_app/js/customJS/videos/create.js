"use strict";

var frmID = document.getElementById('create_video_form');
var btnSubmitID = $("#create_video_submit");
var btnCancelID = $("#create_video_cancel");

var videos_init = function () {
    var initElements = function () {

    }

    return {
        init: function () {
            initElements();
        }
    };
}();


var videos_create = function () {
    var actions = function () {
        btnSubmitID.on("click", function(e) {
            e.preventDefault();
            const forms = document.querySelectorAll('.needs-validation')

            Array.from(forms).forEach(form => {
                if (form.checkValidity()) {
                    var xhr = new XMLHttpRequest();
                    xhr.addEventListener("readystatechange", function () {
                        if (xhr.readyState !== 4) return;
                        if (xhr.status >= 200 && xhr.status < 300) {
                            var response = JSON.parse(xhr.responseText);
                            Swal.fire({
                                text: "Form has been successfully submitted!",
                                icon: "success",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });

                            setTimeout(function () {
                                window.location.href = "/web_app/student/media/";
                            }, 2000);
                        } else {
                            Swal.fire({
                                text: "Sorry, looks like there are some errors detected, please try again.",
                                icon: "error",
                                buttonsStyling: false,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }
                    });
                    xhr.open("POST", "/web_app/videofile/create", true);
                    let formData = new FormData();
                    formData.append("name", frmID.elements['name'].value);
                    //formData.append("description", frmID.elements['description'].value);
                    formData.append("src", frmID.elements['file_input'].files[0]);
                    xhr.send(formData);
                }
                form.classList.add('was-validated')
            })
        });

        btnCancelID.on("click", function(e) {
            e.preventDefault();
            window.location.href = "/web_app/student/media/"
        });
    }

    return {
        init: function () {
            actions();
        }
    };
}();