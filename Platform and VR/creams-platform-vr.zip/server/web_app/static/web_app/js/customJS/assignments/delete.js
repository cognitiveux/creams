try {
    document.getElementById('deleteAssignmentkBtn').onclick = function () {
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: 'btn btn-success',
                cancelButton: 'btn btn-danger'
            },
            buttonsStyling: false
        });

        Swal.fire({
            text: "Are you sure you would like to delete this exhibition?",
            icon: "question",
            showCancelButton: true,
            buttonsStyling: false,
            confirmButtonText: "Yes, delete it!",
            cancelButtonText: "No, return",
            customClass: {
                confirmButton: "btn btn-primary",
                cancelButton: "btn btn-active-light"
            }
        }).then(function (result) {
            if (result.value) {
                /***************************/
                var xhr = new XMLHttpRequest();

                xhr.addEventListener("readystatechange", function () {
                    // Only run if the request is complete
                    if (xhr.readyState !== 4) return;
                    // Process our return data
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var response = JSON.parse(xhr.responseText);
                        swalWithBootstrapButtons.fire(
                            'Deleted!',
                            'Your exhibition has been deleted.',
                            'success'
                        )
                        setTimeout(function () {
                            location.href = "/web_app/teacher/dashboard/";
                        }, 2000);
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong!',
                        })
                    }
                });

                xhr.open("DELETE", "/web_app/assignment/delete/?assignment-id=" + EXHIBITION_ID, true);
                xhr.send();
                /***************************/

            } else if (result.dismiss === 'cancel') {}
        });

    };

} catch {
    console.log("You're not the main advisor!");
}