function displayUsername() {
	var username = $("#username").val();
	console.log("[displayUsername] username is: " + username);
	alert("[displayUsername] username is: " + username);
}

$(document).ready(function (){
	console.log("[index] index page called");
});