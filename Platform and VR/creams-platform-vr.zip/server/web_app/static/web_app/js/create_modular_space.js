var canvas;
var HAS_A_STARTER = false;
var STARTER_HEX = "#20c997";
var x;
var y;
var exist = [];
canvas = document.getElementById("tutorial");
canvas.addEventListener('click', function (e) {
	x = e.offsetX;
	y = e.offsetY;
	if (this.getContext) {
		const ctx = this.getContext("2d");
		block = findProperBlock(x, y);
		if (doesNotExist(block)) {
			ctx.fillRect(block.x, block.y, 100, 100);
			ctx.beginPath();
			ctx.rect(block.x, block.y, 100, 100);
			if (HAS_A_STARTER) {
				block.starter = false;
				ctx.fillStyle = "#ED4969";
			} else {
				ctx.fillStyle = STARTER_HEX;
				HAS_A_STARTER = true;
				block.starter = true;
			}
			ctx.fill();
			exist.push(block);
		} else {
			let handler = getExisting(block);
			if (handler.starter === true) {
				if (HAS_A_STARTER === true) {
					ctx.clearRect(handler.x, handler.y, 100, 100);
					HAS_A_STARTER = false;
					removeFromCanvas(handler);
				}

			} else {
				if (HAS_A_STARTER === false) {
					ctx.fillRect(block.x, block.y, 100, 100);
					ctx.beginPath();
					ctx.rect(block.x, block.y, 100, 100);
					ctx.fillStyle = STARTER_HEX;
					ctx.fill();
					handler.starter = true;
					HAS_A_STARTER = true;
				} else {
					ctx.clearRect(handler.x, handler.y, 100, 100);
					removeFromCanvas(handler);
				}
			}

		}
	}
});

let flag = false;
let possible_blocks = [];
for (let j = 0; j < canvas.height; j = j + 100)
	for (let i = 0; i < canvas.width; i = i + 100)
		possible_blocks.push({
			'x': j,
			'y': i,
		});

function findProperBlock(x, y) {
	return {
		'x': Math.floor(x / 100) * 100,
		'y': Math.floor(y / 100) * 100,
	}
}

function removeFromCanvas(block) {
	for (let i = 0; i < exist.length; i++)
		if (exist[i].x === block.x && exist[i].y === block.y) {
			exist.splice(i, 1);
			return true;

		}
	return false;
}

function doesNotExist(block) {
	for (let i = 0; i < exist.length; i++)
		if (exist[i].x === block.x && exist[i].y === block.y)
			return false;
	return true;
}

function getExisting(block) {
	for (let i = 0; i < exist.length; i++)
		if (exist[i].x === block.x && exist[i].y === block.y)
			return exist[i];
	return true;
}

function createBlueprint() {
	let submitButton = document.getElementById('btnSubmit');
	// Disable button to avoid multiple click 
	submitButton.disabled = true;
	if (HAS_A_STARTER) {
		let ret = {};
		for (let i = 0; i < exist.length; i++) {
			let up = false,
				down = false,
				right = false,
				left = false;
			let upTo = -1,
				downTo = -1,
				rightTo = -1,
				leftTo = -1;
			for (let j = 0; j < exist.length; j++) {
				if (i !== j) {
					if (exist[i].y === exist[j].y && (exist[i].y - exist[j].y) <= 100 && (exist[i].y - exist[j].y) >= 0 && (exist[i].x - exist[j].x) <= 100 && (exist[i].x - exist[j].x) >= 0) {
						right = true;
						rightTo = j;
					}
					if (exist[i].y === exist[j].y && (-exist[i].y + exist[j].y) <= 100 && (-exist[i].y + exist[j].y) >= 0 && (-exist[i].x + exist[j].x) <= 100 && (-exist[i].x + exist[j].x) >= 0) {
						left = true;
						leftTo = j;
					}
					if (exist[i].x === exist[j].x && (exist[i].y - exist[j].y) <= 100 && (exist[i].y - exist[j].y) >= 0 && (exist[i].x - exist[j].x) <= 100 && (exist[i].x - exist[j].x) >= 0) {
						down = true;
						downTo = j;
					}
					if (exist[i].x === exist[j].x && (-exist[i].y + exist[j].y) <= 100 && (-exist[i].y + exist[j].y) >= 0 && (-exist[i].x + exist[j].x) <= 100 && (-exist[i].x + exist[j].x) >= 0) {
						up = true;
						upTo = j;
					}
				}
			}
			ret[i] = {
				'x': exist[i].x / 100,
				'y': exist[i].y / 100,
				'starting': exist[i].starter,
				'up': up,
				'upTo': upTo,
				'down': down,
				'downTo': downTo,
				'right': right,
				'rightTo': rightTo,
				'left': left,
				'leftTo': leftTo
			};
		}

		var min_x = 100000,
			min_y = 100000;
		for (let prop in ret) {
			// Call the callback as: callback(key, value)
			if (min_x > ret[prop].x)
				min_x = ret[prop].x;
			if (min_y > ret[prop].y)
				min_y = ret[prop].y;
		}

		for (let prop in ret) {
			// Call the callback as: callback(key, value)
			ret[prop].x = ret[prop].x - min_x;
			ret[prop].y = ret[prop].y - min_y;
		}
		// Create urlParams query string
		var urlParams = new URLSearchParams(window.location.search);

		// Get value of single parameter
		var sectionName = urlParams.get('assign');
		setTimeout(() => {
			submitButton.removeAttribute('data-kt-indicator');
			submitButton.disabled = false;
		}, "1000");
		setTimeout(() => {
			let url = '/web_app/' + user_role + '/editor/?assign=';
			//window.location.href = url + sectionName + '&height=' + document.getElementById('room_height').value + '&layout=' + JSON.stringify(ret);
			window.location.href = url + sectionName + '&height=5&layout=' + JSON.stringify(ret);
		}, "1000");
	} else {
		Swal.fire({
			icon: 'error',
			title: 'Oops... Something went wrong',
			text: 'You have to set a starting point',
		}).then(function (result) {
			submitButton.removeAttribute('data-kt-indicator');
			submitButton.disabled = false;
		});
	}

}