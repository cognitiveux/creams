function help() {
    Swal.fire({
        title: "<h1>" + HELP_TITLE + "</h1>",
        text: HELP_TEXT,
    })
}