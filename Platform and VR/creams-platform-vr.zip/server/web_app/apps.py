from django.apps import AppConfig
from .image_similarity import Img2Vec
from .chromadb_client import get_client


class WebappConfig(AppConfig):
    name = 'web_app'
    IMG_SIMIL = Img2Vec('resnet50', weights='DEFAULT')

    def ready(self):
        client = get_client()

'''
    items = []
    _initialized = False
    client = None

    def ready(self):
        WebappConfig.client = None

        if not WebappConfig._initialized:
            WebappConfig._initialized = True
            WebappConfig.client = chromadb.Client()

            f = open("/code/web_app/study_data.json")

            data = json.load(f)

            for item in data:
                item_name = item.get('name')
                item_name = item_name.replace(' ', '_')
                if item_name not in WebappConfig.items:
                    WebappConfig.items.append(item_name)
                    print("Adding name to chromadb collection: ", item_name)
                    descr = item.get('description')
                    descr_split = descr.split(".")
                    ids = [str(i) for i in range(len(descr_split))]
                    client_obj = WebappConfig.client.get_or_create_collection(name=item_name)
                    client_obj.add(documents=descr_split,ids=ids)


            print("Init chromadb success")
'''
