from .views import *
from django.http import HttpResponseNotAllowed
from datetime import datetime
import psycopg2
from django.shortcuts import render, redirect
from .forms import ExtendedOrganizationsForm


DIR_NAME = "reference_tables"

def load_data(CFG_FILE):
	data = {}

	with open(DIR_NAME + "/" + CFG_FILE) as json_file:
		data = json.load(json_file)

	return data


def delete_and_reset_db(conn, cursor):
	try:
		cursor.execute("delete from public.web_app_artterms")
		cursor.execute("delete from public.web_app_spatialcontextterms")
		# Reset sequence of primary keys
		cursor.execute('''SELECT setval(pg_get_serial_sequence('"web_app_artterms"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "web_app_artterms";''')
		cursor.execute('''SELECT setval(pg_get_serial_sequence('"web_app_spatialcontextterms"','id'), coalesce(max("id"), 1), max("id") IS NOT null) FROM "web_app_spatialcontextterms";''')
		conn.commit()
	except Exception as e:
		print("[delete_and_reset_db] Error occurred: {}".format(str(e)))


def insert_artterms(conn, cursor, data, ts_now):
	try:
		i = 0
		for item in data:
			i = i + 1
			r_id = item.get("id")
			name = item.get("name")

			cursor.execute("INSERT INTO public.web_app_artterms ( \
				id, name, ts_added, ts_last_updated) \
				VALUES (%s, %s, %s, %s)",
				(
					r_id, name, ts_now, ts_now
				)
			)
		conn.commit()
	except Exception as e:
		traceback.print_exc()
		print("[insert_artterms] Error occurred: {}".format(str(e)))


def insert_spatialcontextterms(conn, cursor, data, ts_now):
	try:
		i = 0
		for item in data:
			i = i + 1
			r_id = item.get("id")
			name = item.get("name")

			cursor.execute("INSERT INTO public.web_app_spatialcontextterms ( \
				id, name, ts_added, ts_last_updated) \
				VALUES (%s, %s, %s, %s)",
				(
					r_id, name, ts_now, ts_now
				)
			)
		conn.commit()
	except Exception as e:
		traceback.print_exc()
		print("[insert_artterms] Error occurred: {}".format(str(e)))


def adminDashboardPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if(tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if(instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    template = loader.get_template('web_app/admin/dashboard.html')

    context = {
		'title': "Admin Dashboard",
		'header_content': 'Index header content',
        'user' : caller,
	}
    return HttpResponse(template.render(context, request))


def adminAddTermsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if(tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if(instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    try:
        ts_now = datetime.now()
        conn = psycopg2.connect("dbname=postgres user=postgres host=creams-postgres-poc-final")
        cursor = conn.cursor()

        delete_and_reset_db(conn, cursor)

        artterms_data = load_data("ArtTerms.json")
        insert_artterms(conn, cursor, artterms_data, ts_now)

        spatialcontextterms_data = load_data("SpatialContextTerms.json")
        insert_spatialcontextterms(conn, cursor, spatialcontextterms_data, ts_now)

        cursor.close()
        conn.close()
    except Exception as e:
        print("Error occurred: {}".format(str(e)))

    template = loader.get_template('web_app/admin/add_terms.html')

    context = {
		'title': "Admin Add Terms",
		'header_content': 'Index header content',
        'user' : caller,
	}
    return HttpResponse(template.render(context, request))


def adminManageGuidesPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if(tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if(instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    template = loader.get_template('web_app/admin/manage_guides.html')

    context = {
		'title': "Admin Add Terms",
		'header_content': 'Index header content',
        'user' : caller,
	}
    return HttpResponse(template.render(context, request))


def adminManageKRPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if(tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)
    
    if(instr == False):
        if decoded['role'] == STUDENT:
            return HttpResponseRedirect('/web_app/student/dashboard/')
        elif decoded['role'] == ARTIST:
            return HttpResponseRedirect('/web_app/artist/dashboard/')
        else:
            return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
    caller = get_object_or_404(Users,id = decoded['user_id'])

    template = loader.get_template('web_app/admin/manage_kr.html')

    context = {
		'title': "Admin Add Terms",
		'header_content': 'Index header content',
        'user' : caller,
	}
    return HttpResponse(template.render(context, request))


# def adminManageOrganizationsPage(request):
#     access_tkn = request.COOKIES.get('access_tkn')
#     refresh_tkn = request.COOKIES.get('refresh_tkn')
#     if not access_tkn:
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)

#     tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
#     if(tkn_okay == False):
#         url = reverse('loginPage')
#         return HttpResponseRedirect(url)
    
#     if(instr == False):
#         if decoded['role'] == STUDENT:
#             return HttpResponseRedirect('/web_app/student/dashboard/')
#         elif decoded['role'] == ARTIST:
#             return HttpResponseRedirect('/web_app/artist/dashboard/')
#         else:
#             return HttpResponseRedirect('/web_app/visitor/dashboard/')
    
#     caller = get_object_or_404(Users,id = decoded['user_id'])

#     template = loader.get_template('web_app/admin/manage_organizations.html')

#     context = {
# 		'title': "Admin Manage Organizations",
# 		'header_content': 'Index header content',
#         'user' : caller,
# 	}
#     return HttpResponse(template.render(context, request))


def adminManageOrganizationsPage(request):
    access_tkn = request.COOKIES.get('access_tkn')
    refresh_tkn = request.COOKIES.get('refresh_tkn')
    if not access_tkn:
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    tkn_okay, instr, decoded = at.authenticateInstructor(request,settings)
    if(tkn_okay == False):
        url = reverse('loginPage')
        return HttpResponseRedirect(url)

    if request.method == 'POST':
        form = ExtendedOrganizationsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  
    else:
        form = ExtendedOrganizationsForm()

    return render(request, 'web_app/admin/manage_organizations.html', {'form': form})


def org_success(request):
    return render(request, 'web_app/admin/manage_organizations.html')