#!/bin/bash
pkill -9 celery
celery -A creams_project worker & celery -A creams_project beat & celery -A creams_project flower --conf=./creams_project/flowerconfig.py
sleep 5