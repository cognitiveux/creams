#!/bin/bash

# Delete the x.flag file if it exists
if [ -f "/code/webapp_chromadb_initialized.flag" ]; then
    rm /code/webapp_chromadb_initialized.flag
    echo "Deleted /code/webapp_chromadb_initialized.flag"
fi

exec "$@"
