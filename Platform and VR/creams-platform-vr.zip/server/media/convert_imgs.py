from PIL import Image
import os

def convert_images_to_rgb(input_folder, output_folder=None):
    # Create the output folder if it doesn't exist
    if output_folder and not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Iterate over all files in the input folder
    for filename in os.listdir(input_folder):
        if filename.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            file_path = os.path.join(input_folder, filename)
            
            # Open the image
            image = Image.open(file_path)

            # Check if the image is in RGBA format
            if image.mode == 'RGBA':
                print(f"Converting {filename} from RGBA to RGB.")
                # Convert the image to RGB
                image = image.convert('RGB')
            else:
                print(f"{filename} is already in RGB format.")

            # Determine the output path
            if output_folder:
                output_path = os.path.join(output_folder, filename)
            else:
                output_path = file_path  # Overwrite the original file

            # Save the image
            image.save(output_path)

# Example usage
input_folder = 'images/'
output_folder = None  # Set to None to overwrite original files
convert_images_to_rgb(input_folder, output_folder)

