from PIL import Image
import os

# Paths
input_folder = "images"
output_folder = "resized_images"

# Create the output folder if it doesn't exist
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Target size for the resized images (width, height)
target_size = (800, 600)  # Adjust as needed

# Loop through all files in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith(('.png', '.jpg', '.jpeg', '.gif', '.JPG', '.JPEG')):
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(output_folder, filename)

        # Open the image
        image = Image.open(input_path)

        # Check if the existing size is smaller than the target size
        if image.width < target_size[0] or image.height < target_size[1]:
            # If smaller, just copy the image to the output folder
            image.save(output_path)
        else:
            # Calculate the aspect ratio to maintain it during resizing
            aspect_ratio = image.width / image.height
            new_width = target_size[0]
            new_height = int(new_width / aspect_ratio)

            # Resize the image while maintaining aspect ratio
            resized_image = image.resize((new_width, new_height), Image.LANCZOS)

            # Save the resized image to the output folder
            resized_image.save(output_path)

        # Close the image
        image.close()

print("Image resizing complete.")
