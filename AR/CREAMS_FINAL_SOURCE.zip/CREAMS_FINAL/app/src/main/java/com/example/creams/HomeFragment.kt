package com.example.creams

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.fragment_home.*
import okhttp3.*
import okio.IOException
import org.json.JSONObject

class HomeFragment : Fragment() {



    // Initialization of adapter
    val gson: Gson = GsonBuilder().create()
    var outdoorGalleries: OutdoorGalleryModel = gson.fromJson("{\"exhibitions\":[]}",OutdoorGalleryModel::class.java)

    ///////////////////////////////////////
    //var outdoorGalleriesArtworks: OutdoorGalleries = gson.fromJson("{\"artworks\":[]}",OutdoorGalleries::class.java)

    private var recyclerViewGalleries: RecyclerView? = null  // Ensure it's nullable


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_home, container, false)

//        // Inflate the layout for this fragment
//        val view = inflater.inflate(R.layout.fragment_home, container, false)
//
//        val recyclerView_Galleries_Home = view?.findViewById(R.id.recyclerView_Galleries_Home) as RecyclerView
//        recyclerView_Galleries_Home.layoutManager = GridLayoutManager(context, 1,  RecyclerView.HORIZONTAL,false )
//        recyclerView_Galleries_Home.adapter = MainAdapter(outdoorGalleries)
//
//
//        fetchJson()
//
//        return view
    }

    @SuppressLint("CutPasteId")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerViewGalleries = view.findViewById(R.id.recyclerView_Galleries_Home)
        recyclerViewGalleries?.layoutManager = GridLayoutManager(context, 1, RecyclerView.HORIZONTAL, false)
        recyclerViewGalleries?.adapter = MainAdapter(outdoorGalleries)

        // All> button
        val buttonAll = view.findViewById<Button>(R.id.button_all)
        buttonAll.setOnClickListener {
            findNavController().navigate(R.id.action_homeFragment_to_galleriesFragment)
        }

        /* TO DO : Put button stuff in function */

        // Closest Gallery Button
        val dis_closest_gallery_button = view.findViewById(R.id.dis_closest_gallery_button) as Button
        dis_closest_gallery_button.setOnClickListener {
            val button_id = 1
            val artworklistlat = arrayListOf<Double>()
            val artworklistlon = arrayListOf<Double>()
            val artworklistsrc = arrayListOf<String>()
            val artworklistname = arrayListOf<String>()
            var ownername = arrayListOf<String>()
            var artworklistownerid = arrayListOf<String>()
            val artworklistowneridart = arrayListOf<String>()
            val num_exhibitions = outdoorGalleries.exhibitions.size
            val artworklistarttype = arrayListOf<String>()
            val artworklistthreedfiles = ArrayList<List<String>>()


            activity?.let{
                //fetchJsonButton (button_id)
                //Thread.sleep(2_000)
                val bundle = Bundle()
                val intent = Intent (it, MapsActivity::class.java)

                // Bundle up the exhibition and artwork info
                //bundle.putString("ownername", outdoorGalleries.exhibitions[1].owner_name)

                for (i in 0 until num_exhibitions ) {
                    ownername += outdoorGalleries.exhibitions[i].owner_name
                    artworklistownerid += outdoorGalleries.exhibitions[i].owner /*id of owner in exhibition*/

                    // Extracting from artworks correctly
                    val artworks = outdoorGalleries.exhibitions[i].artworks
                    artworklistowneridart += artworks.map { it.owner } as ArrayList<String> /*id of owner in artworks*/
                    artworklistname += artworks.map { it.name } as ArrayList<String>
                    artworklistlat += artworks.map { it.lat ?: 0.0 } as ArrayList<Double> // handle nulls
                    artworklistlon += artworks.map { it.lon ?: 0.0 } as ArrayList<Double> // handle nulls
                    artworklistsrc += artworks.map { it.src } as ArrayList<String>

                    // Correctly extracting art_type and threed_files
                    artworklistarttype += artworks.map { it.art_type ?: "unknown" } as ArrayList<String> // Default to "unknown" if null
                    artworklistthreedfiles += artworks.map { it.threed_files.ifEmpty { listOf() } } as ArrayList<List<String>> // Handle empty lists
                }


                bundle.putInt("button_id",  button_id)

                // artworks_size = Number of ALL the artworks
                bundle.putInt("artworks_size", artworklistname.size)
                bundle.putStringArrayList("artworklistname",  artworklistname)
                bundle.putSerializable("artworklistlat", artworklistlat)
                bundle.putSerializable("artworklistlon", artworklistlon)
                bundle.putStringArrayList("artworklistsrc", artworklistsrc)

                // Adding art_type and threed_files to the bundle
                bundle.putStringArrayList("artworklistarttype", artworklistarttype)

                // Convert artworklistthreedfiles to ArrayList of ArrayList
                val serializedThreedFiles = ArrayList<ArrayList<String>>()
                artworklistthreedfiles.forEach { serializedThreedFiles.add(ArrayList(it)) }
                bundle.putSerializable("artworklistthreedfiles", serializedThreedFiles)

                // Remove duplicates
                val artworklistownerid_new = artworklistownerid.distinct()
                val ownername_new = ownername.distinct()

                // Create Array List with painters' names
                for (i in 0 until artworklistowneridart.size) {
                    for (j in 0 until artworklistownerid_new.size) {
                        if (artworklistownerid_new[j] == artworklistowneridart[i]) {
                            artworklistowneridart[i] = ownername_new [j]
                        }
                    }
                }
                // Bundle painters' names according to their id
                bundle.putStringArrayList("artworklistowneridart",artworklistowneridart)
                Thread.sleep(1_000)
                // Add bundle to intent and send to intended activity
                intent.putExtras(bundle)
                it.startActivity(intent)
            }
        }



        // Closest Artwork Button
        val dis_closest_artwork_button = view.findViewById(R.id.dis_closest_artwork_button) as Button
        dis_closest_artwork_button.setOnClickListener {
            val button_id = 2
            val artworklistlat = arrayListOf<Double>()
            val artworklistlon = arrayListOf<Double>()
            val artworklistsrc = arrayListOf<String>()
            val artworklistarttype = arrayListOf<String>()
            val artworklistname = arrayListOf<String>()
            val ownername = arrayListOf<String>()
            val artworklistownerid = arrayListOf<String>()
            val artworklistowneridart = arrayListOf<String>()
            val artworklistthreedfiles = ArrayList<List<String>>()

            val num_exhibitions = outdoorGalleries.exhibitions.size

            activity?.let{
                //fetchJsonButton (button_id)
                //Thread.sleep(2_000)
                val bundle = Bundle()
                val intent = Intent (it, MapsActivity::class.java)

                // Bundle up the exhibition and artwork info
                //bundle.putString("ownername", outdoorGalleries.exhibitions[1].owner_name)

                for (i in 0 until num_exhibitions ) {
                    ownername += outdoorGalleries.exhibitions[i].owner_name
                    artworklistownerid += outdoorGalleries.exhibitions[i].owner /*id of owner in exhibition*/

                    // Extracting from artworks correctly
                    val artworks = outdoorGalleries.exhibitions[i].artworks
                    artworklistowneridart += artworks.map { it.owner } as ArrayList<String> /*id of owner in artworks*/
                    artworklistname += artworks.map { it.name } as ArrayList<String>
                    artworklistlat += artworks.map { it.lat ?: 0.0 } as ArrayList<Double> // handle nulls
                    artworklistlon += artworks.map { it.lon ?: 0.0 } as ArrayList<Double> // handle nulls
                    artworklistsrc += artworks.map { it.src } as ArrayList<String>

                    // Correctly extracting art_type and threed_files
                    artworklistarttype += artworks.map { it.art_type ?: "unknown" } as ArrayList<String> // Default to "unknown" if null
                    artworklistthreedfiles += artworks.map { it.threed_files.ifEmpty { listOf() } } as ArrayList<List<String>> // Handle empty lists
                }



                bundle.putInt("button_id",  button_id)

                // artworks_size = Number of ALL the artworks
                bundle.putInt("artworks_size", artworklistname.size)
                bundle.putStringArrayList("artworklistname",  artworklistname)
                bundle.putSerializable("artworklistlat", artworklistlat)
                bundle.putSerializable("artworklistlon", artworklistlon)
                bundle.putStringArrayList("artworklistsrc", artworklistsrc)

                // Adding art_type and threed_files to the bundle
                bundle.putStringArrayList("artworklistarttype", artworklistarttype)

                // Convert artworklistthreedfiles to ArrayList of ArrayList
                val serializedThreedFiles = ArrayList<ArrayList<String>>()
                artworklistthreedfiles.forEach { serializedThreedFiles.add(ArrayList(it)) }
                bundle.putSerializable("artworklistthreedfiles", serializedThreedFiles)



                // Remove duplicates
                val artworklistownerid_new = artworklistownerid.distinct()
                val ownername_new = ownername.distinct()

                // Create Array List with painters' names
                for (i in 0 until artworklistowneridart.size) {
                    for (j in 0 until artworklistownerid_new.size) {
                        if (artworklistownerid_new[j] == artworklistowneridart[i]) {
                            artworklistowneridart[i] = ownername_new [j]
                        }
                    }
                }
                // Bundle painters' names according to their id
                bundle.putStringArrayList("artworklistowneridart",artworklistowneridart)
                Thread.sleep(1_000)
                // Add bundle to intent and send to intended activity
                intent.putExtras(bundle)
                it.startActivity(intent)
            }
        }

        fetchJson()

    }



    fun fetchJson() {

        // Val url that doesn't change
        val url = "https://creams-poc-final.cognitiveux.net/web_app/exhibitions/outdoor/all"

        // Construct the request
        val request = Request.Builder().url(url).build()
        val client = OkHttpClient()

        // Call the request (execute outside the main thread... enqueued first)
        // Enqueue runs all the request on the background, need to call run on ui to bring in the front
        client.newCall(request).enqueue(object: Callback {
            @SuppressLint("NotifyDataSetChanged")
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                val json = JSONObject(body)
                val resource_obj = json.getJSONObject("resource_obj").toString()

                //val gson = GsonBuilder().create()
                outdoorGalleries = gson.fromJson(resource_obj,OutdoorGalleryModel::class.java)
                activity?.runOnUiThread(Runnable {
                    recyclerView_Galleries_Home?.adapter = MainAdapter(outdoorGalleries)
                })
            }
            override fun onFailure(call: Call, e: IOException) {
                println("Failed to execute request")
                e.printStackTrace()
            }
        } )
    }






}