package com.example.creams

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okio.IOException
import org.json.JSONObject

class GalleriesFragment : Fragment() {

    private lateinit var recyclerViewArtworks: RecyclerView
    private lateinit var mainAdapter: MainAdapter
    private val gson: Gson = GsonBuilder().create()

    private var transformedExhibitions: MutableList<OutdoorGalleries> = mutableListOf() // List to hold "fake" exhibitions

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_galleries, container, false)
        recyclerViewArtworks = view.findViewById(R.id.recyclerView_Galleries)
        recyclerViewArtworks.layoutManager = GridLayoutManager(context, 2) // Display two items per row

        // Fetch JSON data and setup RecyclerView after data is ready
        fetchJson {
            // Once data is fetched and transformed, pass the transformed galleries to MainAdapter
            val galleryModel = OutdoorGalleryModel(transformedExhibitions)
            mainAdapter = MainAdapter(galleryModel)
            recyclerViewArtworks.adapter = mainAdapter
        }

        recyclerViewArtworks.addOnItemClickListener(object : OnItemClickListener {
            override fun onItemClicked(position: Int) {
                // Get the corresponding "gallery" which is actually a single artwork now
                val selectedGallery = transformedExhibitions[position]
                val firstArtwork = selectedGallery.artworks.firstOrNull()
                val artType = firstArtwork?.art_type

                // Construct the correct URL for the AR activity
                val uriToPass = if (artType == "2d") {
                    // Pass the relative path of the 2D image
                    "https://creams-poc-final.cognitiveux.net/media/${firstArtwork?.src}"
                } else {
                    firstArtwork?.threed_files?.firstOrNull()?.let { "https://creams-poc-final.cognitiveux.net/$it" }
                }

                if (uriToPass != null) {
                    openArActivity(Uri.parse(uriToPass))
                } else {
                    Toast.makeText(context, "No valid 3D file found.", Toast.LENGTH_SHORT).show()
                }
            }
        })

        return view
    }

    private fun RecyclerView.addOnItemClickListener(onItemClickListener: OnItemClickListener) {
        this.addOnChildAttachStateChangeListener(object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                view.setOnClickListener {
                    val position = getChildAdapterPosition(view)
                    if (position != RecyclerView.NO_POSITION) {
                        onItemClickListener.onItemClicked(position)
                    }
                }
            }

            override fun onChildViewDetachedFromWindow(view: View) {
                view.setOnClickListener(null)
            }
        })
    }

    private fun fetchJson(onComplete: () -> Unit) {
        val url = "https://creams-poc-final.cognitiveux.net/web_app/exhibitions/outdoor/all"
        val request = Request.Builder().url(url).build()
        val client = OkHttpClient()

        client.newCall(request).enqueue(object : Callback {
            @SuppressLint("NotifyDataSetChanged")
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string()
                val json = JSONObject(body)
                val resourceObj = json.getJSONObject("resource_obj").toString()

                // Parse the data into `OutdoorGalleryModel`
                val outdoorGalleries = gson.fromJson(resourceObj, OutdoorGalleryModel::class.java)

                // Transform each artwork into a separate gallery/exhibition
                outdoorGalleries.exhibitions.forEach { gallery ->
                    gallery.artworks.forEach { artwork ->
                        // Use just the relative path as the thumbnail (e.g., "images/abstract.jpeg")
                        val thumbnailPath = artwork.src

                        Log.d("GalleriesFragment", "Thumbnail Path: $thumbnailPath")  // Log the path

                        // Create a fake "gallery" for each artwork with relative `thumbnail`
                        val newGallery = OutdoorGalleries(
                            id = artwork.hashCode(),  // Use hashcode of artwork to generate unique ID
                            owner = gallery.owner.toString(),
                            owner_name = gallery.owner_name,
                            thumbnail = thumbnailPath,  // Pass only the relative path
                            title = artwork.name,  // Use artwork's name as gallery title
                            description = gallery.description,
                            exhibition_type = gallery.exhibition_type,
                            ar_exhibition_type = gallery.ar_exhibition_type,
                            artworks = listOf(artwork)  // Treat this artwork as a standalone "exhibition"
                        )
                        transformedExhibitions.add(newGallery)  // Add this "fake" gallery to the list
                    }
                }

                // Debugging log to verify the transformed exhibitions
                Log.d("GalleriesFragment", "Transformed Exhibitions: ${transformedExhibitions.size}")
                transformedExhibitions.forEach {
                    Log.d("GalleriesFragment", "Exhibition Title: ${it.title}, Thumbnail: ${it.thumbnail}")
                }

                activity?.runOnUiThread {
                    onComplete()  // Notify that the data is ready
                }
            }

            override fun onFailure(call: Call, e: IOException) {
                println("Failed to execute request")
            }
        })
    }

    private fun openArActivity(imageUri: Uri) {
        val intent = Intent(activity, ArActivity::class.java)
        intent.putExtra("imageUri", imageUri)  // Pass the Uri directly
        startActivity(intent)
    }


    // Click listener interface for RecyclerView item clicks
    interface OnItemClickListener {
        fun onItemClicked(position: Int)
    }
}
