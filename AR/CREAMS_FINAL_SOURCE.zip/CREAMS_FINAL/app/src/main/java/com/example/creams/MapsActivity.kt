package com.example.creams

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.location.LocationManagerCompat
import com.example.creams.databinding.ActivityMapsBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener, GoogleMap.OnInfoWindowClickListener {

    private lateinit var mMap: GoogleMap
    private lateinit var binding: ActivityMapsBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val images: HashMap<String, Uri> = HashMap() // Store image URIs for markers

    companion object {
        const val LOCATION_REQUEST_CODE = 1
        const val BASE_MEDIA_URL = "https://creams-poc-final.cognitiveux.net/media/"
        const val BASE_URL = "https://creams-poc-final.cognitiveux.net/"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!isGPSEnabled()) {
            Toast.makeText(this, "Please enable GPS for accurate location.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }
    }

    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerClickListener(this)

        if (!checkLocationPermissions()) return

        mMap.isMyLocationEnabled = true

        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val userLatLng = LatLng(location.latitude, location.longitude)
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))
                handleMarkersBasedOnButton(userLatLng)
            } else {
                Toast.makeText(this, "Failed to retrieve current location", Toast.LENGTH_LONG).show()
            }
        }
    }


    @SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (::mMap.isInitialized) {
                    mMap.isMyLocationEnabled = true
                    fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                        if (location != null) {
                            val userLatLng = LatLng(location.latitude, location.longitude)
                            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))
                            handleMarkersBasedOnButton(userLatLng) // Call marker logic after permission granted
                        } else {
                            Toast.makeText(this, "Failed to retrieve current location", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } else {
                Toast.makeText(this, "Location permission is required to show your location on the map.", Toast.LENGTH_LONG).show()
            }
        }
    }




    private fun handleMarkersBasedOnButton(userLatLng: LatLng) {
        val buttonId = intent.getIntExtra("button_id", -1)
        // Log.i("MapsActivity2", "buttonId: $buttonId")
        val artworkListLat = intent.getSerializableExtra("artworklistlat") as ArrayList<*>
        // Log.i("MapsActivity2", "artworkListLat: $artworkListLat")
        val artworkListLon = intent.getSerializableExtra("artworklistlon") as ArrayList<*>
        // Log.i("MapsActivity2", "artworkListLon: $artworkListLon")
        val artworkListName = intent.getStringArrayListExtra("artworklistname")
        // Log.i("MapsActivity2", "artworkListName: $artworkListName")
        val artworkListSrc = intent.getStringArrayListExtra("artworklistsrc")
        // Log.i("MapsActivity2", "artworkListSrc: $artworkListSrc")
        val artworkListOwnerIdArt = intent.getStringArrayListExtra("artworklistowneridart")
        // Log.i("MapsActivity2", "artworkListOwnerIdArt: $artworkListOwnerIdArt")
        val artworkListArtType = intent.getStringArrayListExtra("artworklistarttype")
        // Log.i("MapsActivity2", "artworkListArtType: $artworkListArtType")
        val threedFiles = intent.getSerializableExtra("artworklistthreedfiles") as? ArrayList<List<String>>
        // Log.i("MapsActivity2", "threedFiles: $threedFiles")

        var validMarkersFound = false

        when (buttonId) {
            1 -> { // Closest Gallery
                val closestIndex = getClosestGalleryIndex(userLatLng, artworkListLat, artworkListLon)

                for (i in artworkListLat.indices) {
                    if (isValidLatLon(artworkListLat[i], artworkListLon[i])) {
                        val artType = artworkListArtType?.get(i)
                        Log.i("MapsActivity", "artType for artwork at index $i: $artType")

                        // Construct the URL for AR model or image
                        val imageUrl = constructImageUrl(artType, artworkListSrc?.get(i), threedFiles?.get(i))
                        Log.i("MapsActivity", "Constructed URL for artwork at index $i: $imageUrl")

                        addMarker(
                            mMap,
                            artworkListLat[i] as Double,
                            artworkListLon[i] as Double,
                            artworkListName?.get(i),
                            "by ${artworkListOwnerIdArt?.get(i)}",
                            imageUrl,
                            artworkListSrc?.get(i),
                            threedFiles?.get(i)
                        )
                        validMarkersFound = true
                    }
                }

                if (validMarkersFound && closestIndex != -1 && isValidLatLon(artworkListLat[closestIndex], artworkListLon[closestIndex])) {
                    val lat = artworkListLat[closestIndex] as Double
                    val lon = artworkListLon[closestIndex] as Double
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), 18f))
                }
            }

            2 -> { // Closest Artwork
                val closestIndex = getClosestGalleryIndex(userLatLng, artworkListLat, artworkListLon)

                if (closestIndex != -1 && isValidLatLon(artworkListLat[closestIndex], artworkListLon[closestIndex])) {
                    val lat = artworkListLat[closestIndex] as Double
                    val lon = artworkListLon[closestIndex] as Double
                    val artType = artworkListArtType?.get(closestIndex)

                    val imageUrl = constructImageUrl(artType, artworkListSrc?.get(closestIndex), threedFiles?.get(closestIndex))

                    val marker = addMarker(
                        mMap,
                        lat,
                        lon,
                        artworkListName?.get(closestIndex),
                        "by ${artworkListOwnerIdArt?.get(closestIndex)}",
                        imageUrl,
                        artworkListSrc?.get(closestIndex),
                        threedFiles?.get(closestIndex)
                    )

                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), 18f))
                    marker?.showInfoWindow()
                    validMarkersFound = true
                }
            }

            else -> { // Gallery from list in homepage
                if (artworkListLat.isNotEmpty() && artworkListLon.isNotEmpty()) {
                    // Loop through all artworks in the selected gallery
                    var firstArtworkLatLng: LatLng? = null
                    for (i in artworkListLat.indices) {
                        if (isValidLatLon(artworkListLat[i], artworkListLon[i])) {
                            val artType = artworkListArtType?.get(i)

                            // Construct the URL for the artwork or model
                            val imageUrl = constructImageUrl(artType, artworkListSrc?.get(i), threedFiles?.get(i))

                            // Add marker for each artwork in the selected gallery
                            addMarker(
                                mMap,
                                artworkListLat[i] as Double,
                                artworkListLon[i] as Double,
                                artworkListName?.get(i),
                                "by ${artworkListOwnerIdArt?.get(i)}",
                                imageUrl,
                                artworkListSrc?.get(i),
                                threedFiles?.get(i)
                            )

                            // Set validMarkersFound to true when a valid marker is added
                            validMarkersFound = true

                            // Use the first artwork's location to center the zoom on the gallery
                            if (firstArtworkLatLng == null) {
                                firstArtworkLatLng = LatLng(artworkListLat[i] as Double, artworkListLon[i] as Double)
                            }
                        }
                    }

                    // Zoom into the first artwork's location in the selected gallery
                    firstArtworkLatLng?.let {
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(it, 18f))
                    }
                }
            }


        }

        // Show error message only if no valid markers were found
        if (!validMarkersFound) {
            Toast.makeText(this, "No valid artwork locations to display on the map.", Toast.LENGTH_LONG).show()
        } else {
            mMap.setInfoWindowAdapter(PopupAdapter(this, layoutInflater, images))
            mMap.setOnInfoWindowClickListener(this)
        }
    }

    private fun constructImageUrl(artType: String?, src: String?, threedFiles: List<String>?): String? {
        return if (artType == "2d") {
            if (src != null) "$BASE_MEDIA_URL$src" else null
        } else if (artType == "3d") {
            threedFiles?.firstOrNull { it.endsWith(".glb", true) }?.let { "$BASE_URL$it" }
        } else {
            null
        }
    }

    private fun addMarker(
        map: GoogleMap, lat: Double, lon: Double, title: String?, snippet: String?,
        image: String?, src: String?, threedFiles: List<String>?  // Updated to also accept 3D files
    ): Marker? {
        Log.i("MapsActivity", "Adding marker: Title = $title, Snippet = $snippet, Image = $image")

        // Add the marker to the map
        val marker = map.addMarker(
            MarkerOptions().position(LatLng(lat, lon)).title(title).snippet(snippet)
        )

        // Store the thumbnail URL for the info window
        val thumbnailUrl = if (src != null) "$BASE_MEDIA_URL$src" else null

        if (marker != null) {
            if (thumbnailUrl != null) {
                // Store the thumbnail Uri for the info window display for 2D or 3D artworks
                images[marker.id] = Uri.parse(thumbnailUrl) // Show the thumbnail in the info window
            }

            // If the artwork is 3D and a .glb file is available, keep the .glb file for AR but do not overwrite the thumbnail
            val glbFileUrl = threedFiles?.firstOrNull { it.endsWith(".glb", true) }
            if (glbFileUrl != null) {
                Log.i("MapsActivity", "3D artwork with .glb file: $glbFileUrl")
                marker.tag = "$BASE_URL$glbFileUrl" // Store the .glb file URL in marker's tag for AR activity
            }
        }

        return marker
    }




    @SuppressLint("MissingPermission")
    override fun onInfoWindowClick(marker: Marker) {
        // Retrieve the user's current location
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val userLatLng = LatLng(location.latitude, location.longitude)
                val markerLatLng = marker.position
                val distanceToMarker = calculateDistance(userLatLng, markerLatLng)

                // Define the proximity threshold (in meters)
                val proximityThreshold = 50f

                if (distanceToMarker <= proximityThreshold) {
                    // Check for the .glb file URL from marker's tag (for 3D AR)
                    val glbUrl = marker.tag as? String

                    if (glbUrl != null) {
                        // If it's a 3D artwork, use the .glb file URL for AR activity
                        Log.i("MapsActivity", "Starting ArActivity with 3D model URL: $glbUrl")
                        openArActivity(Uri.parse(glbUrl)) // Use .glb file URL for AR
                    } else {
                        // Otherwise, use the thumbnail URL (for 2D artwork or fallback)
                        val imageUri = images[marker.id]
                        Log.i("MapsActivity", "Starting ArActivity with imageUri: $imageUri")

                        if (imageUri != null) {
                            openArActivity(imageUri)
                        } else {
                            Log.e("MapsActivity", "Image/Model Uri is null for marker: ${marker.title}")
                            Toast.makeText(this, "No valid Uri found for this artwork", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    // Inform the user if they are too far away
                    Toast.makeText(this, "You are too far from the artwork to start augmentation", Toast.LENGTH_LONG).show()
                }
            }
        }
    }



    private fun isGPSEnabled(): Boolean {
        val locationManager = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
        return LocationManagerCompat.isLocationEnabled(locationManager)
    }

    private fun checkLocationPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_REQUEST_CODE)
            return false
        }
        return true
    }

    private fun calculateDistance(location1: LatLng, location2: LatLng): Float {
        val results = FloatArray(1)
        Location.distanceBetween(location1.latitude, location1.longitude, location2.latitude, location2.longitude, results)
        return results[0]
    }

    private fun isValidLatLon(lat: Any?, lon: Any?): Boolean {
        return lat is Double && lon is Double && lat != 0.0 && lon != 0.0
    }

    private fun getClosestGalleryIndex(userLocation: LatLng, artworklistlat: ArrayList<*>, artworklistlon: ArrayList<*>): Int {
        var closestDistance = Float.MAX_VALUE
        var closestIndex = -1

        for (i in artworklistlat.indices) {
            val lat = artworklistlat[i] as? Double ?: continue
            val lon = artworklistlon[i] as? Double ?: continue

            val artworkLocation = LatLng(lat, lon)
            val distance = calculateDistance(userLocation, artworkLocation)

            if (distance < closestDistance) {
                closestDistance = distance
                closestIndex = i
            }
        }
        return closestIndex
    }

    override fun onMarkerClick(p0: Marker): Boolean {
        return false
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.clear()
    }

    private fun openArActivity(imageUri: Uri) {
        val intent = Intent(this, ArActivity::class.java)
        intent.putExtra("imageUri", imageUri)
        Log.i("MapsActivity", "Passing to ArActivity: imageUri = $imageUri")
        startActivity(intent)
    }
}