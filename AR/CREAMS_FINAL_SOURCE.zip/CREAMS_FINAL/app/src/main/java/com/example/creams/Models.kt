package com.example.creams

class OutdoorGalleryModel(val exhibitions: List<OutdoorGalleries>)
class OutdoorGalleries (val title: String, val owner: String, val owner_name: String, var thumbnail: String, val artworks: List<OutdoorGalleryArtworks>,
                        val description: String, val id: Int, val exhibition_type: String, val ar_exhibition_type: String)
class OutdoorGalleryArtworks(val lat: Double, val lon: Double, var src: String, val name: String, val owner: String,
                             val genre: String, val art_type: String, val threed_files: List<String>)
