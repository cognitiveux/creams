package com.example.creams

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.NetworkPolicy
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.galleries_row.view.*


private val image_url = "https://creams-poc-final.cognitiveux.net/media/"

// https://creams-poc-final.cognitiveux.net/web_app/exhibitions/outdoor/all

class MainAdapter(var outdoorGalleries: OutdoorGalleryModel): RecyclerView.Adapter<CustomViewHolder>() {

    // Number of exhibitions
    override fun getItemCount(): Int {
        return outdoorGalleries.exhibitions.count()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val cellForRow = layoutInflater.inflate(R.layout.galleries_row,parent,false)
        return CustomViewHolder(cellForRow)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        val exhibition = outdoorGalleries.exhibitions[position]
        holder.itemView.GalleryIconText.text = exhibition.title

        // Show the owner's name
        val by_string = "by \n" + exhibition.owner_name
        holder.itemView.GalleryOwnerText.text = by_string

        // Use Picasso to load the image with debugging options
        val thumbnailImageUrl = image_url + exhibition.thumbnail
        Picasso.get()
            .load(thumbnailImageUrl)
            .networkPolicy(NetworkPolicy.NO_CACHE, NetworkPolicy.NO_STORE) // Skip cache to force fresh load
            .error(android.R.drawable.stat_notify_error) // Show error drawable if loading fails
            .into(holder.view.GalleryIcon, object : com.squareup.picasso.Callback {
                override fun onSuccess() {
                    // Log success
                    Log.d("MainAdapter", "Successfully loaded image: $thumbnailImageUrl")
                }

                override fun onError(e: Exception?) {
                    // Log any errors
                    Log.e("MainAdapter", "Failed to load image: $thumbnailImageUrl, Error: ${e?.message}")
                    e?.printStackTrace()
                }
            })

        // Refresh the item data for the view holder
        holder.outdoorGallery = exhibition
    }

}

class CustomViewHolder(val view: View, var outdoorGallery: OutdoorGalleries? = null): RecyclerView.ViewHolder(view) {


    init {

        view.setOnClickListener {
            val intent = Intent(view.context, MapsActivity::class.java)
            val bundle = Bundle()

            // Bundle up the exhibition and artwork info
            //bundle.putString("title", outdoorGallery?.title)
            bundle.putString("ownername_from_recyclerview", outdoorGallery?.owner_name)
            //bundle.putInt("gal_id", outdoorGallery!!.id)
            bundle.putInt("gal_size", outdoorGallery!!.artworks.size)

            val button_id = 0
            val artworklistname: ArrayList<String> = outdoorGallery!!.artworks.map { it.name } as ArrayList<String>
            val artworklistlat: ArrayList<Double> = outdoorGallery!!.artworks.map { it.lat } as ArrayList<Double>
            val artworklistlon: ArrayList<Double> = outdoorGallery!!.artworks.map { it.lon } as ArrayList<Double>
            val artworklistsrc: ArrayList<String> = outdoorGallery!!.artworks.map { it.src } as ArrayList<String>


            bundle.putInt("button_id",  button_id)
            bundle.putInt("gal_id", outdoorGallery!!.artworks.size)
            bundle.putStringArrayList("artworklistname",  artworklistname)
            bundle.putSerializable("artworklistlat", artworklistlat)
            bundle.putSerializable("artworklistlon", artworklistlon)
            bundle.putStringArrayList("artworklistsrc",  artworklistsrc)

            // Add bundle to intent and send to intended activity
            intent.putExtras(bundle)
            view.context.startActivity(intent)
            }
        }
}
